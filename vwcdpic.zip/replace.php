<HTML>
<HEAD>
  <TITLE>VWCDPIC Replacements</TITLE>
  <STYLE TYPE="text/css"><!--
    .Header {
      color: #FFFFFF;
      background-color: #000000;
      font-weight: bold;
      text-align: center;
    }
  --></STYLE>
</HEAD>

<BODY BGCOLOR="#FFFFFF" TEXT="#000000" LINK="#990066" ALINK="#FF6600" VLINK="#232182">


<TABLE WIDTH=200 BORDER=0 CELLSPACING=0 CELLPADDING=5 ALIGN=RIGHT>
<TR><TD>
  <TABLE WIDTH=180 BORDER=0 CELLSPACING=2 CELLPADDING=2>
  <TR>
  <TD BGCOLOR="#D0D0FF" ALIGN=CENTER><B><FONT SIZE=+1>VWCDPIC</FONT></B></TD>
  </TR>

  <TR ALIGN=CENTER><TD BGCOLOR="#F5F5FF">
  <A HREF="install.html">Installation Instructions</A><BR>
  <A HREF="install2.html">Additional Diagrams</A><BR><BR>
  <A HREF="/vwcdpic2/pinout.html">Board Pinouts</A><BR><BR>
  <A HREF="winamp.html">Winamp Remote Control</A><BR><BR>
  <A HREF="/phorum/list.php?f=1">Discussion Forum</A><BR><BR>
  <A HREF="devel.html">Developer's Area</A><BR><BR>
  <A HREF="/puborders.php">Stock Quantity<BR>Order Status</A>
  </TD></TR>

  </TABLE>
</TD></TR></TABLE>

<P>
<B>US$5.00</B> - <B>VWCDPIC-R Replacement (core return required)</B>
</P>

<P>We are now offering replacement VWCDPIC devices at reduced cost 
with the return of your original VWCDPIC.
</P>

<P><B>Features</B>
<UL>
<LI>Latest hardware design adds additional circuitry to help protect 
PICmicro from self-destructing when improperly installed.<BR><BR>

<LI>Input capacitors have been added to help protect your head unit from 
self-destructing if you accidently connect DC power to the audio inputs.<BR><BR>

<LI>Board layout includes 10 Ohm audio ground termination resistor built in
(no errata wire needed). Minimizes the electrical clicking noise 
observed when no audio device is attached, or non-terminating audio device
is attached.<BR><BR>

<LI>New PIC12F629 microcontroller with wider pin spacing, wider traces,
20MHz rated, and extended temperature range (-40&deg;C to +125&deg;C). 
Possible reliability improvement.<BR><BR>

<LI>New firmware may work better with your head unit than earlier
versions (although there is no guarantee).
</UL>
</P>

<P>Limit one replacement priced VWCDPIC for each original VWCDPIC
returned. We will accept any VWCDPIC (good, used, or broken) that was
originally purchased from us.
</P>

<P>The current hardware revision number is "VWCDPIC 2.1" (printed on the 
circuit board).<BR>
The current firmware revision number is v2.7 (only visible through serial
port text output).
</P>

<P>If your VWCDPIC is already hardware revision number "2.1" and it is not 
physically broken, you do not need to order a replacement to get the latest
firmware. Currently, I am providing FLASH upgrades to original VWCDPIC
owners at no charge. Email for shipping details.</P>

<P><B>Limited Warranty</B></P>

<P>This device may not do what you want. We will refund its purchase
price if you return the device to us in original, re-sellable condition 
within 30 days. Shipping and handling fees are not refundable. There are 
no other warranties.</P>

<P>In no event shall you hold us liable for damages, including any general, 
special, incidental or consequential damages arising out of the use or
inability to use this item (including but not limited to loss
of data or data being rendered inaccurate or losses sustained by you or
third parties or a failure of the item to operate with any other device), 
even if such holder or other party has been advised of the possibility of
such damages.
</P>

<P>
<FORM ACTION="/cart.php" METHOD=POST>
<INPUT TYPE=HIDDEN NAME="PartName" VALUE="VWCDPIC-R">
Price: <B>US$5.00</B>
<INPUT TYPE=SUBMIT NAME="Submit" VALUE="Add to order">
</FORM>
</P>

<P>
Go to <A HREF="/">The Garage Shop</A>, <A HREF="/cart.php">Shopping Cart</A>, or <A HREF="/orderinfo.html">Ordering Information</A>.
</P>

</BODY>
</HTML>
