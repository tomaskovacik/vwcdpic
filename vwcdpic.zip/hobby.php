<HTML>
<HEAD>
  <TITLE>Ed takes a vacation from overgrown hobby.</TITLE>
  <STYLE TYPE="text/css"><!--
    .Header {
      color: #FFFFFF;
      background-color: #000000;
      font-weight: bold;
      text-align: center;
    }

    .About {
      background-color: #BBEEBB;
      text-align: left;
    }

    .Quote {
      color: #000000;
      background-color: #EEEEFF;
    }
  --></STYLE>
</HEAD>

<BODY BGCOLOR="#FFFFFF" TEXT="#000000" LINK="#990066" ALINK="#FF6600" VLINK="#232182">

<P>
<FONT SIZE=+1>
<B>I'm tired of soldering! It's time for a vacation...</B>
</FONT>
</P>

<P>
As my home page has always stated, this is only my hobby. I started out just
playing with electronics on my own for fun. I wasted a lot of money on 
electronic components and equipment for assembling prototype circuits to
satisfy my curiosity of electronics and microcontrollers. I was thinking that
maybe I could take my most useful projects and sell them to help pay off
some of the debt wasted on my hobby so that I could continue to play with
more projects.
</P>

<P>Unfortunately, when you give out a good product to a few friends, they
start using it and tell all their friends. Their friends start using it
and tell <i>their</i> friends. And so on. It snow balls. You can increase 
prices to help slow it down, but before you know it, you're not playing with
your little hobby any more.
</P>

<P>I need a little vacation from all of this. I've been thinking about this
even before the <A HREF="http://www.public.asu.edu/~zilym/vwcdpic/bs/">BlitzSafe patent pending problem</A> came up. Please don't take out
your frustration on them. They have stated in my forum that they are not
looking to sue me and I am grateful for that. They make nice products, which
I can certainly tell you, is a lot of hard work to do.
</P>

<P>No new VWCDPIC/VWCDCHIP orders are being accepted as of July 11th, 2004.
All pre-existing orders will be fully honored. I will try to
keep replacements available as necessary to pre-existing customers.</P>

<P>Hopefully by shutting down new orders, I'll finally have a little time 
to play with some of my personal projects again. I certainly have a lot more
spare surface mount components laying around to play with this time.
I'm thinking maybe something with a <b>really small</b> niche market that 
nobody will care about so that I can support my hobby without having the
hobby grow out of control. ;-)
</P>

<P><IMG SRC="/email.png"></P>


<P>
<FONT SIZE=+1><B>Remaining Options</B></FONT>
</P>

<P>If you still need an auxiliary input to your VW but didn't get in on 
ordering a pre-assembled VWCDPIC from me before the pending patent came up,
you still may have some options:

<UL>
<LI>The complete schematic, firmware source code, and parts list for the
VWCDPIC design is available in the <A HREF="devel.html">Developer's Area</A> 
(and has been for a long time).
You can build yourself a VWCDPIC from scratch if you like, but beware that
your finished product is may become patent encumbered in the United
States, so beware if you plan on selling your device to anyone.<BR><BR>

<LI>If you live in Europe, you might be able to buy audio interface adapter
kit from <A HREF="http://home.tiscali.de/matthiasklumpp/index.html">Matthias
Klumpp</A> in Germany. I've never played with one of his adapters to know 
how well it works and unfortunately it does not build upon my VWCDPIC design,
but from what I've read, this is probably a good alternative. This does not
remotely control the Apple iPod or PJRC MP3 Player at the moment, but it does 
remotely control Archos Jukeboxes.<BR><BR>

<LI>Despite the pending patent, Precision Interface Electronics (PIE) still 
seems be producing their <A HREF="http://www.pie.net/aux_vw.htm">auxiliary 
input adapters</A>. You can't remotely control anything, but at least you
can get audio in.
</UL>
</P>

<P>
Go to <A HREF="http://www.k9spud.com/phorum/">Discussion Forum</A>, 
 or <A HREF="http://www.k9spud.com/about/">About Ed</A>.
</P>

</BODY>
</HTML>
