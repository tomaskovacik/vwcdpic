
<HTML>
<HEAD>
  <TITLE>VWCDKIT Parts List</TITLE>
  <LINK REL=StyleSheet HREF="style.css" TYPE="text/css">
  <!-- Copyright (c) 2004, Ed Schlunder -->
</HEAD>
<BODY BGCOLOR="#FFFFFF" TEXT="#000000" LINK="#990066" ALINK="#FF6600" VLINK="#232182">

<P>
  <FONT SIZE=+1><B>VWCDKIT Audio Interface Adapter Kit Parts List</B></FONT><BR>
Copyright &copy; 2004, <IMG SRC="/email.png">
</P>

<P>
<TABLE BORDER=2>
<TR>
<TD CLASS=Header>Part No.</TD>
<TD CLASS=Header>Package</TD>
<TD CLASS=Header>Ref. Designators</TD>
<TD CLASS=Header ALIGN=CENTER>Qty.</TD>
<TD CLASS=Header ALIGN=CENTER>Cost</TD>
<TD CLASS=Header ALIGN=CENTER>Ext.</TD>
<TR><TD CLASS=PartHeader>271-10</TD><TD CLASS=PartHeader>Through Hole</TD><TD CLASS=PartHeader>R19, R20, R11, R12, R6</TD><TD CLASS=PartHeader ALIGN=CENTER>5</TD><TD CLASS=PartHeader ALIGN=CENTER>$0.02</TD><TD CLASS=PartHeader ALIGN=CENTER>$0.1</TD></TR>
<TR><TD COLSPAN=6>10 &#937; 1% 1/4W metal film resistors
<BR>Distributors:  <A HREF='http://www.mouser.com/index.cfm?handler=displayproduct&lstdispproductid=198922'>Mouser</A> ($0.02) &nbsp;
</TD></TR>
<TR><TD CLASS=PartHeader>291-100K</TD><TD CLASS=PartHeader>Through Hole</TD><TD CLASS=PartHeader>R2</TD><TD CLASS=PartHeader ALIGN=CENTER>1</TD><TD CLASS=PartHeader ALIGN=CENTER>$0.009</TD><TD CLASS=PartHeader ALIGN=CENTER>$0.009</TD></TR>
<TR><TD COLSPAN=6>100K &#937; 5% 1/4W carbon film resistors
<BR>Distributors:  <A HREF='http://www.mouser.com/index.cfm?handler=displayproduct&lstdispproductid=202036'>Mouser</A> ($0.009) &nbsp;
</TD></TR>
<TR><TD CLASS=PartHeader>291-1K</TD><TD CLASS=PartHeader>Through Hole</TD><TD CLASS=PartHeader>R15, R16</TD><TD CLASS=PartHeader ALIGN=CENTER>2</TD><TD CLASS=PartHeader ALIGN=CENTER>$0.009</TD><TD CLASS=PartHeader ALIGN=CENTER>$0.018</TD></TR>
<TR><TD COLSPAN=6>1K &#937; 5% 1/4W carbon film resistors
<BR>Distributors:  <A HREF='http://www.mouser.com/index.cfm?handler=displayproduct&lstdispproductid=227915'>Mouser</A> ($0.009) &nbsp;
</TD></TR>
<TR><TD CLASS=PartHeader>291-2.7K</TD><TD CLASS=PartHeader>Through Hole</TD><TD CLASS=PartHeader>R13, R14, R18</TD><TD CLASS=PartHeader ALIGN=CENTER>3</TD><TD CLASS=PartHeader ALIGN=CENTER>$0.009</TD><TD CLASS=PartHeader ALIGN=CENTER>$0.027</TD></TR>
<TR><TD COLSPAN=6>2.7K &#937; 5% 1/4W carbon film resistors
<BR>Distributors:  <A HREF='http://www.mouser.com/index.cfm?handler=displayproduct&lstdispproductid=302581'>Mouser</A> ($0.009) &nbsp;
</TD></TR>
<TR><TD CLASS=PartHeader>291-2K</TD><TD CLASS=PartHeader>Through Hole</TD><TD CLASS=PartHeader>R1</TD><TD CLASS=PartHeader ALIGN=CENTER>1</TD><TD CLASS=PartHeader ALIGN=CENTER>$0.009</TD><TD CLASS=PartHeader ALIGN=CENTER>$0.009</TD></TR>
<TR><TD COLSPAN=6>2K &#937; 5% 1/4W carbon film resistors
<BR>Distributors:  <A HREF='http://www.mouser.com/index.cfm?handler=displayproduct&lstdispproductid=225903'>Mouser</A> ($0.009) &nbsp;
</TD></TR>
<TR><TD CLASS=PartHeader>140-L10V22</TD><TD CLASS=PartHeader>Radial</TD><TD CLASS=PartHeader>C9</TD><TD CLASS=PartHeader ALIGN=CENTER>1</TD><TD CLASS=PartHeader ALIGN=CENTER>$0.065</TD><TD CLASS=PartHeader ALIGN=CENTER>$0.065</TD></TR>
<TR><TD COLSPAN=6>22�F ultraminature electrolytic 10V +/-20% 5x5x2mm (H x D x LS) -40�C to +85�C
<BR>Distributors:  <A HREF='http://www.mouser.com/index.cfm?handler=displayproduct&lstdispproductid=404282'>Mouser</A> ($0.065) &nbsp;
</TD></TR>
<TR><TD CLASS=PartHeader>581-BN154E0105K</TD><TD CLASS=PartHeader>Through Hole</TD><TD CLASS=PartHeader>C2-C5</TD><TD CLASS=PartHeader ALIGN=CENTER>4</TD><TD CLASS=PartHeader ALIGN=CENTER>$0.32</TD><TD CLASS=PartHeader ALIGN=CENTER>$1.28</TD></TR>
<TR><TD COLSPAN=6>1.0�F 10% metallized polyester film capacitor 100V, 17.7mm L x 10.6mm H x 5.2mm W, 15mm LS
<BR>Distributors:  <A HREF='http://www.mouser.com/index.cfm?handler=displayproduct&lstdispproductid=339537'>Mouser</A> ($0.32) &nbsp;
</TD></TR>
<TR><TD CLASS=PartHeader>78-1N4148</TD><TD CLASS=PartHeader>DO-35</TD><TD CLASS=PartHeader>D2</TD><TD CLASS=PartHeader ALIGN=CENTER>1</TD><TD CLASS=PartHeader ALIGN=CENTER>$0.021</TD><TD CLASS=PartHeader ALIGN=CENTER>$0.021</TD></TR>
<TR><TD COLSPAN=6>100V 500mA, VR = 10V through hole
<BR>Distributors:  <A HREF='http://www.mouser.com/index.cfm?handler=displayproduct&lstdispproductid=305127'>Mouser</A> ($0.021) &nbsp;
</TD></TR>
<TR><TD CLASS=PartHeader>78-1N5231B</TD><TD CLASS=PartHeader>DO-35</TD><TD CLASS=PartHeader>D1</TD><TD CLASS=PartHeader ALIGN=CENTER>1</TD><TD CLASS=PartHeader ALIGN=CENTER>$0.024</TD><TD CLASS=PartHeader ALIGN=CENTER>$0.024</TD></TR>
<TR><TD COLSPAN=6>5.1V Zener Diode. 0.5W through hole
<BR>Distributors:  <A HREF='http://www.mouser.com/index.cfm?handler=displayproduct&lstdispproductid=363859'>Mouser</A> ($0.024) &nbsp;
</TD></TR>
<TR><TD CLASS=PartHeader>390261-2</TD><TD CLASS=PartHeader>DIP-8</TD><TD CLASS=PartHeader>-</TD><TD CLASS=PartHeader ALIGN=CENTER>1</TD><TD CLASS=PartHeader ALIGN=CENTER>$0.06</TD><TD CLASS=PartHeader ALIGN=CENTER>$0.06</TD></TR>
<TR><TD COLSPAN=6>8P DIP IC sockets economy tin leaf sleeve
<BR>Distributors:  <A HREF='http://www.mouser.com/index.cfm?handler=displayproduct&lstdispproductid=246437'>Mouser</A> ($0.06) &nbsp;
 <A HREF='http://www.web-tronics.com/c8408.html'>Circuit Specialists</A> ($0.05) &nbsp;
</TD></TR>
<TR><TD CLASS=PartHeader>517-6111TN</TD><TD CLASS=PartHeader>SIP-40</TD><TD CLASS=PartHeader>J3, J4</TD><TD CLASS=PartHeader ALIGN=CENTER>1</TD><TD CLASS=PartHeader ALIGN=CENTER>$0.74</TD><TD CLASS=PartHeader ALIGN=CENTER>$0.74</TD></TR>
<TR><TD COLSPAN=6>.100" 40x1pin .230 post
<BR>Distributors:  <A HREF='http://www.mouser.com/index.cfm?handler=displayproduct&lstdispproductid=291603'>Mouser</A> ($0.74) &nbsp;
 <A HREF='http://www.mouser.com/index.cfm?handler=displayproduct&lstdispproductid=291393'>Mouser</A> ($0.46) &nbsp;
 <A HREF='http://www.web-tronics.com/24-645.html'>Circuit Specialists</A> ($0.22) &nbsp;
</TD></TR>
<TR><TD CLASS=PartHeader>PIC12F629-E/P</TD><TD CLASS=PartHeader>DIP-8</TD><TD CLASS=PartHeader>U1</TD><TD CLASS=PartHeader ALIGN=CENTER>1</TD><TD CLASS=PartHeader ALIGN=CENTER>$2.00</TD><TD CLASS=PartHeader ALIGN=CENTER>$2</TD></TR>
<TR><TD COLSPAN=6>1KB code FLASH ROM, 64 bytes data RAM, 256 bytes data EEPROM.

<p><b>Chip must be flashed with VWCDPIC firmware. If you do not have a <a HREF="/jdm/">PIC Programmer</a>, make sure you purchase our 
pre-programmed chip!</b>
<BR>Distributors:  <A HREF='http://www.k9spud.com/vwcdchip/'>Ed's Electronics Garage</A> ($2.00) &nbsp;
 <A HREF='http://www.mouser.com/index.cfm?handler=displayproduct&lstdispproductid=535415'>Mouser</A> ($1.17) &nbsp;
 <A HREF='http://www.digikey.com/scripts/US/DKSUS.dll?KeywordSearch&Keywords=PIC12F629-E/P-ND'>Digi-Key</A> ($1.11) &nbsp;
 <A HREF='http://www.mouser.com/index.cfm?handler=displayproduct&lstdispproductid=401231'>Mouser</A> ($1.08) &nbsp;
 <A HREF='http://www.digikey.com/scripts/US/DKSUS.dll?KeywordSearch&Keywords=PIC12F629-I/P-ND'>Digi-Key</A> ($1.02) &nbsp;
</TD></TR>
<TR><TD CLASS=PartHeader>000-979-132</TD><TD CLASS=PartHeader>Unknown</TD><TD CLASS=PartHeader></TD><TD CLASS=PartHeader ALIGN=CENTER>4</TD><TD CLASS=PartHeader ALIGN=CENTER>$1.84</TD><TD CLASS=PartHeader ALIGN=CENTER>$7.36</TD></TR>
<TR><TD COLSPAN=6>Male Micro-Timer II tabs (2 on wire), tin.

<P><B>If you find a cheaper distributor for these parts, please let us know!</B><BR>
The crimped on tabs are AMP Part Number 964268-2 (loose) or 964267-2 (strip). These parts are only made in Germany. If we could find a distributor that carried these AMP part numbers, it would probably be a lot cheaper.
<BR>Distributors:  <A HREF='http://www.impexfap.com/partlist.cfm?PARTNUMBERSEARCH=000979132'>Impex</A> ($1.84) &nbsp;
</TD></TR>
<TR><TD CLASS=PartHeader>6Q0-972-736</TD><TD CLASS=PartHeader>Unknown</TD><TD CLASS=PartHeader>H2</TD><TD CLASS=PartHeader ALIGN=CENTER>1</TD><TD CLASS=PartHeader ALIGN=CENTER>$0.95</TD><TD CLASS=PartHeader ALIGN=CENTER>$0.95</TD></TR>
<TR><TD COLSPAN=6>Plastic housing for the CD Changer side connector.
<BR>Distributors:  <A HREF='http://www.impexfap.com/partlist.cfm?PARTNUMBERSEARCH=6Q0972736'>Impex</A> ($0.95) &nbsp;
</TD></TR>
<TR><TD ALIGN=RIGHT COLSPAN=5>Total:</TD><TD ALIGN=CENTER>$12.663</TD></TR>
</TABLE>
</P>


</BODY></HTML>
