<HTML>
<HEAD>
  <TITLE>VWCDPIC Developer's Area</TITLE>
  <STYLE TYPE="text/css"><!--
    .Header {
      color: #FFFFFF;
      background-color: #000000;
      font-weight: bold;
      text-align: center;
    }
  --></STYLE>
</HEAD>

<BODY BGCOLOR="#FFFFFF" TEXT="#000000" LINK="#990066" ALINK="#FF6600" VLINK="#232182">

<P>
<A HREF="schematic-2.0.png">VWCDPIC v2.0 Schematic Diagram</A> - Adds improved protection circuitry and uses low cost PIC12F629.<BR><BR>

<A HREF="powerctl-driver.png">Power Control Driver</A> - Experimental circuit for driving higher current (less than ~3 amps) devices from power control line.<BR><BR>

<A HREF="iPod-VW.asm">iPod-VW Source Code</A> [<A HREF="iPod-VW.hex">HEX</A>] - Carlo Zaskorski's hack at iPod advanced remote control protocol.
<BR><BR>

<A HREF="vwcdpic-2.7.asm">Firmware v2.7 Source Code</A> - VWCDPIC Firmware v2.7. Might work on Touareg head units. Support for remote controlling Archos is working!
<UL>
<A HREF="vwcdpic-2.7-12f629.hex">PIC12F629 HEX</A> - Use this for VWCDPIC v2.x pre-assembled boards.<BR>
<A HREF="vwcdpic-2.7-16f627.hex">PIC16F627 HEX</A> - Use this for VWCDPIC v1.x pre-assembled boards.<BR>
<A HREF="vwcdpic-2.7-12f675.hex">PIC12F675 HEX</A> - Homebrew circuits using PIC12F675 chip.<BR>
</UL>

<A HREF="vwcdpic-2.6d.asm">Firmware v2.6d Source Code</A> - VWCDPIC Firmware v2.6d. Previous version of v2.6 had a bug where the serial TX buffer 
overlapped with the command RX buffer. Whoops!
<UL>
<A HREF="vwcdpic-2.6d-12f629.hex">PIC12F629 HEX</A> - Use this for VWCDPIC v2.x pre-assembled boards.<BR>
<A HREF="vwcdpic-2.6d-16f627.hex">PIC16F627 HEX</A> - Use this for VWCDPIC v1.x pre-assembled boards.<BR>
<A HREF="vwcdpic-2.6d-12f675.hex">PIC12F675 HEX</A> - Homebrew circuits using PIC12F675 chip.<BR>
</UL>

<A HREF="vwcdpic-2.6pre3.asm">Firmware v2.6pre3 Source Code</A> [<A HREF="vwcdpic-2.6pre3.hex">HEX</A>] - VWCDPIC Firmware v2.6pre3 for PIC12F629 microcontrollers.<BR><BR>

<A HREF="vwcdpic-2.6pre2.asm">Firmware v2.6pre2 Source Code</A> [<A HREF="vwcdpic-2.6pre2.hex">HEX</A>] - VWCDPIC Firmware v2.6pre2 for PIC12F629 microcontrollers.<BR><BR>

<A HREF="vwcdpic-2.6pre1.asm">Firmware v2.6pre1 Source Code</A> [<A HREF="vwcdpic-2.6pre1.hex">HEX</A>] - VWCDPIC Firmware v2.6pre1 for PIC12F629 microcontrollers.<BR><BR>

<A HREF="old/vwcdpic-2.5.1.asm">Firmware v2.5 Source Code</A> - VWCDPIC Firmware v2.5 for various PICmicros:
<UL>
 <A HREF="vwcdpic-2.5.hex">PIC12F629 HEX</A> - Use this for VWCDPIC v2.x pre-assembled boards.<BR>
 <A HREF="old/vwcdpic-2.5.1-16f627.hex">PIC16F627 HEX</A> - Use this for VWCDPIC v1.x pre-assembled boards.<BR>
</UL>

<A HREF="old/vwcdpic-2.4.1.asm">Firmware v2.4 Source Code</A> - VWCDPIC Firmware v2.4.
<UL>
 <A HREF="vwcdpic-2.4.hex">PIC12F629 HEX</A><BR>
 <A HREF="old/vwcdpic-2.4.1-16f627.hex">PIC16F627 HEX</A><BR>
</UL>

<A HREF="vwcdpic-svet.asm">Firmware v2.3 (Svet Hack) Source Code</A> [<A HREF="vwcdpic-svet.hex">HEX</A>] - VWCDPIC Firmware v2.3 (Svet Hack) for PIC12F629 microcontrollers - <B>UNTESTED</B>.<BR><BR>

<A HREF="old/vwcdpic-2.3.1.asm">Firmware v2.3 Source Code</A> - VWCDPIC Firmware v2.3.
<UL>
 <A HREF="vwcdpic-2.3.hex">PIC12F629 HEX</A><BR>
 <A HREF="old/vwcdpic-2.3.1-16f627.hex">PIC16F627 HEX</A><BR>
</UL>

<!-- A HREF="vwcdpic-2.3.asm">Firmware v2.3 Source Code</A> [<A HREF="vwcdpic-2.3.hex">HEX</A>] - VWCDPIC Firmware v2.3 for PIC12F629 microcontrollers.<BR><BR -->

<A HREF="old/vwcdpic-2.2.1.asm">Firmware v2.2 Source Code</A> - VWCDPIC Firmware v2.2.
<UL>
 <A HREF="vwcdpic-2.2.hex">PIC12F629 HEX</A><BR>
 <A HREF="old/vwcdpic-2.2.1-16f627.hex">PIC16F627 HEX</A><BR>
</UL>

<!-- A HREF="vwcdpic-2.2.asm">Firmware v2.2 Source Code</A> [<A HREF="vwcdpic-2.2.hex">HEX</A>] - VWCDPIC Firmware v2.2 for PIC12F629 microcontrollers.<BR><BR -->

<A HREF="pjrc-vwcdpic-support.patch">PJRC MP3 Player Firmware Patch</A> [<A HREF="mp3player-vwcdpic-08092003.hex">HEX</A>] - PJRC MP3 Player Firmware Aug. 9th 2003 CVS Snapshot, with added modifications for better VWCDPIC support.<BR><BR>

<A HREF="old/vwcdpic-2.1.1.asm">Firmware v2.1 Source Code</A> - VWCDPIC Firmware v2.1.
<UL>
 <A HREF="vwcdpic-2.1.hex">PIC12F629 HEX</A><BR>
 <A HREF="old/vwcdpic-2.1.1-16f627.hex">PIC16F627 HEX</A><BR>
</UL>

<!-- A HREF="vwcdpic-2.1.asm">Firmware v2.1 Source Code</A> [<A HREF="vwcdpic-2.1.hex">HEX</A>] - VWCDPIC Firmware v2.1 for PIC12F629 microcontrollers.<BR><BR -->

<A HREF="old/vwcdpic-2.0.1.asm">Firmware v2.0 Source Code</A> - VWCDPIC Firmware v2.0.
<UL>
 <A HREF="vwcdpic-2.0.hex">PIC12F629 HEX</A><BR>
 <A HREF="old/vwcdpic-2.0.1-16f627.hex">PIC16F627 HEX</A><BR>
</UL>

<!-- A HREF="vwcdpic-2.0.asm">Firmware v2.0 Source Code</A> [<A HREF="vwcdpic-2.0.hex">HEX</A>] - VWCDPIC Firmware v2.0 for PIC12F629 microcontrollers.<BR><BR -->

<A HREF="schematic.png">VWCDPIC v1.0 Schematic Diagram</A> - The original tried and true design based on PIC16F62X.<BR>

<A HREF="vwcdpic-1.7.asm">Firmware v1.7 Source Code</A> [<A HREF="vwcdpic-1.7.hex">HEX</A>] - VWCDPIC Firmware v1.7 for PIC16F62X microcontrollers.<BR><BR>

<A HREF="vwcdpic-1.6.asm">Firmware v1.6 Source Code</A> [<A HREF="vwcdpic-1.6.hex">HEX</A>] - VWCDPIC Firmware v1.6 (beta) for PIC16F62X.<BR><B>WARNING</B>: This firmware configures PIC I/O Pin RB7 as an -output- line, while previous versions of the firmware configured RB7 as an input.</A><BR><BR>
<A HREF="vwcdpic-1.5.asm">Firmware v1.5 Source Code</A> [<A HREF="vwcdpic-1.5.hex">HEX</A>] - VWCDPIC Firmware v1.5 for PIC16F62X.</A><BR><BR>
<A HREF="vwcdpic-1.4.asm">Firmware v1.4 Source Code</A> [<A HREF="vwcdpic-1.4.hex">HEX</A>] - VWCDPIC Firmware v1.4 for PIC16F62X.</A><BR><BR>
<A HREF="vwcdpic-dump.asm">Head Unit Dump Source Code</A> [<A HREF="vwcdpic-dump.hex">HEX</A>] - VWCDPIC firmware for dumping command data strings from the head unit to your PC.</A><BR><BR>
<A HREF="vwcdcap.asm">Changer Dump Source Code</A> [<A HREF="vwcdcap.hex">HEX</A>] - PIC16F62x firmware for dumping packets from the CD Changer to your PC.</A><BR><BR>
<A HREF="vwcde-hc08.asm">Motorola HC08 Source Code</A> [<A HREF="vwcde-hc08.s19">S19</A>] - Esmir Celebic's Motorola HC08 firmware.<BR><BR>
<A HREF="vwhack.asm">PIC16F84 Source Code</A> [<A HREF="vwhack.hex">HEX</A>] - Simple display update only code. Should be easy to compile on any PIC16F microcontroller with minor modifications.<BR><BR>
<A HREF="vwcdpic-stewart.asm">Firmware PJS-Monsoon Source Code</A> [<A HREF="vwcdpic-stewart.hex">HEX</A>] - VWCDPIC firmware for Monsoon, unstable (P. Stewart branch). Obsoleted by firmware v1.4.</A><BR><BR>
<A HREF="vwcdpic-stewart.txt">P. Stewart's Notes</A> - VWCDPIC firmware for Monsoon, unstable.</A><BR><BR>
<A HREF="pic2.cap">P. Stewart's pic2.cap</A> - Monsoon data dumps.</A><BR><BR>
<A HREF="pic3.cap">P. Stewart's pic3.cap</A> - Monsoon data dumps.</A><BR><BR>
<A HREF="pic5.cap">P. Stewart's pic5.cap</A> - Monsoon data dumps.</A><BR><BR>
<A HREF="emulate.pbp">A. Wilson's CDC emulator</A> - 6/10/2002 PIC Basic Pro code snippet of CDC emulator supporting his Monsoon head unit<BR><BR>

<A HREF="old/vwcdpic-1.0.asm">VWCDPIC Firmware v1.0 Source Code</A> [<A HREF="vwcdpic-1.0.hex">HEX</A>] - 6/10/2002 Used on the very first VWCDPIC's shipped.
<BR><BR>

<A HREF="old/vwhack-1.0.0.tar.gz">EZ Protoboard Firmware v1.0</A> - 3/17/2002 
Ed's last prototype CDC emulator using the EZ-USB FX
microcontroller.<BR><BR>

<A HREF="old/vwhack-04172001.zip">EZ Protoboard Firmware</A> - 4/17/2001
Initial CDC emulator hack with very crude head unit command capture capability.
Also includes some messy source code for capturing high speed digital
data using the EZ Protoboard and dumping to a PC's USB port.
<BR><BR>

<A HREF="http://www.microchip.com/1010/pline/tools/picmicro/devenv/mplabi/">Microchip MPLAB IDE</A> - Includes assembler for building the firmware.<BR><BR>
<A HREF="gen_vwcdpic_plugin.zip">Winamp 2.x Plugin v1.0</A> - Winamp Remote Control plugin v1.0 source code (Visual C++ v5.0).<BR><BR>
<A HREF="audi-pinout.html">Audi & Panasonic CD Changer Pinouts</A><BR><BR>
<A HREF="http://www.John-Wasser.com/NewBeetle/CDChanger.html">Volkswagen CD Changer Pinouts</A><BR><BR>
</P>

<P>
<A HREF="http://www.mictronics.de/?page=cdc_proto">CD Changer
Protocols</A> - If you scroll down to the very bottom of this page,
you will find a brief description of the Panasonic CD Changer protocol.
Panasonic makes the VW head unit and CD Changer. This page is not my work and
is otherwise unrelated to the VWCDPIC project.
</P>

<P>
<A HREF="http://www.maushammer.com/systems/ipod-remote/ipod-remote.html">
Apple iPod Remote Control</A> - Here's a guy working on reverse 
engineering the iPod wired remote control. Might be useful if someone wanted
to design a VWCDPIC that could remote control the iPod.
</P>

<P>
Go to <A HREF="/">The Garage Shop</A>, <A HREF="/phorum/list.php?f=1">Discussion Forum</A>.
</P>

</BODY>
</HTML>
