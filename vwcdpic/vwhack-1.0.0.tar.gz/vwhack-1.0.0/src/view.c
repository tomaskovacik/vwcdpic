#include <stdio.h>
#include <stdlib.h>

int main(void) {
  FILE *fp;
  char buf[64];

  fp = fopen("capture.dat", "r");

  while(fread(buf, sizeof(buf), 1, fp)) {
    int i, j;
    for(i = 0; i < sizeof(buf); i++) {
      if((i % 7) == 0)
	printf("\n");
      
      for(j = 0; j < 8; j++) {
	printf(buf[i] & 0x80 ? "1":"0");
	buf[i] <<= 1;
      }
    }
  }

  return 0;
}
