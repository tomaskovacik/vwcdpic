// EZ Console
// Copyright (c) 2001, Ed Schlunder <zilym@yahoo.com>

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <signal.h>
#include <string.h>
#include "usblinux.h"

#define EPCONSOLE 2
#define USBTIMEOUT 1000

void printUsage(void);

int main(int argc, char *argv[]) {
  struct usbdevice *ezusb;
  int bus = -1, device = -1, vendor = 0x547, product = 0x2131;
  unsigned char buf[64];
  int i;

  printf("EZ Console v1.0.0\n");
  printf("Copyright (c) 2001, Ed Schlunder <zilym@yahoo.com>\n\n");

  // process command line options
  do {
    i = getopt(argc, argv, "hb:d:v:p:");
    switch(i) {
    case 'b':
      bus = atoi(optarg);
      break;
    case 'd':
      device = atoi(optarg);
      break;
    case 'v':
      vendor = atoi(optarg);
      break;
    case 'p':
      product = atoi(optarg);
      break;
    case 'h':
      printUsage();
      break;
    }
  } while(i != -1);

  // attempt to connect to the USB device
  if(bus != -1 && device != 1)
    ezusb = usbOpenByNumber(bus, device);
  else
    ezusb = usbOpen(vendor, product);
  if(ezusb == NULL) {
    printf("Error: No EZ USB device connected.\n");
    return 2;
  }

  if(usbClaimInterface(ezusb, 0) < 0)
    return 3;

  if(usbSetAltInterface(ezusb, 1) < 0)
    return 4;

  // tell device to reset console endpoint data toggles
  buf[0] = 0;
  usbBulkOut(ezusb, EPCONSOLE, buf, sizeof(buf), USBTIMEOUT);

  /*
  if(fork() == 0) {
    FILE *fp;
    struct {
      unsigned short pktCount;
      unsigned short timeCount;
      unsigned char state;
    } pkt;

    printf("child data reciever started\n");
    fp = fopen("capture.dat", "w");
    if(fp == NULL) {
      printf("couldn't create capture.dat\n");
      return -1;
    }
    for(;;) {
      if(usbBulkIn(ezusb, 4, &pkt, 8, 32766) >= 0) {
	fprintf(fp, (pkt.state & 4) ? "1":"0");
	fprintf(fp, (pkt.state & 2) ? "1":"0");
	fprintf(fp, (pkt.state & 1) ? "1":"0");
	fprintf(fp, (pkt.state & 8) ? "1":"0");
	fprintf(fp, " pkt: %d time: %d\n", pkt.pktCount, pkt.timeCount);
	fflush(fp);
      }
      else {
	printf("timeout while waiting for usb, exiting\n");
	return 0;
      }
    }
  }
  */

  printf("[ezusb]$ ");
  while(fgets(buf, sizeof(buf), stdin) != NULL) {
    if(strcmp(buf, "save\n") == 0) {
      FILE *fp = fopen("capture.dat", "w");

      printf("Downloading capture data");
      while(usbBulkIn(ezusb, 4, buf, sizeof(buf), 32000) >= 0) {
	printf(".");
	fflush(stdout);
	/*
	for(i = 0; i < sizeof(buf); i++) {
	  if((i % 16) == 0)
	    fprintf(fp, "\n");
	  fprintf(fp, "%.2X ", buf[i]);
	}
	*/
	fwrite(buf, sizeof(buf), 1, fp);
	fflush(fp);
      }
      fclose(fp);
      printf("done!\n[ezusb]$ ");
      continue;
    }

    usbBulkOut(ezusb, EPCONSOLE, buf, sizeof(buf), USBTIMEOUT);

    for(;;) {
      if(usbBulkIn(ezusb, EPCONSOLE, buf, sizeof(buf), USBTIMEOUT) < 0)
	break;
      if(buf[0] == 0)   // end of transmission
	break;  

      if(buf[0] == 1)   // string
	printf("%s", buf+1);
      if(buf[0] == 2) { // numeric
	unsigned short tmp;
	memcpy(&tmp, buf+1, sizeof(tmp));
	printf("%X", tmp);
      }
      if(buf[0] == 3) { // binary data
	unsigned char len;
	len = buf[1];
	for(i = 0; i < len; i++)
	  printf("%.2X ", buf[i+2]);
      }
    }
    
    printf("[ezusb]$ ");
  }

  printf("\n");
  
  // tell device to reset connection, we are exiting
  buf[0] = 1;
  usbBulkOut(ezusb, EPCONSOLE, buf, sizeof(buf), USBTIMEOUT);

  usbReleaseInterface(ezusb, 0);
  usbClose(ezusb);
  return 0;
}

void printUsage(void) {
  printf("Usage: ezconsole [options]\n\n");
  printf(" -b BUS\t\tBUS is the bus number that your EZ USB device is connected to\n");
  printf(" -d DEVICE\tDEVICE is the device number that was assigned at connect\n");
  printf(" OR\n");
  printf(" -v VENDORID\n");
  printf(" -p PRODUCTID\n");
}
