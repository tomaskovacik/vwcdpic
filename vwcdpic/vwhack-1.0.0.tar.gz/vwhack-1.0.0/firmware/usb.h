// USB Control
// Copyright (c) 2001, Edward Schlunder <zilym@yahoo.com>

void initUSB(void);
void intUSB(void) interrupt 8;
void ep2outUSB(void);

// send a string back to the host through EP2IN
signed char prints(char *s);
signed char printn(unsigned int val);
signed char printDone(void);
