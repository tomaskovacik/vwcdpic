// VW Head Unit <-> PJRC MP3 Serial Communications
// Copyright (c) 2001, Edward Schlunder <zilym@yahoo.com>

#include <string.h>
#include "ezusbfx.h"
#include "serial.h"
#include "vwhack.h"

#define MP3_BAUDRATE 19200

unsigned char txlen, txloc, rxloc;
idata unsigned char volatile rxbuf[RXSIZE], txbuf[10];

void initSerial(void) {
  SCON0 = 0x50;           // Serial 0 - Mode 1, Async No Parity
  OEC   |= (1<<1);        // enable output (is this necessary?)
  //OEC   &= ~(1<<0);
  OEB   |= (1<<3);
  IOC_1 = 0;
  IOB_3 = 0;

  PORTCCF2 = 0;
  PORTCCFG = (1<<1);        // IOC.1 = TxD0
  IFCONFIG = 0;             // IOB.2 = RxD1 IOB.3 = TxD1
  PORTBCFG = (1<<3);

  T2CON = 0x34 & ~(1<<5);   // time 2 baud rate generator for send
  TR2 = 0;                  // turn off timer while changing timer reload value

  // Timer Reload = 65536 - (MCU Osc. Freq / (32 * Baud Rate))
  //  RCAP2H = (0xFFFF - (48000000 / (32 * BAUDRATE))) >> 8;
  //  RCAP2L = (0xFFFF - (48000000 / (32 * BAUDRATE))) & 0xFF;
  RCAP2H = 0xFF;
  RCAP2L = 0xB1;

  TMOD = TIMER0_16 | TIMER1_8AUTO_RELOAD; // t0 = 16 bit timer t1 = 8 bit auto
  TCON = 0;
  PCON |= SMOD0;        // baud rate doubled
  SMOD1 = 1;            // divide timer clock by two
  TR1 = 0;
  TH1 = 81;             // 1428.57142857 baud
  TL1 = 81;

  rxloc = 0;
  clearRX();

  ET1 = 0;
  TR1 = 1;
  TR2 = 1;               // enable timer 2 (baud rate generator)
  ES0 = 1;               // enable serial interrupt
  //  ES1 = 1;
  //  IOA_2 = 1;
  REN_0 = 0;             // disable serial 0 reception
}

void clearRX(void) {
  unsigned char i;

  for(i = 0; i < RXSIZE; i++)
    rxbuf[i] = 0;
}

void nextList(void) {
  strcpy(txbuf, "NXT_LIST\n");
  txloc = 1;
  txlen = 9;
  SBUF0 = txbuf[0];
}

void prevList(void) {
  strcpy(txbuf, "PRV_LIST\n");
  txloc = 1;
  txlen = 9;
  SBUF0 = txbuf[0];
}

void nextMP3(void) {
  strcpy(txbuf, "NEXT\n");
  txloc = 1;
  txlen = 5;
  SBUF0 = txbuf[0];
}

void previousMP3(void) {
  strcpy(txbuf, "PREVIOUS\n");
  txloc = 1;
  txlen = 9;
  SBUF0 = txbuf[0];
}

void mixMP3(void) {
  strcpy(txbuf, "RANDOM\n");
  txloc = 1;
  txlen = 7;
  SBUF0 = txbuf[0];
}

void playMP3(void) {
  strcpy(txbuf, "PLAY\n");
  txloc = 1;
  txlen = 5;
  SBUF0 = txbuf[0];
}

void serial0(void) interrupt 4 {
  if(TI_0) { // sending control commands to the PJRC MP3 player
    TI_0 = 0;
    if(txloc < txlen)
      SBUF0 = txbuf[txloc++];
  }
}

void serial1(void) interrupt 7 {
}
