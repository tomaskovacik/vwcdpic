// Volkswagen CD Changer Emulator Firmware
// Copyright (c) 2001, Ed Schlunder <zilym@yahoo.com>

#include <string.h>
#include "ezusbfx.h"
#include "usb.h"
#include "serial.h"

void idle(void);
void sendByte(unsigned char a);
void matchButton(void);

idata unsigned char volatile pkt[8];
unsigned char volatile disc, track, mix, scan;
unsigned char volatile timeCount;

void main(void) {
  PSW = 0;
  DPS = 0;                // select first data pointer (dptr)
  CKCON = 0;              // no external waitstates
  IE = 0;                 // disable all interrupts
  EIE = 0;

  I2CMODE = I2400KHZ;     // set high speed I2C bus
  PORTSETUP = 1;          // enable using SFRs for I/O port control

  OEA = 0x1F;             // port a pins outputs (blinking LEDs)
  OEB = 0;                // inputs
  OEC = 0;
  OED = 0;
  OEE = 0xFF;             // drive port E pins, save power on 80 pin chip

  IOA = 0;

  initUSB();
  initSerial();

  pkt[0] = 0x74;
  pkt[1] = 0xB9; // disc
  pkt[2] = 0xFE; // track
  pkt[3] = 0xFF; // ??
  pkt[4] = 0xFF;
  pkt[5] = 0xFF; // mode (scan/mix)
  pkt[6] = 0x8F;
  pkt[7] = 0x7C;

  // need 2200K timer pules for 550ms interval = 22000 * 100
  // 0xFFFF - 22000 = 0xAA0F
  //  TMOD = TIMER0_16 | TIMER1_8AUTO_RELOAD; // t0 = 16 bit timer t1 = stop
  //  TCON = 0;
  TR0 = 0;
  TL0 = 0x0F;             // Hz clock (assuming 48MHz system clock)
  TH0 = 0xAA;
  TR0 = 1;                // enable timer 0
  //  IP |= (1<<1);           // set timer 0 to high priority

  // enable interrupts  
  ET0 = 1;  // enable timer 0 interrupt
  EA = 1;   // global interrupt enable

  disc = 1;
  track = 1;
  mix = 0;
  scan = 0;
  idle();
}

void idle(void) {
  for(;;) {
    ET0 = 0;  // disable timer 0 interrupt while changing data values
    pkt[1] = 0xB0 | (0x0F - disc);
    pkt[2] = 0xFF - track;
    pkt[5] = (scan ? 0x20:0xF0) | (mix ? 0x0B:0x0F);
    ET0 = 1;  // enable timer 0 interrupt
    
    if(IOC_0 == 0) {
    _asm
    ;;001$: ;;jb    _IOC_0, 001$ ;; wait for high from head unit (start of data)
          clr   _EA          ;; disable interrupts
    007$: jnb   _IOC_0, 007$ ;; wait for low from head unit
    008$: jb    _IOC_0, 008$ ;; wait for high from head unit (start of data)

          mov   r2, #8 ;; read 8 bits of data per byte
          mov   r1, #0
          mov   r0, #(_rxbuf+1)
    006$:
          mov   r7, #1
          mov   r6, #0
          mov   r5, #0
    002$: jb    _IOC_0, 003$
          djnz  r5, 002$
   	  djnz  r6, 002$
          djnz  r7, 002$

          ;; if execution reaches here, we have timed out
          ajmp  099$
    003$: 
          mov   r7, #1
          mov   r6, #0
          mov   r5, #0
    004$: jnb   _IOC_0, 005$ ;; exit if LOW period has ended
          djnz  r5, 004$
   	  djnz  r6, 004$
          djnz  r7, 004$
          ;; if execution reaches here, we have timed out
          ajmp  099$
    005$: inc   r1 
	  clr   c
          cjne  r6, #0xF5, 009$
          setb  c
    009$: rlc   a
          djnz  r2, 006$
          mov   @r0, a
          inc   r0
          mov   r2, #8
	  ajmp  006$
 
    099$: 
          mov   r0, #_rxbuf
          mov   a,r1
          mov   @r0, a

          setb  _EA
    _endasm;

    matchButton();
    }
  }
}

void matchButton(void) {
  if(rxbuf[1] != 0x53 || rxbuf[2] != 0x2C)
    return;

  if(rxbuf[3] == 0xF8 && rxbuf[4] == 0x07) { // up
    nextMP3();
    if(track < 99)
      track++;
    if((track & 0x0F) == 0x0A)
      track += 6;
    return;
  }

  if(rxbuf[3] == 0x78 && rxbuf[4] == 0x87) { // dn
    previousMP3();
    if(track > 0)
      track--;
    if((track & 0x0F) == 0x0F)
      track -= 6;
    return;
  }

  if(rxbuf[3] == 0xA0 && rxbuf[4] == 0x5F) { // scan
    playMP3();
    return;
  }

  if(rxbuf[3] == 0x60 && rxbuf[4] == 0x9F) { // mix
    mixMP3();
    mix = (mix ? 0:1);
    return;
  }

  if(rxbuf[3] == 0xD8 && rxbuf[4] == 0x27) { // seek forward press
    nextList();
    if(disc < 10)
      disc++;
    track = 1;
    return;
  }

  if(rxbuf[3] == 0x58 && rxbuf[4] == 0xA7) { // seek back press
    prevList();
    if(disc > 0)
      disc--;
    track = 1;
    return;
  }
}

void timer0(void) interrupt 1 {
  if(--timeCount == 0) {
    // We send the Head Unit a data packet every ~550ms as seen on the original
    // VW OEM CD Changer with my standard oscilloscope.
    
    // actually, it seems to work fine all the way down to 5.5ms or so now that
    // we are sending data more properly. faster display updates, yay!
  _asm
      mov  r0, #_pkt
      mov  r1, #8     ;; packet size in bytes

    00000$:
      mov  a, @r0     ;; load next byte of data into accumulator
      inc  r0

      clr  _EA        ;; disable all interrupts for timing critical code

      mov  r2, #8     ;; send 8 bits of data
    00001$:
      clr  _IOA_0     ;; 2 clks
      rlc  a          ;; 1 clk  load next data bit into carry flag
      mov  _IOA_1,c   ;; 2 clks load carry flag onto STX line
      setb _IOA_0     ;; 2 clks clock data into head unit
      djnz r2,00001$  ;; 3 clks

      setb _EA        ;; re-enable interrupts

      ;; this delay can be made longer without limit as long as we have 5V 
      ;; signaling. does not work so grand with 3.3V signals.
      mov  r2,#4
      mov  r3,#0      ;; 256 iterations of inner loop
    00002$:
      nop             ;; 1 clk
      djnz r3, 00002$ ;; 3 clks
      djnz r2, 00002$ 

      djnz r1,00000$
    _endasm;

    timeCount = REFRESH_WAIT;
  }

  // reload timer count
  TR0 = 0;
  TL0 = 0x0F;            // 0.55ms clock (assuming 48MHz system clock)
  TH0 = 0xAA;
  TR0 = 1;
}
