// VW Head Unit Serial Communications
// Copyright (c) 2001, Edward Schlunder <zilym@yahoo.com>

#define RXSIZE 70
#define REFRESH_WAIT 2

extern idata unsigned char volatile rxbuf[RXSIZE];
extern unsigned char volatile rxloc;

void initSerial(void);
void clearRX(void);
void nextList(void);
void prevList(void);
void nextMP3(void);
void previousMP3(void);
void mixMP3(void);
void playMP3(void);

void serial0(void) interrupt 4;
void serial1(void) interrupt 7;

void captureHead(void);
void captureCD(void);

