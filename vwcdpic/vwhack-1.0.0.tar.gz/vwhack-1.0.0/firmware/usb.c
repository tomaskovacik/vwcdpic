// USB Control
// Copyright (c) 2001, Edward Schlunder <zilym@yahoo.com>

#include "ezusbfx.h"
#include "usb.h"
#include "serial.h"
#include "vwhack.h"

#include <string.h>

void initUSB(void) {
  unsigned char i;

  USBIEN = 0;             // disable all USB interrupts

  USBCS = 0;              // disconnect from USB (to simulate device removal)
  USBBAV = 0;             // disable autovector, disable breakpoint logic
  ISOCTL = ISODISAB;      // disable ISO endpoints
  INISOVAL = 0;
  OUTISOVAL = 0;

  USBPAIR = (1<<1);       // turn on double buffering for endpoints 4/5 IN
  IN07VAL = (1<<2)|(1<<4);// enable ezconsole in endpoint
  OUT07VAL= (1<<2);       // enable ezconsole out endpoint
  IN07IEN = 0;            // disable all IN endpoint interrupts
  OUT07IEN = (1<<2);      // enable OUT2EP interrupt, disable all others

  // clear all endpoint dataX toggles
  for(i = 0; i < 7; i++) {
    TOGCTL = 0x10 + i;
    TOGCTL = 0x30 + i;
    TOGCTL = i;           // clear EP in toggle
    TOGCTL = 0x20 + i;    // clear EP out toggle
  }

  USBCS = (1<<2);         // reconnect to USB bus (simulate device insertion)
  // renumeration is done

  // arm the OUT2EP so we can receive the next command
  OUT2BC = 0;
  EUSB = 1;               // enable USB interrupts
}

void intUSB(void) interrupt 8 {
  unsigned char src = IVEC >> 2;

  switch(src) {
  case 0:
    // setup data available
    EXIF &= ~USBINT;
    USBIRQ = SUDAVIR;
    break;
  case 1:
    //    usb_sof();
    EXIF &= ~USBINT; // without this get continuous interrupt :-)
    USBIRQ = SOFIR;
    break;
  case 2:
    //    usb_sutok(); // setup token (debug only)
    EXIF &= ~USBINT;
    USBIRQ = SUTOKIR;
    break;
  case 3:
    //    usb_suspend();
    EXIF &= ~USBINT;
    USBIRQ = SUSPIR;
    break;
  case 4:
    //    usb_usbreset();
    EXIF &= ~USBINT;
    USBIRQ = URESIR;
    break;
  case 6:
    //    usb_ep0in();
    EXIF &= ~USBINT;
    IN07IRQ = 1<<0;
    break;
  case 7:
    //    usb_ep0out();
    EXIF &= ~USBINT;
    OUT07IRQ = 1<<0;
    break;
  case 8:
    //    usb_ep1in();
    EXIF &= ~USBINT;
    IN07IRQ = 1<<1;
    break;
  case 9:
    //    usb_ep1out();
    EXIF &= ~USBINT;
    OUT07IRQ = 1<<1;
    break;
  case 11:
    ep2outUSB();
    EXIF &= ~USBINT;
    OUT07IRQ = 1<<2;
    break;
  }
}

// EndPoint 2 Out - Console Commands
void ep2outUSB(void) {
  // console app start/exit?
  if(OUT2BUF[0] == 0 || OUT2BUF[0] == 1) {
    unsigned char i;
    for(i = 0; i < 7; i++) {
      TOGCTL = 0x10 + i;
      TOGCTL = 0x30 + i;
      TOGCTL = i;           // clear EP in toggle
      if(OUT2BUF[0] == 1)
	TOGCTL = 0x20 + i;  // clear EP out toggle (only if console app exited)
    }

    OUT2BC = 0;
    return;
  }
  if(strcmp(OUT2BUF, "id\n") == 0) {
    prints("VW CD Changer Emulator Firmware 1.0.0 (03-15-2002)\n");
    prints("Copyright (c) 2001-2002, Ed Schlunder <zilym@yahoo.com>\n\n");
  }

  if(strcmp(OUT2BUF, "speed\n") == 0) {
    if(CPUCS & CLK2448)
      prints("48MHz\n\n");
    else
      prints("24MHz\n\n");
  }

  if(strcmp(OUT2BUF, "next\n") == 0) {
    prints("next mp3 song\n");
    nextMP3();
  }

  if(strcmp(OUT2BUF, "prev\n") == 0) {
    prints("previous mp3 song\n");
    previousMP3();
  }

  if(strcmp(OUT2BUF, "mix\n") == 0) {
    prints("mix mp3 songs\n");
    mixMP3();
  }

  if(strcmp(OUT2BUF, "play\n") == 0) {
    prints("play/pause mp3\n");
    playMP3();
  }

  if(strcmp(OUT2BUF, "rxbuf\n") == 0) {
    unsigned char i;

    prints("RXBUF: [");

    // make sure EP2IN is available before screwing around with it
    while(IN2CS & EPBUSY);
    IN2BUF[0] = 3; // flag host that we're sending binary data
    IN2BUF[1] = 62; //RXSIZE;
    for(i = 0; i < 62; i++)
      IN2BUF[i+2] = rxbuf[i];
    IN2BC = 64;

    // make sure EP2IN is available before screwing around with it
    while(IN2CS & EPBUSY);
    IN2BUF[0] = 3; // flag host that we're sending binary data
    IN2BUF[1] = RXSIZE - 62;
    for(i = 0; i < RXSIZE; i++)
      IN2BUF[i+2] = rxbuf[i+62];
    IN2BC = 64;

    rxloc = 0;
    clearRX();

    prints("]\n");
  }

  if(strcmp(OUT2BUF, "t+\n") == 0)
    track++;
  if(strcmp(OUT2BUF, "t-\n") == 0)
    track--;

  if(strcmp(OUT2BUF, "d+\n") == 0)
    disc++;
  if(strcmp(OUT2BUF, "d-\n") == 0)
    disc--;


  if(strcmp(OUT2BUF, "stop\n") == 0) {
    ET0 = 0;
    prints("cd emulator timer disabled\n");
  }

  if(strcmp(OUT2BUF, "mix\n") == 0) {
    if(mix) {
      prints("mix off\n");
      mix = 0;
    }
    else {
      prints("mix on\n");
      mix = 1;
    }
  }

  if(strcmp(OUT2BUF, "scan\n") == 0) {
    if(scan) {
      prints("scan off\n");
      scan = 0;
    }
    else {
      prints("scan on\n");
      scan = 1;
    }
  }

  if(strcmp(OUT2BUF, "go\n") == 0) {
    ET0 = 1;
    prints("cd emulator timer enabled\n");
  }

  if(strcmp(OUT2BUF, "status\n") == 0) {
    unsigned char i, v;
    prints("EZ USB Status...\n");

    prints("Port A: ");
    v = IOA;
    for(i = 0; i < 8; i++) {
      prints((v & 0x80) ? "1":"0");
      v <<= 1;
    }
    prints("\n");

    prints("Port B: ");
    v = IOB;
    for(i = 0; i < 8; i++) {
      prints((v & 0x80) ? "1":"0");
      v <<= 1;
    }
    prints("\n");

    prints("Port C: ");
    v = IOC;
    for(i = 0; i < 8; i++) {
      prints((v & 0x80) ? "1":"0");
      v <<= 1;
    }
    prints("\n");

    prints("Port D: ");
    v = IOD;
    for(i = 0; i < 8; i++) {
      prints((v & 0x80) ? "1":"0");
      v <<= 1;
    }
    prints("\n");
  }
  
  if(strcmp(OUT2BUF, "\n") == 0)
    prints("commands: id status\n");

  printDone();
  // re-arm the endpoint so we can receive the next command
  OUT2BC = 0;
}

// send a string back to the host through EP2IN
signed char prints(char *s) {
  unsigned char i;
  
  // make sure EP2IN is available before screwing around with it
  for(i = 1; i; i++) {
    if((IN2CS & 2) == 0)
      break;

    msecWait(10);
  }
  if(IN2CS & EPBUSY)
    return -1;   // EP2IN is busy, we skipped sending the data

  IN2BUF[0] = 1; // flag host that we're sending a string
  for(i = 0; i < 63; i++) {
    IN2BUF[i+1] = s[i];
    if(s[i] == 0)
      break;
  }

  IN2BC = 64;
  return 0;
}

signed char printn(unsigned int val) {
  unsigned char i;
  
  // make sure EP2IN is available before screwing around with it
  for(i = 1; i; i++) {
    if((IN2CS & 2) == 0)
      break;

    msecWait(10);
  }
  if(IN2CS & EPBUSY)
    return -1;   // EP2IN is busy, we skipped sending the data

  IN2BUF[0] = 2; // flag host that we're sending an integer
  IN2BUF[1] = val;
  IN2BUF[2] = val >> 8;
  IN2BC = 64;
  return 0;
}

signed char printDone(void) {
  unsigned char i;
  
  // make sure EP2IN is available before screwing around with it
  for(i = 1; i; i++) {
    if((IN2CS & 2) == 0)
      break;

    msecWait(10);
  }
  if(IN2CS & EPBUSY)
    return -1;   // EP2IN is busy, we skipped sending the data

  IN2BUF[0] = 0; // flag host that we're done
  IN2BC = 64;
  return 0;
}
