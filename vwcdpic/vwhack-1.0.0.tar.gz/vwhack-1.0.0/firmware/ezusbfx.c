// EZ USB FX Standard Library
// Copyright (c) 2001, Ed Schlunder <zilym@yahoo.com>

#include "ezusbfx.h"

// instruction cycles are 4 clock cycles in length on EZUSB FX

// 48MHz Clock = (1/48e6) * 4 = 83.33ns per Instruction Cycle
// 1ms = 1ms/(83.33ns * 10 cycles) = 1200 loop iterations
void msecWait48MHz(void) {
  _asm
    mov     dptr,#(0xFFFF - 1200)
  00001$:                   ; 10 instruction cycles per loop iteration 
    inc     dptr            ; 3 Instruction Cycles
    mov     a,dpl           ; 2 Instruction Cycles
    orl     a,dph           ; 2 Instruction Cycles
    jnz     00001$          ; 3 Instruction Cycles
  _endasm;
}

// 24MHz Clock = (1/24e6) * 4 = 166.66ns per Instruction Cycle
// 1ms = 1ms/(166.66ns * 10 cycles) = 600 loop iterations
void msecWait24MHz(void) {
  _asm
    mov     dptr,#(0xFFFF - 600)
  00001$:                   ; 10 instruction cycles per loop iteration 
    inc     dptr            ; 3 Instruction Cycles
    mov     a,dpl           ; 2 Instruction Cycles
    orl     a,dph           ; 2 Instruction Cycles
    jnz     00001$          ; 3 Instruction Cycles
  _endasm;
}

// waits msec milliseconds by checking our current clock speed
void msecWait(unsigned int msec) {
  if(CPUCS & CLK2448)
    while(msec--)
      msecWait48MHz();
  else
    while(msec--)
      msecWait24MHz();
}

// assumes that you've already set the I2CS START bit beforehand
unsigned char i2cWrite(unsigned char d) {
  // send data
  I2DAT = d;
  while((I2CS & I2DONE) == 0);

  // did we recieve the ACK from the slave?
  if((I2CS & I2BERR) || (I2CS & I2ACK) == 0) {
    I2CS = I2STOP;  // no, stop I2C transfer and abort
    return 1;
  }
 
  return 0;
}

// first byte read from slave will be garbage and should be discarded
// before reading second to last byte from slave, set LASTRD bit of I2CS
// last byte of data has to be read directly from I2DAT (don't use i2cRead())
// immediately after setting the STOP bit of I2CS.
int i2cRead(void) {
  unsigned char dat;
  dat = I2DAT;
  while((I2CS & I2DONE) == 0);

  // did we recieve any errors?
  if(I2CS & I2BERR) {
    I2CS = I2STOP;  // yes, stop I2C transfer and abort
    return -1;
  }

  return dat;
}

