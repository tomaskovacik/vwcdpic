// Volkswagen CD Changer Emulator Firmware
// Copyright (c) 2001, Ed Schlunder <zilym@yahoo.com>

extern idata unsigned char volatile disc, track, mix, scan;
extern unsigned char volatile timeCount;

