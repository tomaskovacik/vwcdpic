                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : FreeWare ANSI-C Compiler
                              3 ; Version 2.2.2 Tue Apr 17 02:00:28 2001
                              4 
                              5 ;--------------------------------------------------------
                              6 	.module usb
                              7 	
                              8 ;--------------------------------------------------------
                              9 ; Public variables in this module
                             10 ;--------------------------------------------------------
                             11 	.globl _IVEC
                             12 	.globl _IN2CS
                             13 	.globl _OUT2BUF
                             14 	.globl _IN2BUF
                             15 	.globl _CPUCS
                             16 	.globl _initUSB
                             17 	.globl _intUSB
                             18 	.globl _ep2outUSB
                             19 	.globl _prints
                             20 	.globl _printn
                             21 	.globl _printDone
                             22 ;--------------------------------------------------------
                             23 ; special function registers
                             24 ;--------------------------------------------------------
                    0081     25 G$SP$0$0 == 0x0081
                    0081     26 _SP	=	0x0081
                    0082     27 G$DPL$0$0 == 0x0082
                    0082     28 _DPL	=	0x0082
                    0083     29 G$DPH$0$0 == 0x0083
                    0083     30 _DPH	=	0x0083
                    0082     31 G$DPL0$0$0 == 0x0082
                    0082     32 _DPL0	=	0x0082
                    0083     33 G$DPH0$0$0 == 0x0083
                    0083     34 _DPH0	=	0x0083
                    0084     35 G$DPL1$0$0 == 0x0084
                    0084     36 _DPL1	=	0x0084
                    0085     37 G$DPH1$0$0 == 0x0085
                    0085     38 _DPH1	=	0x0085
                    0086     39 G$DPS$0$0 == 0x0086
                    0086     40 _DPS	=	0x0086
                    008E     41 G$CKCON$0$0 == 0x008e
                    008E     42 _CKCON	=	0x008e
                    00A2     43 G$INT4CLR$0$0 == 0x00a2
                    00A2     44 _INT4CLR	=	0x00a2
                    00F8     45 G$EIP$0$0 == 0x00f8
                    00F8     46 _EIP	=	0x00f8
                    0087     47 G$PCON$0$0 == 0x0087
                    0087     48 _PCON	=	0x0087
                    0088     49 G$TCON$0$0 == 0x0088
                    0088     50 _TCON	=	0x0088
                    0080     51 G$IOA$0$0 == 0x0080
                    0080     52 _IOA	=	0x0080
                    0090     53 G$IOB$0$0 == 0x0090
                    0090     54 _IOB	=	0x0090
                    00A0     55 G$IOC$0$0 == 0x00a0
                    00A0     56 _IOC	=	0x00a0
                    00B0     57 G$IOD$0$0 == 0x00b0
                    00B0     58 _IOD	=	0x00b0
                    00B1     59 G$IOE$0$0 == 0x00b1
                    00B1     60 _IOE	=	0x00b1
                    0089     61 G$TMOD$0$0 == 0x0089
                    0089     62 _TMOD	=	0x0089
                    008A     63 G$TL0$0$0 == 0x008a
                    008A     64 _TL0	=	0x008a
                    008B     65 G$TL1$0$0 == 0x008b
                    008B     66 _TL1	=	0x008b
                    008C     67 G$TH0$0$0 == 0x008c
                    008C     68 _TH0	=	0x008c
                    008D     69 G$TH1$0$0 == 0x008d
                    008D     70 _TH1	=	0x008d
                    008F     71 G$SPC_FNC$0$0 == 0x008f
                    008F     72 _SPC_FNC	=	0x008f
                    0091     73 G$EXIF$0$0 == 0x0091
                    0091     74 _EXIF	=	0x0091
                    0092     75 G$MPAGE$0$0 == 0x0092
                    0092     76 _MPAGE	=	0x0092
                    0098     77 G$SCON0$0$0 == 0x0098
                    0098     78 _SCON0	=	0x0098
                    0099     79 G$SBUF0$0$0 == 0x0099
                    0099     80 _SBUF0	=	0x0099
                    00A8     81 G$IE$0$0 == 0x00a8
                    00A8     82 _IE	=	0x00a8
                    00B8     83 G$IP$0$0 == 0x00b8
                    00B8     84 _IP	=	0x00b8
                    00C0     85 G$SCON1$0$0 == 0x00c0
                    00C0     86 _SCON1	=	0x00c0
                    00C1     87 G$SBUF1$0$0 == 0x00c1
                    00C1     88 _SBUF1	=	0x00c1
                    00C8     89 G$T2CON$0$0 == 0x00c8
                    00C8     90 _T2CON	=	0x00c8
                    00CA     91 G$RCAP2L$0$0 == 0x00ca
                    00CA     92 _RCAP2L	=	0x00ca
                    00CB     93 G$RCAP2H$0$0 == 0x00cb
                    00CB     94 _RCAP2H	=	0x00cb
                    00CC     95 G$TL2$0$0 == 0x00cc
                    00CC     96 _TL2	=	0x00cc
                    00CD     97 G$TH2$0$0 == 0x00cd
                    00CD     98 _TH2	=	0x00cd
                    00D0     99 G$PSW$0$0 == 0x00d0
                    00D0    100 _PSW	=	0x00d0
                    00D8    101 G$EICON$0$0 == 0x00d8
                    00D8    102 _EICON	=	0x00d8
                    00E0    103 G$ACC$0$0 == 0x00e0
                    00E0    104 _ACC	=	0x00e0
                    00E8    105 G$EIE$0$0 == 0x00e8
                    00E8    106 _EIE	=	0x00e8
                    00F0    107 G$B$0$0 == 0x00f0
                    00F0    108 _B	=	0x00f0
                            109 ;--------------------------------------------------------
                            110 ; special function bits 
                            111 ;--------------------------------------------------------
                    00FC    112 G$PX6$0$0 == 0x00fc
                    00FC    113 _PX6	=	0x00fc
                    00FB    114 G$PX5$0$0 == 0x00fb
                    00FB    115 _PX5	=	0x00fb
                    00FA    116 G$PX4$0$0 == 0x00fa
                    00FA    117 _PX4	=	0x00fa
                    00F9    118 G$PI2C$0$0 == 0x00f9
                    00F9    119 _PI2C	=	0x00f9
                    00F8    120 G$PUSB$0$0 == 0x00f8
                    00F8    121 _PUSB	=	0x00f8
                    008F    122 G$TF1$0$0 == 0x008f
                    008F    123 _TF1	=	0x008f
                    008E    124 G$TR1$0$0 == 0x008e
                    008E    125 _TR1	=	0x008e
                    008D    126 G$TF0$0$0 == 0x008d
                    008D    127 _TF0	=	0x008d
                    008C    128 G$TR0$0$0 == 0x008c
                    008C    129 _TR0	=	0x008c
                    008B    130 G$IE1$0$0 == 0x008b
                    008B    131 _IE1	=	0x008b
                    008A    132 G$IT1$0$0 == 0x008a
                    008A    133 _IT1	=	0x008a
                    0089    134 G$IE0$0$0 == 0x0089
                    0089    135 _IE0	=	0x0089
                    0088    136 G$IT0$0$0 == 0x0088
                    0088    137 _IT0	=	0x0088
                    0080    138 G$IOA_0$0$0 == 0x0080
                    0080    139 _IOA_0	=	0x0080
                    0081    140 G$IOA_1$0$0 == 0x0081
                    0081    141 _IOA_1	=	0x0081
                    0082    142 G$IOA_2$0$0 == 0x0082
                    0082    143 _IOA_2	=	0x0082
                    0083    144 G$IOA_3$0$0 == 0x0083
                    0083    145 _IOA_3	=	0x0083
                    0084    146 G$IOA_4$0$0 == 0x0084
                    0084    147 _IOA_4	=	0x0084
                    0085    148 G$IOA_5$0$0 == 0x0085
                    0085    149 _IOA_5	=	0x0085
                    0086    150 G$IOA_6$0$0 == 0x0086
                    0086    151 _IOA_6	=	0x0086
                    0087    152 G$IOA_7$0$0 == 0x0087
                    0087    153 _IOA_7	=	0x0087
                    0090    154 G$IOB_0$0$0 == 0x0090
                    0090    155 _IOB_0	=	0x0090
                    0091    156 G$IOB_1$0$0 == 0x0091
                    0091    157 _IOB_1	=	0x0091
                    0092    158 G$IOB_2$0$0 == 0x0092
                    0092    159 _IOB_2	=	0x0092
                    0093    160 G$IOB_3$0$0 == 0x0093
                    0093    161 _IOB_3	=	0x0093
                    0094    162 G$IOB_4$0$0 == 0x0094
                    0094    163 _IOB_4	=	0x0094
                    0095    164 G$IOB_5$0$0 == 0x0095
                    0095    165 _IOB_5	=	0x0095
                    0096    166 G$IOB_6$0$0 == 0x0096
                    0096    167 _IOB_6	=	0x0096
                    0097    168 G$IOB_7$0$0 == 0x0097
                    0097    169 _IOB_7	=	0x0097
                    00A0    170 G$IOC_0$0$0 == 0x00a0
                    00A0    171 _IOC_0	=	0x00a0
                    00A1    172 G$IOC_1$0$0 == 0x00a1
                    00A1    173 _IOC_1	=	0x00a1
                    00A2    174 G$IOC_2$0$0 == 0x00a2
                    00A2    175 _IOC_2	=	0x00a2
                    00A3    176 G$IOC_3$0$0 == 0x00a3
                    00A3    177 _IOC_3	=	0x00a3
                    00A4    178 G$IOC_4$0$0 == 0x00a4
                    00A4    179 _IOC_4	=	0x00a4
                    00A5    180 G$IOC_5$0$0 == 0x00a5
                    00A5    181 _IOC_5	=	0x00a5
                    00A6    182 G$IOC_6$0$0 == 0x00a6
                    00A6    183 _IOC_6	=	0x00a6
                    00A7    184 G$IOC_7$0$0 == 0x00a7
                    00A7    185 _IOC_7	=	0x00a7
                    00B0    186 G$IOD_0$0$0 == 0x00b0
                    00B0    187 _IOD_0	=	0x00b0
                    00B1    188 G$IOD_1$0$0 == 0x00b1
                    00B1    189 _IOD_1	=	0x00b1
                    00B2    190 G$IOD_2$0$0 == 0x00b2
                    00B2    191 _IOD_2	=	0x00b2
                    00B3    192 G$IOD_3$0$0 == 0x00b3
                    00B3    193 _IOD_3	=	0x00b3
                    00B4    194 G$IOD_4$0$0 == 0x00b4
                    00B4    195 _IOD_4	=	0x00b4
                    00B5    196 G$IOD_5$0$0 == 0x00b5
                    00B5    197 _IOD_5	=	0x00b5
                    00B6    198 G$IOD_6$0$0 == 0x00b6
                    00B6    199 _IOD_6	=	0x00b6
                    00B7    200 G$IOD_7$0$0 == 0x00b7
                    00B7    201 _IOD_7	=	0x00b7
                    009F    202 G$SM0_0$0$0 == 0x009f
                    009F    203 _SM0_0	=	0x009f
                    009E    204 G$SM1_0$0$0 == 0x009e
                    009E    205 _SM1_0	=	0x009e
                    009D    206 G$SM2_0$0$0 == 0x009d
                    009D    207 _SM2_0	=	0x009d
                    009C    208 G$REN_0$0$0 == 0x009c
                    009C    209 _REN_0	=	0x009c
                    009B    210 G$TB8_0$0$0 == 0x009b
                    009B    211 _TB8_0	=	0x009b
                    009A    212 G$RB8_0$0$0 == 0x009a
                    009A    213 _RB8_0	=	0x009a
                    0099    214 G$TI_0$0$0 == 0x0099
                    0099    215 _TI_0	=	0x0099
                    0098    216 G$RI_0$0$0 == 0x0098
                    0098    217 _RI_0	=	0x0098
                    00AF    218 G$EA$0$0 == 0x00af
                    00AF    219 _EA	=	0x00af
                    00AE    220 G$ES1$0$0 == 0x00ae
                    00AE    221 _ES1	=	0x00ae
                    00AD    222 G$ET2$0$0 == 0x00ad
                    00AD    223 _ET2	=	0x00ad
                    00AC    224 G$ES0$0$0 == 0x00ac
                    00AC    225 _ES0	=	0x00ac
                    00AB    226 G$ET1$0$0 == 0x00ab
                    00AB    227 _ET1	=	0x00ab
                    00AA    228 G$EX1$0$0 == 0x00aa
                    00AA    229 _EX1	=	0x00aa
                    00A9    230 G$ET0$0$0 == 0x00a9
                    00A9    231 _ET0	=	0x00a9
                    00A8    232 G$EX0$0$0 == 0x00a8
                    00A8    233 _EX0	=	0x00a8
                    00BE    234 G$PS1$0$0 == 0x00be
                    00BE    235 _PS1	=	0x00be
                    00BD    236 G$PT2$0$0 == 0x00bd
                    00BD    237 _PT2	=	0x00bd
                    00BC    238 G$PS0$0$0 == 0x00bc
                    00BC    239 _PS0	=	0x00bc
                    00BB    240 G$PT1$0$0 == 0x00bb
                    00BB    241 _PT1	=	0x00bb
                    00BA    242 G$PX1$0$0 == 0x00ba
                    00BA    243 _PX1	=	0x00ba
                    00B9    244 G$PT0$0$0 == 0x00b9
                    00B9    245 _PT0	=	0x00b9
                    00B8    246 G$PX0$0$0 == 0x00b8
                    00B8    247 _PX0	=	0x00b8
                    00C7    248 G$SM0_1$0$0 == 0x00c7
                    00C7    249 _SM0_1	=	0x00c7
                    00C6    250 G$SM1_1$0$0 == 0x00c6
                    00C6    251 _SM1_1	=	0x00c6
                    00C5    252 G$SM2_1$0$0 == 0x00c5
                    00C5    253 _SM2_1	=	0x00c5
                    00C4    254 G$REN_1$0$0 == 0x00c4
                    00C4    255 _REN_1	=	0x00c4
                    00C3    256 G$TB8_1$0$0 == 0x00c3
                    00C3    257 _TB8_1	=	0x00c3
                    00C2    258 G$RB8_1$0$0 == 0x00c2
                    00C2    259 _RB8_1	=	0x00c2
                    00C1    260 G$TI_1$0$0 == 0x00c1
                    00C1    261 _TI_1	=	0x00c1
                    00C0    262 G$RI_1$0$0 == 0x00c0
                    00C0    263 _RI_1	=	0x00c0
                    00CF    264 G$TF2$0$0 == 0x00cf
                    00CF    265 _TF2	=	0x00cf
                    00CE    266 G$EXF2$0$0 == 0x00ce
                    00CE    267 _EXF2	=	0x00ce
                    00CD    268 G$RCLK$0$0 == 0x00cd
                    00CD    269 _RCLK	=	0x00cd
                    00CC    270 G$TCLK$0$0 == 0x00cc
                    00CC    271 _TCLK	=	0x00cc
                    00CB    272 G$EXEN2$0$0 == 0x00cb
                    00CB    273 _EXEN2	=	0x00cb
                    00CA    274 G$TR2$0$0 == 0x00ca
                    00CA    275 _TR2	=	0x00ca
                    00C9    276 G$CT2$0$0 == 0x00c9
                    00C9    277 _CT2	=	0x00c9
                    00C8    278 G$CPRL2$0$0 == 0x00c8
                    00C8    279 _CPRL2	=	0x00c8
                    00D7    280 G$CY$0$0 == 0x00d7
                    00D7    281 _CY	=	0x00d7
                    00D6    282 G$AC$0$0 == 0x00d6
                    00D6    283 _AC	=	0x00d6
                    00D5    284 G$F0$0$0 == 0x00d5
                    00D5    285 _F0	=	0x00d5
                    00D4    286 G$RS1$0$0 == 0x00d4
                    00D4    287 _RS1	=	0x00d4
                    00D3    288 G$RS0$0$0 == 0x00d3
                    00D3    289 _RS0	=	0x00d3
                    00D2    290 G$OV$0$0 == 0x00d2
                    00D2    291 _OV	=	0x00d2
                    00D0    292 G$P$0$0 == 0x00d0
                    00D0    293 _P	=	0x00d0
                    00DF    294 G$SMOD1$0$0 == 0x00df
                    00DF    295 _SMOD1	=	0x00df
                    00DD    296 G$ERESI$0$0 == 0x00dd
                    00DD    297 _ERESI	=	0x00dd
                    00DC    298 G$RESI$0$0 == 0x00dc
                    00DC    299 _RESI	=	0x00dc
                    00DB    300 G$INT6$0$0 == 0x00db
                    00DB    301 _INT6	=	0x00db
                    00EC    302 G$EWDI$0$0 == 0x00ec
                    00EC    303 _EWDI	=	0x00ec
                    00EB    304 G$EX5$0$0 == 0x00eb
                    00EB    305 _EX5	=	0x00eb
                    00EA    306 G$EX4$0$0 == 0x00ea
                    00EA    307 _EX4	=	0x00ea
                    00E9    308 G$EI2C$0$0 == 0x00e9
                    00E9    309 _EI2C	=	0x00e9
                    00E8    310 G$EUSB$0$0 == 0x00e8
                    00E8    311 _EUSB	=	0x00e8
                            312 ;--------------------------------------------------------
                            313 ; internal ram data
                            314 ;--------------------------------------------------------
                            315 	.area DSEG    (DATA)
                            316 ;--------------------------------------------------------
                            317 ; overlayable items in internal ram 
                            318 ;--------------------------------------------------------
                            319 	.area OSEG    (OVR,DATA)
                            320 ;--------------------------------------------------------
                            321 ; indirectly addressable internal ram data
                            322 ;--------------------------------------------------------
                            323 	.area ISEG    (DATA)
                            324 ;--------------------------------------------------------
                            325 ; bit data
                            326 ;--------------------------------------------------------
                            327 	.area BSEG    (BIT)
                            328 ;--------------------------------------------------------
                            329 ; external ram data
                            330 ;--------------------------------------------------------
                            331 	.area XSEG    (XDATA)
                    7800    332 G$AINDATA$0$0 == 0x7800
                    7800    333 _AINDATA	=	0x7800
                    7801    334 G$AINBC$0$0 == 0x7801
                    7801    335 _AINBC	=	0x7801
                    7802    336 G$AINPF$0$0 == 0x7802
                    7802    337 _AINPF	=	0x7802
                    7803    338 G$AINPFPIN$0$0 == 0x7803
                    7803    339 _AINPFPIN	=	0x7803
                    7805    340 G$BINDATA$0$0 == 0x7805
                    7805    341 _BINDATA	=	0x7805
                    7806    342 G$BINBC$0$0 == 0x7806
                    7806    343 _BINBC	=	0x7806
                    7807    344 G$BINPF$0$0 == 0x7807
                    7807    345 _BINPF	=	0x7807
                    7808    346 G$BINPFPIN$0$0 == 0x7808
                    7808    347 _BINPFPIN	=	0x7808
                    780A    348 G$ABINTF$0$0 == 0x780a
                    780A    349 _ABINTF	=	0x780a
                    780B    350 G$ABINIE$0$0 == 0x780b
                    780B    351 _ABINIE	=	0x780b
                    780C    352 G$ABINIRQ$0$0 == 0x780c
                    780C    353 _ABINIRQ	=	0x780c
                    780E    354 G$AOUTDATA$0$0 == 0x780e
                    780E    355 _AOUTDATA	=	0x780e
                    780F    356 G$AOUTBC$0$0 == 0x780f
                    780F    357 _AOUTBC	=	0x780f
                    7810    358 G$AOUTPF$0$0 == 0x7810
                    7810    359 _AOUTPF	=	0x7810
                    7811    360 G$AOUTPFPIN$0$0 == 0x7811
                    7811    361 _AOUTPFPIN	=	0x7811
                    7813    362 G$BOUTDATA$0$0 == 0x7813
                    7813    363 _BOUTDATA	=	0x7813
                    7814    364 G$BOUTBC$0$0 == 0x7814
                    7814    365 _BOUTBC	=	0x7814
                    7815    366 G$BOUTPF$0$0 == 0x7815
                    7815    367 _BOUTPF	=	0x7815
                    7816    368 G$BOUTPFPIN$0$0 == 0x7816
                    7816    369 _BOUTPFPIN	=	0x7816
                    7818    370 G$ABOUTTF$0$0 == 0x7818
                    7818    371 _ABOUTTF	=	0x7818
                    7819    372 G$ABOUTIE$0$0 == 0x7819
                    7819    373 _ABOUTIE	=	0x7819
                    781A    374 G$ABOUTIRQ$0$0 == 0x781a
                    781A    375 _ABOUTIRQ	=	0x781a
                    781C    376 G$ABSETUP$0$0 == 0x781c
                    781C    377 _ABSETUP	=	0x781c
                    781D    378 G$ABPOLAR$0$0 == 0x781d
                    781D    379 _ABPOLAR	=	0x781d
                    781E    380 G$ABFLUSH$0$0 == 0x781e
                    781E    381 _ABFLUSH	=	0x781e
                    7824    382 G$WFSELECT$0$0 == 0x7824
                    7824    383 _WFSELECT	=	0x7824
                    7825    384 G$IDLE_CS$0$0 == 0x7825
                    7825    385 _IDLE_CS	=	0x7825
                    7826    386 G$IDLE_CTLOUT$0$0 == 0x7826
                    7826    387 _IDLE_CTLOUT	=	0x7826
                    7827    388 G$CTLOUTCFG$0$0 == 0x7827
                    7827    389 _CTLOUTCFG	=	0x7827
                    782A    390 G$GPIFADRL$0$0 == 0x782a
                    782A    391 _GPIFADRL	=	0x782a
                    7900    392 G$WFDESC$0$0 == 0x7900
                    7900    393 _WFDESC	=	0x7900
                    7900    394 G$WFDESC0$0$0 == 0x7900
                    7900    395 _WFDESC0	=	0x7900
                    7920    396 G$WFDESC1$0$0 == 0x7920
                    7920    397 _WFDESC1	=	0x7920
                    7940    398 G$WFDESC2$0$0 == 0x7940
                    7940    399 _WFDESC2	=	0x7940
                    7960    400 G$WFDESC3$0$0 == 0x7960
                    7960    401 _WFDESC3	=	0x7960
                    782C    402 G$AINTC$0$0 == 0x782c
                    782C    403 _AINTC	=	0x782c
                    782D    404 G$AOUTTC$0$0 == 0x782d
                    782D    405 _AOUTTC	=	0x782d
                    782E    406 G$ATRIG$0$0 == 0x782e
                    782E    407 _ATRIG	=	0x782e
                    7830    408 G$BINTC$0$0 == 0x7830
                    7830    409 _BINTC	=	0x7830
                    7831    410 G$BOUTTC$0$0 == 0x7831
                    7831    411 _BOUTTC	=	0x7831
                    7832    412 G$BTRIG$0$0 == 0x7832
                    7832    413 _BTRIG	=	0x7832
                    7834    414 G$SGLDATH$0$0 == 0x7834
                    7834    415 _SGLDATH	=	0x7834
                    7835    416 G$SGLDATLTRIG$0$0 == 0x7835
                    7835    417 _SGLDATLTRIG	=	0x7835
                    7836    418 G$SGLDATLNTRIG$0$0 == 0x7836
                    7836    419 _SGLDATLNTRIG	=	0x7836
                    7838    420 G$READY$0$0 == 0x7838
                    7838    421 _READY	=	0x7838
                    7839    422 G$ABORT$0$0 == 0x7839
                    7839    423 _ABORT	=	0x7839
                    783B    424 G$GENIE$0$0 == 0x783b
                    783B    425 _GENIE	=	0x783b
                    783C    426 G$GENIRQ$0$0 == 0x783c
                    783C    427 _GENIRQ	=	0x783c
                    784A    428 G$IFCONFIG$0$0 == 0x784a
                    784A    429 _IFCONFIG	=	0x784a
                    7FE3    430 G$AUTOPTRH$0$0 == 0x7fe3
                    7FE3    431 _AUTOPTRH	=	0x7fe3
                    7FE4    432 G$AUTOPTRL$0$0 == 0x7fe4
                    7FE4    433 _AUTOPTRL	=	0x7fe4
                    7FE5    434 G$AUTODATA$0$0 == 0x7fe5
                    7FE5    435 _AUTODATA	=	0x7fe5
                    7F96    436 G$OUTA$0$0 == 0x7f96
                    7F96    437 _OUTA	=	0x7f96
                    7F97    438 G$OUTB$0$0 == 0x7f97
                    7F97    439 _OUTB	=	0x7f97
                    7F98    440 G$OUTC$0$0 == 0x7f98
                    7F98    441 _OUTC	=	0x7f98
                    7841    442 G$OUTD$0$0 == 0x7841
                    7841    443 _OUTD	=	0x7841
                    7845    444 G$OUTE$0$0 == 0x7845
                    7845    445 _OUTE	=	0x7845
                    7F99    446 G$PINSA$0$0 == 0x7f99
                    7F99    447 _PINSA	=	0x7f99
                    7F9A    448 G$PINSB$0$0 == 0x7f9a
                    7F9A    449 _PINSB	=	0x7f9a
                    7F9B    450 G$PINSC$0$0 == 0x7f9b
                    7F9B    451 _PINSC	=	0x7f9b
                    7842    452 G$PINSD$0$0 == 0x7842
                    7842    453 _PINSD	=	0x7842
                    7846    454 G$PINSE$0$0 == 0x7846
                    7846    455 _PINSE	=	0x7846
                    7F9C    456 G$OEA$0$0 == 0x7f9c
                    7F9C    457 _OEA	=	0x7f9c
                    7F9D    458 G$OEB$0$0 == 0x7f9d
                    7F9D    459 _OEB	=	0x7f9d
                    7F9E    460 G$OEC$0$0 == 0x7f9e
                    7F9E    461 _OEC	=	0x7f9e
                    7843    462 G$OED$0$0 == 0x7843
                    7843    463 _OED	=	0x7843
                    7847    464 G$OEE$0$0 == 0x7847
                    7847    465 _OEE	=	0x7847
                    7F93    466 G$PORTACFG$0$0 == 0x7f93
                    7F93    467 _PORTACFG	=	0x7f93
                    7F94    468 G$PORTBCFG$0$0 == 0x7f94
                    7F94    469 _PORTBCFG	=	0x7f94
                    7F95    470 G$PORTCCFG$0$0 == 0x7f95
                    7F95    471 _PORTCCFG	=	0x7f95
                    784C    472 G$PORTCCF2$0$0 == 0x784c
                    784C    473 _PORTCCF2	=	0x784c
                    7849    474 G$PORTSETUP$0$0 == 0x7849
                    7849    475 _PORTSETUP	=	0x7849
                    785D    476 G$INT4IVEC$0$0 == 0x785d
                    785D    477 _INT4IVEC	=	0x785d
                    785E    478 G$INT4SETUP$0$0 == 0x785e
                    785E    479 _INT4SETUP	=	0x785e
                    784F    480 G$DMASRCH$0$0 == 0x784f
                    784F    481 _DMASRCH	=	0x784f
                    7850    482 G$DMASRCL$0$0 == 0x7850
                    7850    483 _DMASRCL	=	0x7850
                    7851    484 G$DMADESTH$0$0 == 0x7851
                    7851    485 _DMADESTH	=	0x7851
                    7852    486 G$DMADESTL$0$0 == 0x7852
                    7852    487 _DMADESTL	=	0x7852
                    7857    488 G$DMABURST$0$0 == 0x7857
                    7857    489 _DMABURST	=	0x7857
                    7854    490 G$DMALEN$0$0 == 0x7854
                    7854    491 _DMALEN	=	0x7854
                    7855    492 G$DMAGO$0$0 == 0x7855
                    7855    493 _DMAGO	=	0x7855
                    7FA6    494 G$I2DAT$0$0 == 0x7fa6
                    7FA6    495 _I2DAT	=	0x7fa6
                    7FA5    496 G$I2CS$0$0 == 0x7fa5
                    7FA5    497 _I2CS	=	0x7fa5
                    7FA7    498 G$I2CMODE$0$0 == 0x7fa7
                    7FA7    499 _I2CMODE	=	0x7fa7
                    7F92    500 G$CPUCS$0$0 == 0x7f92
                    7F92    501 _CPUCS	=	0x7f92
                    7FA0    502 G$ISOERR$0$0 == 0x7fa0
                    7FA0    503 _ISOERR	=	0x7fa0
                    7FA1    504 G$ISOCTL$0$0 == 0x7fa1
                    7FA1    505 _ISOCTL	=	0x7fa1
                    7FA2    506 G$ZBCOUNT$0$0 == 0x7fa2
                    7FA2    507 _ZBCOUNT	=	0x7fa2
                    7F00    508 G$IN0BUF$0$0 == 0x7f00
                    7F00    509 _IN0BUF	=	0x7f00
                    7EC0    510 G$OUT0BUF$0$0 == 0x7ec0
                    7EC0    511 _OUT0BUF	=	0x7ec0
                    7E80    512 G$IN1BUF$0$0 == 0x7e80
                    7E80    513 _IN1BUF	=	0x7e80
                    7E40    514 G$OUT1BUF$0$0 == 0x7e40
                    7E40    515 _OUT1BUF	=	0x7e40
                    7E00    516 G$IN2BUF$0$0 == 0x7e00
                    7E00    517 _IN2BUF	=	0x7e00
                    7DC0    518 G$OUT2BUF$0$0 == 0x7dc0
                    7DC0    519 _OUT2BUF	=	0x7dc0
                    7D80    520 G$IN3BUF$0$0 == 0x7d80
                    7D80    521 _IN3BUF	=	0x7d80
                    7D40    522 G$OUT3BUF$0$0 == 0x7d40
                    7D40    523 _OUT3BUF	=	0x7d40
                    7D00    524 G$IN4BUF$0$0 == 0x7d00
                    7D00    525 _IN4BUF	=	0x7d00
                    7CC0    526 G$OUT4BUF$0$0 == 0x7cc0
                    7CC0    527 _OUT4BUF	=	0x7cc0
                    7C80    528 G$IN5BUF$0$0 == 0x7c80
                    7C80    529 _IN5BUF	=	0x7c80
                    7C40    530 G$OUT5BUF$0$0 == 0x7c40
                    7C40    531 _OUT5BUF	=	0x7c40
                    7C00    532 G$IN6BUF$0$0 == 0x7c00
                    7C00    533 _IN6BUF	=	0x7c00
                    7BC0    534 G$OUT6BUF$0$0 == 0x7bc0
                    7BC0    535 _OUT6BUF	=	0x7bc0
                    7B80    536 G$IN7BUF$0$0 == 0x7b80
                    7B80    537 _IN7BUF	=	0x7b80
                    7B40    538 G$OUT7BUF$0$0 == 0x7b40
                    7B40    539 _OUT7BUF	=	0x7b40
                    7FE8    540 G$SETUPBUF$0$0 == 0x7fe8
                    7FE8    541 _SETUPBUF	=	0x7fe8
                    7FE8    542 G$SETUPDAT$0$0 == 0x7fe8
                    7FE8    543 _SETUPDAT	=	0x7fe8
                    7FB4    544 G$EP0CS$0$0 == 0x7fb4
                    7FB4    545 _EP0CS	=	0x7fb4
                    7FB5    546 G$IN0BC$0$0 == 0x7fb5
                    7FB5    547 _IN0BC	=	0x7fb5
                    7FB6    548 G$IN1CS$0$0 == 0x7fb6
                    7FB6    549 _IN1CS	=	0x7fb6
                    7FB7    550 G$IN1BC$0$0 == 0x7fb7
                    7FB7    551 _IN1BC	=	0x7fb7
                    7FB8    552 G$IN2CS$0$0 == 0x7fb8
                    7FB8    553 _IN2CS	=	0x7fb8
                    7FB9    554 G$IN2BC$0$0 == 0x7fb9
                    7FB9    555 _IN2BC	=	0x7fb9
                    7FBA    556 G$IN3CS$0$0 == 0x7fba
                    7FBA    557 _IN3CS	=	0x7fba
                    7FBB    558 G$IN3BC$0$0 == 0x7fbb
                    7FBB    559 _IN3BC	=	0x7fbb
                    7FBC    560 G$IN4CS$0$0 == 0x7fbc
                    7FBC    561 _IN4CS	=	0x7fbc
                    7FBD    562 G$IN4BC$0$0 == 0x7fbd
                    7FBD    563 _IN4BC	=	0x7fbd
                    7FBE    564 G$IN5CS$0$0 == 0x7fbe
                    7FBE    565 _IN5CS	=	0x7fbe
                    7FBF    566 G$IN5BC$0$0 == 0x7fbf
                    7FBF    567 _IN5BC	=	0x7fbf
                    7FC0    568 G$IN6CS$0$0 == 0x7fc0
                    7FC0    569 _IN6CS	=	0x7fc0
                    7FC1    570 G$IN6BC$0$0 == 0x7fc1
                    7FC1    571 _IN6BC	=	0x7fc1
                    7FC2    572 G$IN7CS$0$0 == 0x7fc2
                    7FC2    573 _IN7CS	=	0x7fc2
                    7FC3    574 G$IN7BC$0$0 == 0x7fc3
                    7FC3    575 _IN7BC	=	0x7fc3
                    7FC5    576 G$OUT0BC$0$0 == 0x7fc5
                    7FC5    577 _OUT0BC	=	0x7fc5
                    7FC6    578 G$OUT1CS$0$0 == 0x7fc6
                    7FC6    579 _OUT1CS	=	0x7fc6
                    7FC7    580 G$OUT1BC$0$0 == 0x7fc7
                    7FC7    581 _OUT1BC	=	0x7fc7
                    7FC8    582 G$OUT2CS$0$0 == 0x7fc8
                    7FC8    583 _OUT2CS	=	0x7fc8
                    7FC9    584 G$OUT2BC$0$0 == 0x7fc9
                    7FC9    585 _OUT2BC	=	0x7fc9
                    7FCA    586 G$OUT3CS$0$0 == 0x7fca
                    7FCA    587 _OUT3CS	=	0x7fca
                    7FCB    588 G$OUT3BC$0$0 == 0x7fcb
                    7FCB    589 _OUT3BC	=	0x7fcb
                    7FCC    590 G$OUT4CS$0$0 == 0x7fcc
                    7FCC    591 _OUT4CS	=	0x7fcc
                    7FCD    592 G$OUT4BC$0$0 == 0x7fcd
                    7FCD    593 _OUT4BC	=	0x7fcd
                    7FCE    594 G$OUT5CS$0$0 == 0x7fce
                    7FCE    595 _OUT5CS	=	0x7fce
                    7FCF    596 G$OUT5BC$0$0 == 0x7fcf
                    7FCF    597 _OUT5BC	=	0x7fcf
                    7FD0    598 G$OUT6CS$0$0 == 0x7fd0
                    7FD0    599 _OUT6CS	=	0x7fd0
                    7FD1    600 G$OUT6BC$0$0 == 0x7fd1
                    7FD1    601 _OUT6BC	=	0x7fd1
                    7FD2    602 G$OUT7CS$0$0 == 0x7fd2
                    7FD2    603 _OUT7CS	=	0x7fd2
                    7FD3    604 G$OUT7BC$0$0 == 0x7fd3
                    7FD3    605 _OUT7BC	=	0x7fd3
                    7FA8    606 G$IVEC$0$0 == 0x7fa8
                    7FA8    607 _IVEC	=	0x7fa8
                    7FA9    608 G$IN07IRQ$0$0 == 0x7fa9
                    7FA9    609 _IN07IRQ	=	0x7fa9
                    7FAA    610 G$OUT07IRQ$0$0 == 0x7faa
                    7FAA    611 _OUT07IRQ	=	0x7faa
                    7FAB    612 G$USBIRQ$0$0 == 0x7fab
                    7FAB    613 _USBIRQ	=	0x7fab
                    7FAC    614 G$IN07IEN$0$0 == 0x7fac
                    7FAC    615 _IN07IEN	=	0x7fac
                    7FAD    616 G$OUT07IEN$0$0 == 0x7fad
                    7FAD    617 _OUT07IEN	=	0x7fad
                    7FAE    618 G$USBIEN$0$0 == 0x7fae
                    7FAE    619 _USBIEN	=	0x7fae
                    7FAF    620 G$USBBAV$0$0 == 0x7faf
                    7FAF    621 _USBBAV	=	0x7faf
                    7FB2    622 G$BPADDRH$0$0 == 0x7fb2
                    7FB2    623 _BPADDRH	=	0x7fb2
                    7FB3    624 G$BPADDRL$0$0 == 0x7fb3
                    7FB3    625 _BPADDRL	=	0x7fb3
                    7FD4    626 G$SUDPTRH$0$0 == 0x7fd4
                    7FD4    627 _SUDPTRH	=	0x7fd4
                    7FD5    628 G$SUDPTRL$0$0 == 0x7fd5
                    7FD5    629 _SUDPTRL	=	0x7fd5
                    7FD6    630 G$USBCS$0$0 == 0x7fd6
                    7FD6    631 _USBCS	=	0x7fd6
                    7FD7    632 G$TOGCTL$0$0 == 0x7fd7
                    7FD7    633 _TOGCTL	=	0x7fd7
                    7FD8    634 G$USBFRAMEL$0$0 == 0x7fd8
                    7FD8    635 _USBFRAMEL	=	0x7fd8
                    7FD9    636 G$USBFRAMEH$0$0 == 0x7fd9
                    7FD9    637 _USBFRAMEH	=	0x7fd9
                    7FDB    638 G$FNADDR$0$0 == 0x7fdb
                    7FDB    639 _FNADDR	=	0x7fdb
                    7FDD    640 G$USBPAIR$0$0 == 0x7fdd
                    7FDD    641 _USBPAIR	=	0x7fdd
                    7FDE    642 G$IN07VAL$0$0 == 0x7fde
                    7FDE    643 _IN07VAL	=	0x7fde
                    7FDF    644 G$OUT07VAL$0$0 == 0x7fdf
                    7FDF    645 _OUT07VAL	=	0x7fdf
                    7F60    646 G$OUT8DATA$0$0 == 0x7f60
                    7F60    647 _OUT8DATA	=	0x7f60
                    7F61    648 G$OUT9DATA$0$0 == 0x7f61
                    7F61    649 _OUT9DATA	=	0x7f61
                    7F62    650 G$OUT10DATA$0$0 == 0x7f62
                    7F62    651 _OUT10DATA	=	0x7f62
                    7F63    652 G$OUT11DATA$0$0 == 0x7f63
                    7F63    653 _OUT11DATA	=	0x7f63
                    7F64    654 G$OUT12DATA$0$0 == 0x7f64
                    7F64    655 _OUT12DATA	=	0x7f64
                    7F65    656 G$OUT13DATA$0$0 == 0x7f65
                    7F65    657 _OUT13DATA	=	0x7f65
                    7F66    658 G$OUT14DATA$0$0 == 0x7f66
                    7F66    659 _OUT14DATA	=	0x7f66
                    7F67    660 G$OUT15DATA$0$0 == 0x7f67
                    7F67    661 _OUT15DATA	=	0x7f67
                    7F68    662 G$IN8DATA$0$0 == 0x7f68
                    7F68    663 _IN8DATA	=	0x7f68
                    7F69    664 G$IN9DATA$0$0 == 0x7f69
                    7F69    665 _IN9DATA	=	0x7f69
                    7F6A    666 G$IN10DATA$0$0 == 0x7f6a
                    7F6A    667 _IN10DATA	=	0x7f6a
                    7F6B    668 G$IN11DATA$0$0 == 0x7f6b
                    7F6B    669 _IN11DATA	=	0x7f6b
                    7F6C    670 G$IN12DATA$0$0 == 0x7f6c
                    7F6C    671 _IN12DATA	=	0x7f6c
                    7F6D    672 G$IN13DATA$0$0 == 0x7f6d
                    7F6D    673 _IN13DATA	=	0x7f6d
                    7F6E    674 G$IN14DATA$0$0 == 0x7f6e
                    7F6E    675 _IN14DATA	=	0x7f6e
                    7F6F    676 G$IN15DATA$0$0 == 0x7f6f
                    7F6F    677 _IN15DATA	=	0x7f6f
                    7F70    678 G$OUT8BCH$0$0 == 0x7f70
                    7F70    679 _OUT8BCH	=	0x7f70
                    7F71    680 G$OUT8BCL$0$0 == 0x7f71
                    7F71    681 _OUT8BCL	=	0x7f71
                    7F72    682 G$OUT9BCH$0$0 == 0x7f72
                    7F72    683 _OUT9BCH	=	0x7f72
                    7F73    684 G$OUT9BCL$0$0 == 0x7f73
                    7F73    685 _OUT9BCL	=	0x7f73
                    7F74    686 G$OUT10BCH$0$0 == 0x7f74
                    7F74    687 _OUT10BCH	=	0x7f74
                    7F75    688 G$OUT10BCL$0$0 == 0x7f75
                    7F75    689 _OUT10BCL	=	0x7f75
                    7F76    690 G$OUT11BCH$0$0 == 0x7f76
                    7F76    691 _OUT11BCH	=	0x7f76
                    7F77    692 G$OUT11BCL$0$0 == 0x7f77
                    7F77    693 _OUT11BCL	=	0x7f77
                    7F78    694 G$OUT12BCH$0$0 == 0x7f78
                    7F78    695 _OUT12BCH	=	0x7f78
                    7F79    696 G$OUT12BCL$0$0 == 0x7f79
                    7F79    697 _OUT12BCL	=	0x7f79
                    7F7A    698 G$OUT13BCH$0$0 == 0x7f7a
                    7F7A    699 _OUT13BCH	=	0x7f7a
                    7F7B    700 G$OUT13BCL$0$0 == 0x7f7b
                    7F7B    701 _OUT13BCL	=	0x7f7b
                    7F7C    702 G$OUT14BCH$0$0 == 0x7f7c
                    7F7C    703 _OUT14BCH	=	0x7f7c
                    7F7D    704 G$OUT14BCL$0$0 == 0x7f7d
                    7F7D    705 _OUT14BCL	=	0x7f7d
                    7F7E    706 G$OUT15BCH$0$0 == 0x7f7e
                    7F7E    707 _OUT15BCH	=	0x7f7e
                    7F7F    708 G$OUT15BCL$0$0 == 0x7f7f
                    7F7F    709 _OUT15BCL	=	0x7f7f
                    7FF0    710 G$OUT8ADDR$0$0 == 0x7ff0
                    7FF0    711 _OUT8ADDR	=	0x7ff0
                    7FF1    712 G$OUT9ADDR$0$0 == 0x7ff1
                    7FF1    713 _OUT9ADDR	=	0x7ff1
                    7FF2    714 G$OUT10ADDR$0$0 == 0x7ff2
                    7FF2    715 _OUT10ADDR	=	0x7ff2
                    7FF3    716 G$OUT11ADDR$0$0 == 0x7ff3
                    7FF3    717 _OUT11ADDR	=	0x7ff3
                    7FF4    718 G$OUT12ADDR$0$0 == 0x7ff4
                    7FF4    719 _OUT12ADDR	=	0x7ff4
                    7FF5    720 G$OUT13ADDR$0$0 == 0x7ff5
                    7FF5    721 _OUT13ADDR	=	0x7ff5
                    7FF6    722 G$OUT14ADDR$0$0 == 0x7ff6
                    7FF6    723 _OUT14ADDR	=	0x7ff6
                    7FF7    724 G$OUT15ADDR$0$0 == 0x7ff7
                    7FF7    725 _OUT15ADDR	=	0x7ff7
                    7FF8    726 G$IN8ADDR$0$0 == 0x7ff8
                    7FF8    727 _IN8ADDR	=	0x7ff8
                    7FF9    728 G$IN9ADDR$0$0 == 0x7ff9
                    7FF9    729 _IN9ADDR	=	0x7ff9
                    7FFA    730 G$IN10ADDR$0$0 == 0x7ffa
                    7FFA    731 _IN10ADDR	=	0x7ffa
                    7FFB    732 G$IN11ADDR$0$0 == 0x7ffb
                    7FFB    733 _IN11ADDR	=	0x7ffb
                    7FFC    734 G$IN12ADDR$0$0 == 0x7ffc
                    7FFC    735 _IN12ADDR	=	0x7ffc
                    7FFD    736 G$IN13ADDR$0$0 == 0x7ffd
                    7FFD    737 _IN13ADDR	=	0x7ffd
                    7FFE    738 G$IN14ADDR$0$0 == 0x7ffe
                    7FFE    739 _IN14ADDR	=	0x7ffe
                    7FFF    740 G$IN15ADDR$0$0 == 0x7fff
                    7FFF    741 _IN15ADDR	=	0x7fff
                    7FE0    742 G$INISOVAL$0$0 == 0x7fe0
                    7FE0    743 _INISOVAL	=	0x7fe0
                    7FE1    744 G$OUTISOVAL$0$0 == 0x7fe1
                    7FE1    745 _OUTISOVAL	=	0x7fe1
                    7FE2    746 G$FASTXFR$0$0 == 0x7fe2
                    7FE2    747 _FASTXFR	=	0x7fe2
                            748 ;--------------------------------------------------------
                            749 ; global & static initialisations
                            750 ;--------------------------------------------------------
                            751 	.area GSINIT  (CODE)
                            752 	.area GSFINAL (CODE)
                            753 	.area GSINIT  (CODE)
                            754 ;--------------------------------------------------------
                            755 ; Home
                            756 ;--------------------------------------------------------
                            757 	.area HOME	 (CODE)
                            758 	.area CSEG    (CODE)
                            759 ;--------------------------------------------------------
                            760 ; code
                            761 ;--------------------------------------------------------
                            762 	.area CSEG    (CODE)
                            763 ;------------------------------------------------------------
                            764 ;Allocation info for local variables in function 'initUSB'
                            765 ;------------------------------------------------------------
                            766 ;i                         Allocated to registers 
                    0000    767 	G$initUSB$0$0 ==.
                            768 ;	usb.c 13
                            769 ;	-----------------------------------------
                            770 ;	 function initUSB
                            771 ;	-----------------------------------------
   03F0                     772 _initUSB:
                    0002    773 	ar2 = 0x02
                    0003    774 	ar3 = 0x03
                    0004    775 	ar4 = 0x04
                    0005    776 	ar5 = 0x05
                    0006    777 	ar6 = 0x06
                    0007    778 	ar7 = 0x07
                    0000    779 	ar0 = 0x00
                    0001    780 	ar1 = 0x01
                            781 ;	usb.c 16
   03F0 90 7F AE            782 	mov	dptr,#_USBIEN
                            783 ; Peephole 180   changed mov to clr
                            784 ;	usb.c 18
                            785 ; Peephole 180   changed mov to clr
                            786 ; Peephole 219 removed redundant clear
                            787 ;	usb.c 19
                            788 ; Peephole 180   changed mov to clr
                            789 ; Peephole 219a removed redundant clear
   03F3 E4                  790 	clr   a
   03F4 F0                  791 	movx  @dptr,a
   03F5 90 7F D6            792 	mov   dptr,#_USBCS
   03F8 F0                  793 	movx  @dptr,a
   03F9 90 7F AF            794 	mov   dptr,#_USBBAV
   03FC F0                  795 	movx  @dptr,a
                            796 ;	usb.c 20
   03FD 90 7F A1            797 	mov	dptr,#_ISOCTL
   0400 74 01               798 	mov	a,#0x01
   0402 F0                  799 	movx	@dptr,a
                            800 ;	usb.c 21
   0403 90 7F E0            801 	mov	dptr,#_INISOVAL
                            802 ; Peephole 180   changed mov to clr
                            803 ;	usb.c 22
                            804 ; Peephole 180   changed mov to clr
                            805 ; Peephole 219 removed redundant clear
   0406 E4                  806 	clr   a
   0407 F0                  807 	movx  @dptr,a
   0408 90 7F E1            808 	mov   dptr,#_OUTISOVAL
   040B F0                  809 	movx  @dptr,a
                            810 ;	usb.c 24
   040C 90 7F DD            811 	mov	dptr,#_USBPAIR
   040F 74 02               812 	mov	a,#0x02
   0411 F0                  813 	movx	@dptr,a
                            814 ;	usb.c 25
   0412 90 7F DE            815 	mov	dptr,#_IN07VAL
   0415 74 14               816 	mov	a,#0x14
   0417 F0                  817 	movx	@dptr,a
                            818 ;	usb.c 26
   0418 90 7F DF            819 	mov	dptr,#_OUT07VAL
   041B 74 04               820 	mov	a,#0x04
   041D F0                  821 	movx	@dptr,a
                            822 ;	usb.c 27
   041E 90 7F AC            823 	mov	dptr,#_IN07IEN
                            824 ; Peephole 180   changed mov to clr
   0421 E4                  825 	clr  a
   0422 F0                  826 	movx	@dptr,a
                            827 ;	usb.c 28
   0423 90 7F AD            828 	mov	dptr,#_OUT07IEN
   0426 74 04               829 	mov	a,#0x04
   0428 F0                  830 	movx	@dptr,a
                            831 ;	usb.c 31
   0429 7A 00               832 	mov	r2,#0x00
   042B                     833 00101$:
   042B BA 07 00            834 	cjne	r2,#0x07,00109$
   042E                     835 00109$:
                            836 ; Peephole 108   removed ljmp by inverse jump logic
   042E 50 1D               837 	jnc  00104$
   0430                     838 00110$:
                            839 ;	usb.c 32
   0430 90 7F D7            840 	mov	dptr,#_TOGCTL
   0433 74 10               841 	mov	a,#0x10
   0435 2A                  842 	add	a,r2
   0436 F0                  843 	movx	@dptr,a
                            844 ;	usb.c 33
   0437 90 7F D7            845 	mov	dptr,#_TOGCTL
   043A 74 30               846 	mov	a,#0x30
   043C 2A                  847 	add	a,r2
   043D F0                  848 	movx	@dptr,a
                            849 ;	usb.c 34
   043E 90 7F D7            850 	mov	dptr,#_TOGCTL
   0441 EA                  851 	mov	a,r2
   0442 F0                  852 	movx	@dptr,a
                            853 ;	usb.c 35
   0443 90 7F D7            854 	mov	dptr,#_TOGCTL
   0446 74 20               855 	mov	a,#0x20
   0448 2A                  856 	add	a,r2
   0449 F0                  857 	movx	@dptr,a
                            858 ;	usb.c 31
   044A 0A                  859 	inc	r2
                            860 ; Peephole 132   changed ljmp to sjmp
   044B 80 DE               861 	sjmp 00101$
   044D                     862 00104$:
                            863 ;	usb.c 38
   044D 90 7F D6            864 	mov	dptr,#_USBCS
   0450 74 04               865 	mov	a,#0x04
   0452 F0                  866 	movx	@dptr,a
                            867 ;	usb.c 42
   0453 90 7F C9            868 	mov	dptr,#_OUT2BC
                            869 ; Peephole 180   changed mov to clr
   0456 E4                  870 	clr  a
   0457 F0                  871 	movx	@dptr,a
                            872 ;	usb.c 43
   0458 D2 E8               873 	setb	_EUSB
   045A                     874 00105$:
                    006A    875 	C$usb.c$44$1$1 ==.
                    006A    876 	XG$initUSB$0$0 ==.
   045A 22                  877 	ret
                            878 ;------------------------------------------------------------
                            879 ;Allocation info for local variables in function 'intUSB'
                            880 ;------------------------------------------------------------
                            881 ;src                       Allocated to registers r2 
                    006B    882 	G$intUSB$0$0 ==.
                            883 ;	usb.c 46
                            884 ;	-----------------------------------------
                            885 ;	 function intUSB
                            886 ;	-----------------------------------------
   045B                     887 _intUSB:
   045B C0 E0               888 	push	acc
   045D C0 F0               889 	push	b
   045F C0 82               890 	push	dpl
   0461 C0 83               891 	push	dph
   0463 C0 02               892 	push	(0+2)
   0465 C0 03               893 	push	(0+3)
   0467 C0 04               894 	push	(0+4)
   0469 C0 05               895 	push	(0+5)
   046B C0 06               896 	push	(0+6)
   046D C0 07               897 	push	(0+7)
   046F C0 00               898 	push	(0+0)
   0471 C0 01               899 	push	(0+1)
   0473 C0 D0               900 	push	psw
   0475 75 D0 00            901 	mov	psw,#0x00
                            902 ;	usb.c 47
   0478 90 7F A8            903 	mov	dptr,#_IVEC
   047B E0                  904 	movx	a,@dptr
                            905 ; Peephole 105   removed redundant mov
   047C FA                  906 	mov  r2,a
   047D 03                  907 	rr	a
   047E 03                  908 	rr	a
   047F 54 3F               909 	anl	a,#0x3f
   0481 FA                  910 	mov	r2,a
                            911 ;	usb.c 49
   0482 BA 00 02            912 	cjne	r2,#0x00,00124$
                            913 ; Peephole 132   changed ljmp to sjmp
   0485 80 36               914 	sjmp 00101$
   0487                     915 00124$:
   0487 BA 01 02            916 	cjne	r2,#0x01,00125$
                            917 ; Peephole 132   changed ljmp to sjmp
   048A 80 43               918 	sjmp 00102$
   048C                     919 00125$:
   048C BA 02 02            920 	cjne	r2,#0x02,00126$
                            921 ; Peephole 132   changed ljmp to sjmp
   048F 80 50               922 	sjmp 00103$
   0491                     923 00126$:
   0491 BA 03 02            924 	cjne	r2,#0x03,00127$
                            925 ; Peephole 132   changed ljmp to sjmp
   0494 80 5D               926 	sjmp 00104$
   0496                     927 00127$:
   0496 BA 04 03            928 	cjne	r2,#0x04,00128$
   0499 02 05 05            929 	ljmp	00105$
   049C                     930 00128$:
   049C BA 06 03            931 	cjne	r2,#0x06,00129$
   049F 02 05 16            932 	ljmp	00106$
   04A2                     933 00129$:
   04A2 BA 07 03            934 	cjne	r2,#0x07,00130$
   04A5 02 05 27            935 	ljmp	00107$
   04A8                     936 00130$:
   04A8 BA 08 03            937 	cjne	r2,#0x08,00131$
   04AB 02 05 38            938 	ljmp	00108$
   04AE                     939 00131$:
   04AE BA 09 03            940 	cjne	r2,#0x09,00132$
   04B1 02 05 49            941 	ljmp	00109$
   04B4                     942 00132$:
   04B4 BA 0B 03            943 	cjne	r2,#0x0B,00133$
   04B7 02 05 5A            944 	ljmp	00110$
   04BA                     945 00133$:
   04BA 02 05 6C            946 	ljmp	00112$
                            947 ;	usb.c 52
   04BD                     948 00101$:
   04BD AA 91               949 	mov	r2,_EXIF
   04BF 7B 00               950 	mov	r3,#0x00
   04C1 53 02 E0            951 	anl	ar2,#0xE0
   04C4 8A 91               952 	mov	_EXIF,r2
                            953 ;	usb.c 53
   04C6 90 7F AB            954 	mov	dptr,#_USBIRQ
   04C9 74 01               955 	mov	a,#0x01
   04CB F0                  956 	movx	@dptr,a
                            957 ;	usb.c 54
   04CC 02 05 6C            958 	ljmp	00112$
                            959 ;	usb.c 57
   04CF                     960 00102$:
   04CF AA 91               961 	mov	r2,_EXIF
   04D1 7B 00               962 	mov	r3,#0x00
   04D3 53 02 E0            963 	anl	ar2,#0xE0
   04D6 8A 91               964 	mov	_EXIF,r2
                            965 ;	usb.c 58
   04D8 90 7F AB            966 	mov	dptr,#_USBIRQ
   04DB 74 02               967 	mov	a,#0x02
   04DD F0                  968 	movx	@dptr,a
                            969 ;	usb.c 59
   04DE 02 05 6C            970 	ljmp	00112$
                            971 ;	usb.c 62
   04E1                     972 00103$:
   04E1 AA 91               973 	mov	r2,_EXIF
   04E3 7B 00               974 	mov	r3,#0x00
   04E5 53 02 E0            975 	anl	ar2,#0xE0
   04E8 8A 91               976 	mov	_EXIF,r2
                            977 ;	usb.c 63
   04EA 90 7F AB            978 	mov	dptr,#_USBIRQ
   04ED 74 04               979 	mov	a,#0x04
   04EF F0                  980 	movx	@dptr,a
                            981 ;	usb.c 64
   04F0 02 05 6C            982 	ljmp	00112$
                            983 ;	usb.c 67
   04F3                     984 00104$:
   04F3 AA 91               985 	mov	r2,_EXIF
   04F5 7B 00               986 	mov	r3,#0x00
   04F7 53 02 E0            987 	anl	ar2,#0xE0
   04FA 8A 91               988 	mov	_EXIF,r2
                            989 ;	usb.c 68
   04FC 90 7F AB            990 	mov	dptr,#_USBIRQ
   04FF 74 08               991 	mov	a,#0x08
   0501 F0                  992 	movx	@dptr,a
                            993 ;	usb.c 69
   0502 02 05 6C            994 	ljmp	00112$
                            995 ;	usb.c 72
   0505                     996 00105$:
   0505 AA 91               997 	mov	r2,_EXIF
   0507 7B 00               998 	mov	r3,#0x00
   0509 53 02 E0            999 	anl	ar2,#0xE0
   050C 8A 91              1000 	mov	_EXIF,r2
                           1001 ;	usb.c 73
   050E 90 7F AB           1002 	mov	dptr,#_USBIRQ
   0511 74 10              1003 	mov	a,#0x10
   0513 F0                 1004 	movx	@dptr,a
                           1005 ;	usb.c 74
                           1006 ;	usb.c 77
                           1007 ; Peephole 132   changed ljmp to sjmp
   0514 80 56              1008 	sjmp 00112$
   0516                    1009 00106$:
   0516 AA 91              1010 	mov	r2,_EXIF
   0518 7B 00              1011 	mov	r3,#0x00
   051A 53 02 E0           1012 	anl	ar2,#0xE0
   051D 8A 91              1013 	mov	_EXIF,r2
                           1014 ;	usb.c 78
   051F 90 7F A9           1015 	mov	dptr,#_IN07IRQ
   0522 74 01              1016 	mov	a,#0x01
   0524 F0                 1017 	movx	@dptr,a
                           1018 ;	usb.c 79
                           1019 ;	usb.c 82
                           1020 ; Peephole 132   changed ljmp to sjmp
   0525 80 45              1021 	sjmp 00112$
   0527                    1022 00107$:
   0527 AA 91              1023 	mov	r2,_EXIF
   0529 7B 00              1024 	mov	r3,#0x00
   052B 53 02 E0           1025 	anl	ar2,#0xE0
   052E 8A 91              1026 	mov	_EXIF,r2
                           1027 ;	usb.c 83
   0530 90 7F AA           1028 	mov	dptr,#_OUT07IRQ
   0533 74 01              1029 	mov	a,#0x01
   0535 F0                 1030 	movx	@dptr,a
                           1031 ;	usb.c 84
                           1032 ;	usb.c 87
                           1033 ; Peephole 132   changed ljmp to sjmp
   0536 80 34              1034 	sjmp 00112$
   0538                    1035 00108$:
   0538 AA 91              1036 	mov	r2,_EXIF
   053A 7B 00              1037 	mov	r3,#0x00
   053C 53 02 E0           1038 	anl	ar2,#0xE0
   053F 8A 91              1039 	mov	_EXIF,r2
                           1040 ;	usb.c 88
   0541 90 7F A9           1041 	mov	dptr,#_IN07IRQ
   0544 74 02              1042 	mov	a,#0x02
   0546 F0                 1043 	movx	@dptr,a
                           1044 ;	usb.c 89
                           1045 ;	usb.c 92
                           1046 ; Peephole 132   changed ljmp to sjmp
   0547 80 23              1047 	sjmp 00112$
   0549                    1048 00109$:
   0549 AA 91              1049 	mov	r2,_EXIF
   054B 7B 00              1050 	mov	r3,#0x00
   054D 53 02 E0           1051 	anl	ar2,#0xE0
   0550 8A 91              1052 	mov	_EXIF,r2
                           1053 ;	usb.c 93
   0552 90 7F AA           1054 	mov	dptr,#_OUT07IRQ
   0555 74 02              1055 	mov	a,#0x02
   0557 F0                 1056 	movx	@dptr,a
                           1057 ;	usb.c 94
                           1058 ;	usb.c 96
                           1059 ; Peephole 132   changed ljmp to sjmp
   0558 80 12              1060 	sjmp 00112$
   055A                    1061 00110$:
   055A 12 05 87           1062 	lcall	_ep2outUSB
                           1063 ;	usb.c 97
   055D AA 91              1064 	mov	r2,_EXIF
   055F 7B 00              1065 	mov	r3,#0x00
   0561 53 02 E0           1066 	anl	ar2,#0xE0
   0564 8A 91              1067 	mov	_EXIF,r2
                           1068 ;	usb.c 98
   0566 90 7F AA           1069 	mov	dptr,#_OUT07IRQ
   0569 74 04              1070 	mov	a,#0x04
   056B F0                 1071 	movx	@dptr,a
                           1072 ;	usb.c 100
   056C                    1073 00112$:
   056C D0 D0              1074 	pop	psw
   056E D0 01              1075 	pop	(0+1)
   0570 D0 00              1076 	pop	(0+0)
   0572 D0 07              1077 	pop	(0+7)
   0574 D0 06              1078 	pop	(0+6)
   0576 D0 05              1079 	pop	(0+5)
   0578 D0 04              1080 	pop	(0+4)
   057A D0 03              1081 	pop	(0+3)
   057C D0 02              1082 	pop	(0+2)
   057E D0 83              1083 	pop	dph
   0580 D0 82              1084 	pop	dpl
   0582 D0 F0              1085 	pop	b
   0584 D0 E0              1086 	pop	acc
                    0196   1087 	C$usb.c$101$1$1 ==.
                    0196   1088 	XG$intUSB$0$0 ==.
   0586 32                 1089 	reti
                           1090 ;------------------------------------------------------------
                           1091 ;Allocation info for local variables in function 'ep2outUSB'
                           1092 ;------------------------------------------------------------
                           1093 ;i                         Allocated to registers 
                           1094 ;i                         Allocated to registers 
                           1095 ;i                         Allocated to registers 
                           1096 ;v                         Allocated to registers r2 
                    0197   1097 	G$ep2outUSB$0$0 ==.
                           1098 ;	usb.c 104
                           1099 ;	-----------------------------------------
                           1100 ;	 function ep2outUSB
                           1101 ;	-----------------------------------------
   0587                    1102 _ep2outUSB:
                           1103 ;	usb.c 106
   0587 90 7D C0           1104 	mov	dptr,#_OUT2BUF
   058A E0                 1105 	movx	a,@dptr
   058B FA                 1106 	mov	r2,a
   058C BA 00 02           1107 	cjne	r2,#0x00,00251$
                           1108 ; Peephole 132   changed ljmp to sjmp
   058F 80 08              1109 	sjmp 00205$
   0591                    1110 00251$:
   0591 90 7D C0           1111 	mov	dptr,#_OUT2BUF
   0594 E0                 1112 	movx	a,@dptr
   0595 FA                 1113 	mov	r2,a
                           1114 ; Peephole 132   changed ljmp to sjmp
                           1115 ; Peephole 199   optimized misc jump sequence
   0596 BA 01 34           1116 	cjne r2,#0x01,00104$
                           1117 ;00252$:
                           1118 ; Peephole 200   removed redundant sjmp
   0599                    1119 00253$:
                           1120 ;	usb.c 108
   0599                    1121 00205$:
   0599 7A 00              1122 	mov	r2,#0x00
   059B                    1123 00164$:
   059B BA 07 00           1124 	cjne	r2,#0x07,00254$
   059E                    1125 00254$:
                           1126 ; Peephole 108   removed ljmp by inverse jump logic
   059E 50 25              1127 	jnc  00167$
   05A0                    1128 00255$:
                           1129 ;	usb.c 109
   05A0 90 7F D7           1130 	mov	dptr,#_TOGCTL
   05A3 74 10              1131 	mov	a,#0x10
   05A5 2A                 1132 	add	a,r2
   05A6 F0                 1133 	movx	@dptr,a
                           1134 ;	usb.c 110
   05A7 90 7F D7           1135 	mov	dptr,#_TOGCTL
   05AA 74 30              1136 	mov	a,#0x30
   05AC 2A                 1137 	add	a,r2
   05AD F0                 1138 	movx	@dptr,a
                           1139 ;	usb.c 111
   05AE 90 7F D7           1140 	mov	dptr,#_TOGCTL
   05B1 EA                 1141 	mov	a,r2
   05B2 F0                 1142 	movx	@dptr,a
                           1143 ;	usb.c 112
   05B3 90 7D C0           1144 	mov	dptr,#_OUT2BUF
   05B6 E0                 1145 	movx	a,@dptr
   05B7 FB                 1146 	mov	r3,a
                           1147 ; Peephole 132   changed ljmp to sjmp
                           1148 ; Peephole 199   optimized misc jump sequence
   05B8 BB 01 07           1149 	cjne r3,#0x01,00166$
                           1150 ;00256$:
                           1151 ; Peephole 200   removed redundant sjmp
   05BB                    1152 00257$:
                           1153 ;	usb.c 113
   05BB 90 7F D7           1154 	mov	dptr,#_TOGCTL
   05BE 74 20              1155 	mov	a,#0x20
   05C0 2A                 1156 	add	a,r2
   05C1 F0                 1157 	movx	@dptr,a
   05C2                    1158 00166$:
                           1159 ;	usb.c 108
   05C2 0A                 1160 	inc	r2
                           1161 ; Peephole 132   changed ljmp to sjmp
   05C3 80 D6              1162 	sjmp 00164$
   05C5                    1163 00167$:
                           1164 ;	usb.c 116
   05C5 90 7F C9           1165 	mov	dptr,#_OUT2BC
                           1166 ; Peephole 180   changed mov to clr
   05C8 E4                 1167 	clr  a
   05C9 F0                 1168 	movx	@dptr,a
                           1169 ;	usb.c 117
   05CA 02 0B 0F           1170 	ljmp	00192$
   05CD                    1171 00104$:
                           1172 ;	usb.c 120
                           1173 ; Peephole 182   used 16 bit load of dptr
                           1174 ; Peephole 210   simplified expression
   05CD 90 7D C0           1175 	mov  dptr,#_OUT2BUF
   05D0 75 F0 01           1176 	mov	b,#0x01
   05D3 75 53 3D           1177 	mov	_strcmp_PARM_2,#__str_0
   05D6 75 54 0C           1178 	mov	(_strcmp_PARM_2 + 1),#(__str_0 >> 8)
   05D9 75 55 02           1179 	mov	(_strcmp_PARM_2 + 2),#0x02
   05DC 12 11 26           1180 	lcall	_strcmp
   05DF AA 82              1181 	mov	r2,dpl
   05E1 AB 83              1182 	mov	r3,dph
                           1183 ; Peephole 132   changed ljmp to sjmp
                           1184 ; Peephole 198   optimized misc jump sequence
   05E3 BA 00 15           1185 	cjne r2,#0x00,00107$
   05E6 BB 00 12           1186 	cjne r3,#0x00,00107$
                           1187 ;00258$:
                           1188 ; Peephole 200   removed redundant sjmp
   05E9                    1189 00259$:
                           1190 ;	usb.c 121
                           1191 ; Peephole 182   used 16 bit load of dptr
                           1192 ; Peephole 210   simplified expression
   05E9 90 0C 41           1193 	mov  dptr,#__str_1
   05EC 75 F0 02           1194 	mov	b,#0x02
   05EF 12 0B 10           1195 	lcall	_prints
                           1196 ;	usb.c 122
                           1197 ; Peephole 182   used 16 bit load of dptr
                           1198 ; Peephole 210   simplified expression
   05F2 90 0C 68           1199 	mov  dptr,#__str_2
   05F5 75 F0 02           1200 	mov	b,#0x02
   05F8 12 0B 10           1201 	lcall	_prints
   05FB                    1202 00107$:
                           1203 ;	usb.c 125
                           1204 ; Peephole 182   used 16 bit load of dptr
                           1205 ; Peephole 210   simplified expression
   05FB 90 7D C0           1206 	mov  dptr,#_OUT2BUF
   05FE 75 F0 01           1207 	mov	b,#0x01
   0601 75 53 9D           1208 	mov	_strcmp_PARM_2,#__str_3
   0604 75 54 0C           1209 	mov	(_strcmp_PARM_2 + 1),#(__str_3 >> 8)
   0607 75 55 02           1210 	mov	(_strcmp_PARM_2 + 2),#0x02
   060A 12 11 26           1211 	lcall	_strcmp
   060D AA 82              1212 	mov	r2,dpl
   060F AB 83              1213 	mov	r3,dph
                           1214 ; Peephole 132   changed ljmp to sjmp
                           1215 ; Peephole 198   optimized misc jump sequence
   0611 BA 00 29           1216 	cjne r2,#0x00,00112$
   0614 BB 00 26           1217 	cjne r3,#0x00,00112$
                           1218 ;00260$:
                           1219 ; Peephole 200   removed redundant sjmp
   0617                    1220 00261$:
                           1221 ;	usb.c 126
   0617 90 7F 92           1222 	mov	dptr,#_CPUCS
   061A E0                 1223 	movx	a,@dptr
                           1224 ; Peephole 105   removed redundant mov
   061B FA                 1225 	mov  r2,a
   061C 33                 1226 	rlc	a
   061D 95 E0              1227 	subb	a,acc
   061F FB                 1228 	mov	r3,a
   0620 53 02 08           1229 	anl	ar2,#0x08
   0623 7B 00              1230 	mov	r3,#0x00
   0625 EA                 1231 	mov	a,r2
   0626 4B                 1232 	orl	a,r3
                           1233 ; Peephole 110   removed ljmp by inverse jump logic
   0627 60 0B              1234 	jz  00109$
   0629                    1235 00262$:
                           1236 ;	usb.c 127
                           1237 ; Peephole 182   used 16 bit load of dptr
                           1238 ; Peephole 210   simplified expression
   0629 90 0C A4           1239 	mov  dptr,#__str_4
   062C 75 F0 02           1240 	mov	b,#0x02
   062F 12 0B 10           1241 	lcall	_prints
                           1242 ; Peephole 132   changed ljmp to sjmp
   0632 80 09              1243 	sjmp 00112$
   0634                    1244 00109$:
                           1245 ;	usb.c 129
                           1246 ; Peephole 182   used 16 bit load of dptr
                           1247 ; Peephole 210   simplified expression
   0634 90 0C AC           1248 	mov  dptr,#__str_5
   0637 75 F0 02           1249 	mov	b,#0x02
   063A 12 0B 10           1250 	lcall	_prints
   063D                    1251 00112$:
                           1252 ;	usb.c 132
                           1253 ; Peephole 182   used 16 bit load of dptr
                           1254 ; Peephole 210   simplified expression
   063D 90 7D C0           1255 	mov  dptr,#_OUT2BUF
   0640 75 F0 01           1256 	mov	b,#0x01
   0643 75 53 B4           1257 	mov	_strcmp_PARM_2,#__str_6
   0646 75 54 0C           1258 	mov	(_strcmp_PARM_2 + 1),#(__str_6 >> 8)
   0649 75 55 02           1259 	mov	(_strcmp_PARM_2 + 2),#0x02
   064C 12 11 26           1260 	lcall	_strcmp
   064F AA 82              1261 	mov	r2,dpl
   0651 AB 83              1262 	mov	r3,dph
                           1263 ; Peephole 132   changed ljmp to sjmp
                           1264 ; Peephole 198   optimized misc jump sequence
   0653 BA 00 0F           1265 	cjne r2,#0x00,00114$
   0656 BB 00 0C           1266 	cjne r3,#0x00,00114$
                           1267 ;00263$:
                           1268 ; Peephole 200   removed redundant sjmp
   0659                    1269 00264$:
                           1270 ;	usb.c 133
                           1271 ; Peephole 182   used 16 bit load of dptr
                           1272 ; Peephole 210   simplified expression
   0659 90 0C BA           1273 	mov  dptr,#__str_7
   065C 75 F0 02           1274 	mov	b,#0x02
   065F 12 0B 10           1275 	lcall	_prints
                           1276 ;	usb.c 134
   0662 12 0F 12           1277 	lcall	_nextMP3
   0665                    1278 00114$:
                           1279 ;	usb.c 137
                           1280 ; Peephole 182   used 16 bit load of dptr
                           1281 ; Peephole 210   simplified expression
   0665 90 7D C0           1282 	mov  dptr,#_OUT2BUF
   0668 75 F0 01           1283 	mov	b,#0x01
   066B 75 53 C9           1284 	mov	_strcmp_PARM_2,#__str_8
   066E 75 54 0C           1285 	mov	(_strcmp_PARM_2 + 1),#(__str_8 >> 8)
   0671 75 55 02           1286 	mov	(_strcmp_PARM_2 + 2),#0x02
   0674 12 11 26           1287 	lcall	_strcmp
   0677 AA 82              1288 	mov	r2,dpl
   0679 AB 83              1289 	mov	r3,dph
                           1290 ; Peephole 132   changed ljmp to sjmp
                           1291 ; Peephole 198   optimized misc jump sequence
   067B BA 00 10           1292 	cjne r2,#0x00,00116$
   067E BB 00 0D           1293 	cjne r3,#0x00,00116$
                           1294 ;00265$:
                           1295 ; Peephole 200   removed redundant sjmp
   0681                    1296 00266$:
                           1297 ;	usb.c 138
                           1298 ; Peephole 182   used 16 bit load of dptr
                           1299 ; Peephole 210   simplified expression
   0681 90 0C CF           1300 	mov  dptr,#__str_9
   0684 75 F0 02           1301 	mov	b,#0x02
   0687 12 0B 10           1302 	lcall	_prints
                           1303 ;	usb.c 139
   068A 78 80              1304 	mov	r0,#_state
   068C 76 03              1305 	mov	@r0,#0x03
   068E                    1306 00116$:
                           1307 ;	usb.c 141
                           1308 ; Peephole 182   used 16 bit load of dptr
                           1309 ; Peephole 210   simplified expression
   068E 90 7D C0           1310 	mov  dptr,#_OUT2BUF
   0691 75 F0 01           1311 	mov	b,#0x01
   0694 75 53 ED           1312 	mov	_strcmp_PARM_2,#__str_10
   0697 75 54 0C           1313 	mov	(_strcmp_PARM_2 + 1),#(__str_10 >> 8)
   069A 75 55 02           1314 	mov	(_strcmp_PARM_2 + 2),#0x02
   069D 12 11 26           1315 	lcall	_strcmp
   06A0 AA 82              1316 	mov	r2,dpl
   06A2 AB 83              1317 	mov	r3,dph
   06A4 BA 00 05           1318 	cjne	r2,#0x00,00267$
   06A7 BB 00 02           1319 	cjne	r3,#0x00,00267$
   06AA 80 03              1320 	sjmp	00268$
   06AC                    1321 00267$:
   06AC 02 07 17           1322 	ljmp	00121$
   06AF                    1323 00268$:
                           1324 ;	usb.c 144
                           1325 ; Peephole 182   used 16 bit load of dptr
                           1326 ; Peephole 210   simplified expression
   06AF 90 0C F4           1327 	mov  dptr,#__str_11
   06B2 75 F0 02           1328 	mov	b,#0x02
   06B5 12 0B 10           1329 	lcall	_prints
                           1330 ;	usb.c 147
   06B8                    1331 00117$:
   06B8 90 7F B8           1332 	mov	dptr,#_IN2CS
   06BB E0                 1333 	movx	a,@dptr
                           1334 ; Peephole 105   removed redundant mov
   06BC FA                 1335 	mov  r2,a
   06BD 33                 1336 	rlc	a
   06BE 95 E0              1337 	subb	a,acc
   06C0 FB                 1338 	mov	r3,a
   06C1 53 02 02           1339 	anl	ar2,#0x02
   06C4 7B 00              1340 	mov	r3,#0x00
   06C6 EA                 1341 	mov	a,r2
   06C7 4B                 1342 	orl	a,r3
                           1343 ; Peephole 109   removed ljmp by inverse jump logic
   06C8 70 EE              1344 	jnz  00117$
   06CA                    1345 00269$:
                           1346 ;	usb.c 148
   06CA 90 7E 00           1347 	mov	dptr,#_IN2BUF
   06CD 74 03              1348 	mov	a,#0x03
   06CF F0                 1349 	movx	@dptr,a
                           1350 ;	usb.c 149
   06D0 90 7E 01           1351 	mov	dptr,#(_IN2BUF + 0x0001)
   06D3 74 10              1352 	mov	a,#0x10
   06D5 F0                 1353 	movx	@dptr,a
                           1354 ;	usb.c 150
   06D6 7A 00              1355 	mov	r2,#0x00
   06D8                    1356 00168$:
   06D8 BA 10 00           1357 	cjne	r2,#0x10,00270$
   06DB                    1358 00270$:
                           1359 ; Peephole 108   removed ljmp by inverse jump logic
   06DB 50 17              1360 	jnc  00171$
   06DD                    1361 00271$:
                           1362 ;	usb.c 151
   06DD 74 02              1363 	mov	a,#0x02
   06DF 2A                 1364 	add	a,r2
   06E0 24 00              1365 	add	a,#_IN2BUF
   06E2 F5 82              1366 	mov	dpl,a
                           1367 ; Peephole 180   changed mov to clr
   06E4 E4                 1368 	clr  a
   06E5 34 7E              1369 	addc	a,#(_IN2BUF >> 8)
   06E7 F5 83              1370 	mov	dph,a
   06E9 EA                 1371 	mov	a,r2
   06EA 24 3F              1372 	add	a,#_rxbuf
   06EC F8                 1373 	mov	r0,a
   06ED 86 03              1374 	mov	ar3,@r0
   06EF EB                 1375 	mov	a,r3
   06F0 F0                 1376 	movx	@dptr,a
                           1377 ;	usb.c 150
   06F1 0A                 1378 	inc	r2
                           1379 ; Peephole 132   changed ljmp to sjmp
   06F2 80 E4              1380 	sjmp 00168$
   06F4                    1381 00171$:
                           1382 ;	usb.c 152
   06F4 90 7F B9           1383 	mov	dptr,#_IN2BC
   06F7 74 40              1384 	mov	a,#0x40
   06F9 F0                 1385 	movx	@dptr,a
                           1386 ;	usb.c 154
   06FA 75 4F 00           1387 	mov	_rxloc,#0x00
                           1388 ;	usb.c 155
   06FD 7A 00              1389 	mov	r2,#0x00
   06FF                    1390 00172$:
   06FF BA 10 00           1391 	cjne	r2,#0x10,00272$
   0702                    1392 00272$:
                           1393 ; Peephole 108   removed ljmp by inverse jump logic
   0702 50 0A              1394 	jnc  00175$
   0704                    1395 00273$:
                           1396 ;	usb.c 156
   0704 EA                 1397 	mov	a,r2
   0705 24 3F              1398 	add	a,#_rxbuf
   0707 A8 E0              1399 	mov	r0,acc
   0709 76 FF              1400 	mov	@r0,#0xFF
                           1401 ;	usb.c 155
   070B 0A                 1402 	inc	r2
                           1403 ; Peephole 132   changed ljmp to sjmp
   070C 80 F1              1404 	sjmp 00172$
   070E                    1405 00175$:
                           1406 ;	usb.c 158
                           1407 ; Peephole 182   used 16 bit load of dptr
                           1408 ; Peephole 210   simplified expression
   070E 90 0C FD           1409 	mov  dptr,#__str_12
   0711 75 F0 02           1410 	mov	b,#0x02
   0714 12 0B 10           1411 	lcall	_prints
   0717                    1412 00121$:
                           1413 ;	usb.c 161
                           1414 ; Peephole 182   used 16 bit load of dptr
                           1415 ; Peephole 210   simplified expression
   0717 90 7D C0           1416 	mov  dptr,#_OUT2BUF
   071A 75 F0 01           1417 	mov	b,#0x01
   071D 75 53 00           1418 	mov	_strcmp_PARM_2,#__str_13
   0720 75 54 0D           1419 	mov	(_strcmp_PARM_2 + 1),#(__str_13 >> 8)
   0723 75 55 02           1420 	mov	(_strcmp_PARM_2 + 2),#0x02
   0726 12 11 26           1421 	lcall	_strcmp
   0729 AA 82              1422 	mov	r2,dpl
   072B AB 83              1423 	mov	r3,dph
                           1424 ; Peephole 132   changed ljmp to sjmp
                           1425 ; Peephole 198   optimized misc jump sequence
   072D BA 00 10           1426 	cjne r2,#0x00,00123$
   0730 BB 00 0D           1427 	cjne r3,#0x00,00123$
                           1428 ;00274$:
                           1429 ; Peephole 200   removed redundant sjmp
   0733                    1430 00275$:
                           1431 ;	usb.c 162
                           1432 ; Peephole 182   used 16 bit load of dptr
                           1433 ; Peephole 210   simplified expression
   0733 90 0D 06           1434 	mov  dptr,#__str_14
   0736 75 F0 02           1435 	mov	b,#0x02
   0739 12 0B 10           1436 	lcall	_prints
                           1437 ;	usb.c 163
   073C 78 80              1438 	mov	r0,#_state
   073E 76 00              1439 	mov	@r0,#0x00
   0740                    1440 00123$:
                           1441 ;	usb.c 166
                           1442 ; Peephole 182   used 16 bit load of dptr
                           1443 ; Peephole 210   simplified expression
   0740 90 7D C0           1444 	mov  dptr,#_OUT2BUF
   0743 75 F0 01           1445 	mov	b,#0x01
   0746 75 53 1A           1446 	mov	_strcmp_PARM_2,#__str_15
   0749 75 54 0D           1447 	mov	(_strcmp_PARM_2 + 1),#(__str_15 >> 8)
   074C 75 55 02           1448 	mov	(_strcmp_PARM_2 + 2),#0x02
   074F 12 11 26           1449 	lcall	_strcmp
   0752 AA 82              1450 	mov	r2,dpl
   0754 AB 83              1451 	mov	r3,dph
                           1452 ; Peephole 132   changed ljmp to sjmp
                           1453 ; Peephole 198   optimized misc jump sequence
   0756 BA 00 1E           1454 	cjne r2,#0x00,00125$
   0759 BB 00 1B           1455 	cjne r3,#0x00,00125$
                           1456 ;00276$:
                           1457 ; Peephole 200   removed redundant sjmp
   075C                    1458 00277$:
                           1459 ;	usb.c 167
                           1460 ; Peephole 182   used 16 bit load of dptr
                           1461 ; Peephole 210   simplified expression
   075C 90 0D 20           1462 	mov  dptr,#__str_16
   075F 75 F0 02           1463 	mov	b,#0x02
   0762 12 0B 10           1464 	lcall	_prints
                           1465 ;	usb.c 168
   0765 85 31 82           1466 	mov	dpl,_timeSave
   0768 85 32 83           1467 	mov	dph,(_timeSave + 1)
   076B 12 0B 96           1468 	lcall	_printn
                           1469 ;	usb.c 169
                           1470 ; Peephole 182   used 16 bit load of dptr
                           1471 ; Peephole 210   simplified expression
   076E 90 0D 2B           1472 	mov  dptr,#__str_17
   0771 75 F0 02           1473 	mov	b,#0x02
   0774 12 0B 10           1474 	lcall	_prints
   0777                    1475 00125$:
                           1476 ;	usb.c 186
                           1477 ; Peephole 182   used 16 bit load of dptr
                           1478 ; Peephole 210   simplified expression
   0777 90 7D C0           1479 	mov  dptr,#_OUT2BUF
   077A 75 F0 01           1480 	mov	b,#0x01
   077D 75 53 2D           1481 	mov	_strcmp_PARM_2,#__str_18
   0780 75 54 0D           1482 	mov	(_strcmp_PARM_2 + 1),#(__str_18 >> 8)
   0783 75 55 02           1483 	mov	(_strcmp_PARM_2 + 2),#0x02
   0786 12 11 26           1484 	lcall	_strcmp
   0789 AA 82              1485 	mov	r2,dpl
   078B AB 83              1486 	mov	r3,dph
                           1487 ; Peephole 132   changed ljmp to sjmp
                           1488 ; Peephole 198   optimized misc jump sequence
   078D BA 00 06           1489 	cjne r2,#0x00,00127$
   0790 BB 00 03           1490 	cjne r3,#0x00,00127$
                           1491 ;00278$:
                           1492 ; Peephole 200   removed redundant sjmp
   0793                    1493 00279$:
                           1494 ;	usb.c 187
   0793 78 82              1495 	mov	r0,#_track
   0795 06                 1496 	inc	@r0
   0796                    1497 00127$:
                           1498 ;	usb.c 188
                           1499 ; Peephole 182   used 16 bit load of dptr
                           1500 ; Peephole 210   simplified expression
   0796 90 7D C0           1501 	mov  dptr,#_OUT2BUF
   0799 75 F0 01           1502 	mov	b,#0x01
   079C 75 53 31           1503 	mov	_strcmp_PARM_2,#__str_19
   079F 75 54 0D           1504 	mov	(_strcmp_PARM_2 + 1),#(__str_19 >> 8)
   07A2 75 55 02           1505 	mov	(_strcmp_PARM_2 + 2),#0x02
   07A5 12 11 26           1506 	lcall	_strcmp
   07A8 AA 82              1507 	mov	r2,dpl
   07AA AB 83              1508 	mov	r3,dph
                           1509 ; Peephole 132   changed ljmp to sjmp
                           1510 ; Peephole 198   optimized misc jump sequence
   07AC BA 00 06           1511 	cjne r2,#0x00,00129$
   07AF BB 00 03           1512 	cjne r3,#0x00,00129$
                           1513 ;00280$:
                           1514 ; Peephole 200   removed redundant sjmp
   07B2                    1515 00281$:
                           1516 ;	usb.c 189
   07B2 78 82              1517 	mov	r0,#_track
   07B4 16                 1518 	dec	@r0
   07B5                    1519 00129$:
                           1520 ;	usb.c 191
                           1521 ; Peephole 182   used 16 bit load of dptr
                           1522 ; Peephole 210   simplified expression
   07B5 90 7D C0           1523 	mov  dptr,#_OUT2BUF
   07B8 75 F0 01           1524 	mov	b,#0x01
   07BB 75 53 35           1525 	mov	_strcmp_PARM_2,#__str_20
   07BE 75 54 0D           1526 	mov	(_strcmp_PARM_2 + 1),#(__str_20 >> 8)
   07C1 75 55 02           1527 	mov	(_strcmp_PARM_2 + 2),#0x02
   07C4 12 11 26           1528 	lcall	_strcmp
   07C7 AA 82              1529 	mov	r2,dpl
   07C9 AB 83              1530 	mov	r3,dph
                           1531 ; Peephole 132   changed ljmp to sjmp
                           1532 ; Peephole 198   optimized misc jump sequence
   07CB BA 00 06           1533 	cjne r2,#0x00,00131$
   07CE BB 00 03           1534 	cjne r3,#0x00,00131$
                           1535 ;00282$:
                           1536 ; Peephole 200   removed redundant sjmp
   07D1                    1537 00283$:
                           1538 ;	usb.c 192
   07D1 78 81              1539 	mov	r0,#_disc
   07D3 06                 1540 	inc	@r0
   07D4                    1541 00131$:
                           1542 ;	usb.c 193
                           1543 ; Peephole 182   used 16 bit load of dptr
                           1544 ; Peephole 210   simplified expression
   07D4 90 7D C0           1545 	mov  dptr,#_OUT2BUF
   07D7 75 F0 01           1546 	mov	b,#0x01
   07DA 75 53 39           1547 	mov	_strcmp_PARM_2,#__str_21
   07DD 75 54 0D           1548 	mov	(_strcmp_PARM_2 + 1),#(__str_21 >> 8)
   07E0 75 55 02           1549 	mov	(_strcmp_PARM_2 + 2),#0x02
   07E3 12 11 26           1550 	lcall	_strcmp
   07E6 AA 82              1551 	mov	r2,dpl
   07E8 AB 83              1552 	mov	r3,dph
                           1553 ; Peephole 132   changed ljmp to sjmp
                           1554 ; Peephole 198   optimized misc jump sequence
   07EA BA 00 06           1555 	cjne r2,#0x00,00133$
   07ED BB 00 03           1556 	cjne r3,#0x00,00133$
                           1557 ;00284$:
                           1558 ; Peephole 200   removed redundant sjmp
   07F0                    1559 00285$:
                           1560 ;	usb.c 194
   07F0 78 81              1561 	mov	r0,#_disc
   07F2 16                 1562 	dec	@r0
   07F3                    1563 00133$:
                           1564 ;	usb.c 197
                           1565 ; Peephole 182   used 16 bit load of dptr
                           1566 ; Peephole 210   simplified expression
   07F3 90 7D C0           1567 	mov  dptr,#_OUT2BUF
   07F6 75 F0 01           1568 	mov	b,#0x01
   07F9 75 53 3D           1569 	mov	_strcmp_PARM_2,#__str_22
   07FC 75 54 0D           1570 	mov	(_strcmp_PARM_2 + 1),#(__str_22 >> 8)
   07FF 75 55 02           1571 	mov	(_strcmp_PARM_2 + 2),#0x02
   0802 12 11 26           1572 	lcall	_strcmp
   0805 AA 82              1573 	mov	r2,dpl
   0807 AB 83              1574 	mov	r3,dph
                           1575 ; Peephole 132   changed ljmp to sjmp
                           1576 ; Peephole 198   optimized misc jump sequence
   0809 BA 00 0E           1577 	cjne r2,#0x00,00135$
   080C BB 00 0B           1578 	cjne r3,#0x00,00135$
                           1579 ;00286$:
                           1580 ; Peephole 200   removed redundant sjmp
   080F                    1581 00287$:
                           1582 ;	usb.c 198
   080F C2 A9              1583 	clr	_ET0
                           1584 ;	usb.c 199
                           1585 ; Peephole 182   used 16 bit load of dptr
                           1586 ; Peephole 210   simplified expression
   0811 90 0D 43           1587 	mov  dptr,#__str_23
   0814 75 F0 02           1588 	mov	b,#0x02
   0817 12 0B 10           1589 	lcall	_prints
   081A                    1590 00135$:
                           1591 ;	usb.c 202
                           1592 ; Peephole 182   used 16 bit load of dptr
                           1593 ; Peephole 210   simplified expression
   081A 90 7D C0           1594 	mov  dptr,#_OUT2BUF
   081D 75 F0 01           1595 	mov	b,#0x01
   0820 75 53 5F           1596 	mov	_strcmp_PARM_2,#__str_24
   0823 75 54 0D           1597 	mov	(_strcmp_PARM_2 + 1),#(__str_24 >> 8)
   0826 75 55 02           1598 	mov	(_strcmp_PARM_2 + 2),#0x02
   0829 12 11 26           1599 	lcall	_strcmp
   082C AA 82              1600 	mov	r2,dpl
   082E AB 83              1601 	mov	r3,dph
                           1602 ; Peephole 132   changed ljmp to sjmp
                           1603 ; Peephole 198   optimized misc jump sequence
   0830 BA 00 24           1604 	cjne r2,#0x00,00140$
   0833 BB 00 21           1605 	cjne r3,#0x00,00140$
                           1606 ;00288$:
                           1607 ; Peephole 200   removed redundant sjmp
   0836                    1608 00289$:
                           1609 ;	usb.c 203
   0836 78 83              1610 	mov	r0,#_mix
   0838 E6                 1611 	mov	a,@r0
                           1612 ; Peephole 110   removed ljmp by inverse jump logic
   0839 60 0F              1613 	jz  00137$
   083B                    1614 00290$:
                           1615 ;	usb.c 204
                           1616 ; Peephole 182   used 16 bit load of dptr
                           1617 ; Peephole 210   simplified expression
   083B 90 0D 64           1618 	mov  dptr,#__str_25
   083E 75 F0 02           1619 	mov	b,#0x02
   0841 12 0B 10           1620 	lcall	_prints
                           1621 ;	usb.c 205
   0844 78 83              1622 	mov	r0,#_mix
   0846 76 00              1623 	mov	@r0,#0x00
                           1624 ; Peephole 132   changed ljmp to sjmp
   0848 80 0D              1625 	sjmp 00140$
   084A                    1626 00137$:
                           1627 ;	usb.c 208
                           1628 ; Peephole 182   used 16 bit load of dptr
                           1629 ; Peephole 210   simplified expression
   084A 90 0D 6D           1630 	mov  dptr,#__str_26
   084D 75 F0 02           1631 	mov	b,#0x02
   0850 12 0B 10           1632 	lcall	_prints
                           1633 ;	usb.c 209
   0853 78 83              1634 	mov	r0,#_mix
   0855 76 01              1635 	mov	@r0,#0x01
   0857                    1636 00140$:
                           1637 ;	usb.c 212
                           1638 ; Peephole 182   used 16 bit load of dptr
                           1639 ; Peephole 210   simplified expression
   0857 90 7D C0           1640 	mov  dptr,#_OUT2BUF
   085A 75 F0 01           1641 	mov	b,#0x01
   085D 75 53 75           1642 	mov	_strcmp_PARM_2,#__str_27
   0860 75 54 0D           1643 	mov	(_strcmp_PARM_2 + 1),#(__str_27 >> 8)
   0863 75 55 02           1644 	mov	(_strcmp_PARM_2 + 2),#0x02
   0866 12 11 26           1645 	lcall	_strcmp
   0869 AA 82              1646 	mov	r2,dpl
   086B AB 83              1647 	mov	r3,dph
                           1648 ; Peephole 132   changed ljmp to sjmp
                           1649 ; Peephole 198   optimized misc jump sequence
   086D BA 00 10           1650 	cjne r2,#0x00,00142$
   0870 BB 00 0D           1651 	cjne r3,#0x00,00142$
                           1652 ;00291$:
                           1653 ; Peephole 200   removed redundant sjmp
   0873                    1654 00292$:
                           1655 ;	usb.c 213
                           1656 ; Peephole 182   used 16 bit load of dptr
                           1657 ; Peephole 210   simplified expression
   0873 90 0D 7D           1658 	mov  dptr,#__str_28
   0876 75 F0 02           1659 	mov	b,#0x02
   0879 12 0B 10           1660 	lcall	_prints
                           1661 ;	usb.c 214
   087C 78 80              1662 	mov	r0,#_state
   087E 76 05              1663 	mov	@r0,#0x05
   0880                    1664 00142$:
                           1665 ;	usb.c 217
                           1666 ; Peephole 182   used 16 bit load of dptr
                           1667 ; Peephole 210   simplified expression
   0880 90 7D C0           1668 	mov  dptr,#_OUT2BUF
   0883 75 F0 01           1669 	mov	b,#0x01
   0886 75 53 93           1670 	mov	_strcmp_PARM_2,#__str_29
   0889 75 54 0D           1671 	mov	(_strcmp_PARM_2 + 1),#(__str_29 >> 8)
   088C 75 55 02           1672 	mov	(_strcmp_PARM_2 + 2),#0x02
   088F 12 11 26           1673 	lcall	_strcmp
   0892 AA 82              1674 	mov	r2,dpl
   0894 AB 83              1675 	mov	r3,dph
                           1676 ; Peephole 132   changed ljmp to sjmp
                           1677 ; Peephole 198   optimized misc jump sequence
   0896 BA 00 24           1678 	cjne r2,#0x00,00147$
   0899 BB 00 21           1679 	cjne r3,#0x00,00147$
                           1680 ;00293$:
                           1681 ; Peephole 200   removed redundant sjmp
   089C                    1682 00294$:
                           1683 ;	usb.c 218
   089C 78 84              1684 	mov	r0,#_scan
   089E E6                 1685 	mov	a,@r0
                           1686 ; Peephole 110   removed ljmp by inverse jump logic
   089F 60 0F              1687 	jz  00144$
   08A1                    1688 00295$:
                           1689 ;	usb.c 219
                           1690 ; Peephole 182   used 16 bit load of dptr
                           1691 ; Peephole 210   simplified expression
   08A1 90 0D 99           1692 	mov  dptr,#__str_30
   08A4 75 F0 02           1693 	mov	b,#0x02
   08A7 12 0B 10           1694 	lcall	_prints
                           1695 ;	usb.c 220
   08AA 78 84              1696 	mov	r0,#_scan
   08AC 76 00              1697 	mov	@r0,#0x00
                           1698 ; Peephole 132   changed ljmp to sjmp
   08AE 80 0D              1699 	sjmp 00147$
   08B0                    1700 00144$:
                           1701 ;	usb.c 223
                           1702 ; Peephole 182   used 16 bit load of dptr
                           1703 ; Peephole 210   simplified expression
   08B0 90 0D A3           1704 	mov  dptr,#__str_31
   08B3 75 F0 02           1705 	mov	b,#0x02
   08B6 12 0B 10           1706 	lcall	_prints
                           1707 ;	usb.c 224
   08B9 78 84              1708 	mov	r0,#_scan
   08BB 76 01              1709 	mov	@r0,#0x01
   08BD                    1710 00147$:
                           1711 ;	usb.c 228
                           1712 ; Peephole 182   used 16 bit load of dptr
                           1713 ; Peephole 210   simplified expression
   08BD 90 7D C0           1714 	mov  dptr,#_OUT2BUF
   08C0 75 F0 01           1715 	mov	b,#0x01
   08C3 75 53 AC           1716 	mov	_strcmp_PARM_2,#__str_32
   08C6 75 54 0D           1717 	mov	(_strcmp_PARM_2 + 1),#(__str_32 >> 8)
   08C9 75 55 02           1718 	mov	(_strcmp_PARM_2 + 2),#0x02
   08CC 12 11 26           1719 	lcall	_strcmp
   08CF AA 82              1720 	mov	r2,dpl
   08D1 AB 83              1721 	mov	r3,dph
                           1722 ; Peephole 132   changed ljmp to sjmp
                           1723 ; Peephole 198   optimized misc jump sequence
   08D3 BA 00 0E           1724 	cjne r2,#0x00,00149$
   08D6 BB 00 0B           1725 	cjne r3,#0x00,00149$
                           1726 ;00296$:
                           1727 ; Peephole 200   removed redundant sjmp
   08D9                    1728 00297$:
                           1729 ;	usb.c 229
   08D9 D2 A9              1730 	setb	_ET0
                           1731 ;	usb.c 230
                           1732 ; Peephole 182   used 16 bit load of dptr
                           1733 ; Peephole 210   simplified expression
   08DB 90 0D B0           1734 	mov  dptr,#__str_33
   08DE 75 F0 02           1735 	mov	b,#0x02
   08E1 12 0B 10           1736 	lcall	_prints
   08E4                    1737 00149$:
                           1738 ;	usb.c 233
                           1739 ; Peephole 182   used 16 bit load of dptr
                           1740 ; Peephole 210   simplified expression
   08E4 90 7D C0           1741 	mov  dptr,#_OUT2BUF
   08E7 75 F0 01           1742 	mov	b,#0x01
   08EA 75 53 CB           1743 	mov	_strcmp_PARM_2,#__str_34
   08ED 75 54 0D           1744 	mov	(_strcmp_PARM_2 + 1),#(__str_34 >> 8)
   08F0 75 55 02           1745 	mov	(_strcmp_PARM_2 + 2),#0x02
   08F3 12 11 26           1746 	lcall	_strcmp
   08F6 AA 82              1747 	mov	r2,dpl
   08F8 AB 83              1748 	mov	r3,dph
                           1749 ; Peephole 132   changed ljmp to sjmp
                           1750 ; Peephole 198   optimized misc jump sequence
   08FA BA 00 3D           1751 	cjne r2,#0x00,00155$
   08FD BB 00 3A           1752 	cjne r3,#0x00,00155$
                           1753 ;00298$:
                           1754 ; Peephole 200   removed redundant sjmp
   0900                    1755 00299$:
                           1756 ;	usb.c 234
   0900 78 80              1757 	mov	r0,#_state
   0902 B6 00 02           1758 	cjne	@r0,#0x00,00300$
                           1759 ; Peephole 132   changed ljmp to sjmp
   0905 80 0E              1760 	sjmp 00150$
   0907                    1761 00300$:
   0907 78 80              1762 	mov	r0,#_state
   0909 B6 03 02           1763 	cjne	@r0,#0x03,00301$
                           1764 ; Peephole 132   changed ljmp to sjmp
   090C 80 12              1765 	sjmp 00151$
   090E                    1766 00301$:
   090E 78 80              1767 	mov	r0,#_state
                           1768 ; Peephole 132   changed ljmp to sjmp
                           1769 ;	usb.c 236
                           1770 ; Peephole 132   changed ljmp to sjmp
                           1771 ; Peephole 199   optimized misc jump sequence
   0910 B6 05 27           1772 	cjne @r0,#0x05,00155$
   0913 80 19              1773 	sjmp 00152$
                           1774 ;00302$:
   0915                    1775 00150$:
                           1776 ; Peephole 182   used 16 bit load of dptr
                           1777 ; Peephole 210   simplified expression
   0915 90 0D D2           1778 	mov  dptr,#__str_35
   0918 75 F0 02           1779 	mov	b,#0x02
   091B 12 0B 10           1780 	lcall	_prints
                           1781 ;	usb.c 237
                           1782 ;	usb.c 239
                           1783 ; Peephole 132   changed ljmp to sjmp
   091E 80 1A              1784 	sjmp 00155$
   0920                    1785 00151$:
   0920 75 82 D8           1786 	mov	dpl,#__str_36
   0923 75 83 0D           1787 	mov	dph,#(__str_36 >> 8)
   0926 75 F0 02           1788 	mov	b,#0x02
   0929 12 0B 10           1789 	lcall	_prints
                           1790 ;	usb.c 240
                           1791 ;	usb.c 242
                           1792 ; Peephole 132   changed ljmp to sjmp
   092C 80 0C              1793 	sjmp 00155$
   092E                    1794 00152$:
   092E 75 82 E8           1795 	mov	dpl,#__str_37
   0931 75 83 0D           1796 	mov	dph,#(__str_37 >> 8)
   0934 75 F0 02           1797 	mov	b,#0x02
   0937 12 0B 10           1798 	lcall	_prints
                           1799 ;	usb.c 244
   093A                    1800 00155$:
                           1801 ;	usb.c 247
                           1802 ; Peephole 182   used 16 bit load of dptr
                           1803 ; Peephole 210   simplified expression
   093A 90 7D C0           1804 	mov  dptr,#_OUT2BUF
   093D 75 F0 01           1805 	mov	b,#0x01
   0940 75 53 F0           1806 	mov	_strcmp_PARM_2,#__str_38
   0943 75 54 0D           1807 	mov	(_strcmp_PARM_2 + 1),#(__str_38 >> 8)
   0946 75 55 02           1808 	mov	(_strcmp_PARM_2 + 2),#0x02
   0949 12 11 26           1809 	lcall	_strcmp
   094C AA 82              1810 	mov	r2,dpl
   094E AB 83              1811 	mov	r3,dph
                           1812 ; Peephole 132   changed ljmp to sjmp
                           1813 ; Peephole 198   optimized misc jump sequence
   0950 BA 00 18           1814 	cjne r2,#0x00,00157$
   0953 BB 00 15           1815 	cjne r3,#0x00,00157$
                           1816 ;00303$:
                           1817 ; Peephole 200   removed redundant sjmp
   0956                    1818 00304$:
                           1819 ;	usb.c 248
                           1820 ; Peephole 182   used 16 bit load of dptr
                           1821 ; Peephole 210   simplified expression
   0956 90 0D F9           1822 	mov  dptr,#__str_39
   0959 75 F0 02           1823 	mov	b,#0x02
   095C 12 0B 10           1824 	lcall	_prints
                           1825 ;	usb.c 249
   095F 78 80              1826 	mov	r0,#_state
   0961 76 01              1827 	mov	@r0,#0x01
                           1828 ;	usb.c 252
   0963 90 7F C9           1829 	mov	dptr,#_OUT2BC
                           1830 ; Peephole 180   changed mov to clr
   0966 E4                 1831 	clr  a
   0967 F0                 1832 	movx	@dptr,a
                           1833 ;	usb.c 253
   0968 02 0B 0F           1834 	ljmp	00192$
   096B                    1835 00157$:
                           1836 ;	usb.c 256
                           1837 ; Peephole 182   used 16 bit load of dptr
                           1838 ; Peephole 210   simplified expression
   096B 90 7D C0           1839 	mov  dptr,#_OUT2BUF
   096E 75 F0 01           1840 	mov	b,#0x01
   0971 75 53 0E           1841 	mov	_strcmp_PARM_2,#__str_40
   0974 75 54 0E           1842 	mov	(_strcmp_PARM_2 + 1),#(__str_40 >> 8)
   0977 75 55 02           1843 	mov	(_strcmp_PARM_2 + 2),#0x02
   097A 12 11 26           1844 	lcall	_strcmp
   097D AA 82              1845 	mov	r2,dpl
   097F AB 83              1846 	mov	r3,dph
                           1847 ; Peephole 132   changed ljmp to sjmp
                           1848 ; Peephole 198   optimized misc jump sequence
   0981 BA 00 10           1849 	cjne r2,#0x00,00159$
   0984 BB 00 0D           1850 	cjne r3,#0x00,00159$
                           1851 ;00305$:
                           1852 ; Peephole 200   removed redundant sjmp
   0987                    1853 00306$:
                           1854 ;	usb.c 257
                           1855 ; Peephole 182   used 16 bit load of dptr
                           1856 ; Peephole 210   simplified expression
   0987 90 0E 14           1857 	mov  dptr,#__str_41
   098A 75 F0 02           1858 	mov	b,#0x02
   098D 12 0B 10           1859 	lcall	_prints
                           1860 ;	usb.c 258
   0990 78 80              1861 	mov	r0,#_state
   0992 76 02              1862 	mov	@r0,#0x02
   0994                    1863 00159$:
                           1864 ;	usb.c 261
                           1865 ; Peephole 182   used 16 bit load of dptr
                           1866 ; Peephole 210   simplified expression
   0994 90 7D C0           1867 	mov  dptr,#_OUT2BUF
   0997 75 F0 01           1868 	mov	b,#0x01
   099A 75 53 33           1869 	mov	_strcmp_PARM_2,#__str_42
   099D 75 54 0E           1870 	mov	(_strcmp_PARM_2 + 1),#(__str_42 >> 8)
   09A0 75 55 02           1871 	mov	(_strcmp_PARM_2 + 2),#0x02
   09A3 12 11 26           1872 	lcall	_strcmp
   09A6 AA 82              1873 	mov	r2,dpl
   09A8 AB 83              1874 	mov	r3,dph
   09AA BA 00 05           1875 	cjne	r2,#0x00,00307$
   09AD BB 00 02           1876 	cjne	r3,#0x00,00307$
   09B0 80 03              1877 	sjmp	00308$
   09B2                    1878 00307$:
   09B2 02 0A E2           1879 	ljmp	00161$
   09B5                    1880 00308$:
                           1881 ;	usb.c 263
                           1882 ; Peephole 182   used 16 bit load of dptr
                           1883 ; Peephole 210   simplified expression
   09B5 90 0E 3B           1884 	mov  dptr,#__str_43
   09B8 75 F0 02           1885 	mov	b,#0x02
   09BB 12 0B 10           1886 	lcall	_prints
                           1887 ;	usb.c 265
                           1888 ; Peephole 182   used 16 bit load of dptr
                           1889 ; Peephole 210   simplified expression
   09BE 90 0E 4D           1890 	mov  dptr,#__str_44
   09C1 75 F0 02           1891 	mov	b,#0x02
   09C4 12 0B 10           1892 	lcall	_prints
                           1893 ;	usb.c 266
   09C7 AA 80              1894 	mov	r2,_IOA
                           1895 ;	usb.c 267
   09C9 7B 00              1896 	mov	r3,#0x00
   09CB                    1897 00176$:
   09CB BB 08 00           1898 	cjne	r3,#0x08,00309$
   09CE                    1899 00309$:
                           1900 ; Peephole 108   removed ljmp by inverse jump logic
   09CE 50 28              1901 	jnc  00179$
   09D0                    1902 00310$:
                           1903 ;	usb.c 268
   09D0 74 80              1904 	mov	a,#0x80
   09D2 5A                 1905 	anl	a,r2
                           1906 ; Peephole 110   removed ljmp by inverse jump logic
   09D3 60 06              1907 	jz  00194$
   09D5                    1908 00311$:
   09D5 7C 56              1909 	mov	r4,#__str_45
   09D7 7D 0E              1910 	mov	r5,#(__str_45 >> 8)
                           1911 ; Peephole 132   changed ljmp to sjmp
   09D9 80 04              1912 	sjmp 00195$
   09DB                    1913 00194$:
   09DB 7C 58              1914 	mov	r4,#__str_46
   09DD 7D 0E              1915 	mov	r5,#(__str_46 >> 8)
   09DF                    1916 00195$:
   09DF 8C 82              1917 	mov	dpl,r4
   09E1 8D 83              1918 	mov	dph,r5
   09E3 75 F0 02           1919 	mov	b,#0x02
   09E6 C0 02              1920 	push	ar2
   09E8 C0 03              1921 	push	ar3
   09EA 12 0B 10           1922 	lcall	_prints
   09ED D0 03              1923 	pop	ar3
   09EF D0 02              1924 	pop	ar2
                           1925 ;	usb.c 269
   09F1 EA                 1926 	mov	a,r2
   09F2 25 E0              1927 	add	a,acc
   09F4 FA                 1928 	mov	r2,a
                           1929 ;	usb.c 267
   09F5 0B                 1930 	inc	r3
                           1931 ; Peephole 132   changed ljmp to sjmp
   09F6 80 D3              1932 	sjmp 00176$
   09F8                    1933 00179$:
                           1934 ;	usb.c 271
                           1935 ; Peephole 182   used 16 bit load of dptr
                           1936 ; Peephole 210   simplified expression
   09F8 90 0E 5A           1937 	mov  dptr,#__str_47
   09FB 75 F0 02           1938 	mov	b,#0x02
   09FE C0 02              1939 	push	ar2
   0A00 12 0B 10           1940 	lcall	_prints
   0A03 D0 02              1941 	pop	ar2
                           1942 ;	usb.c 273
                           1943 ; Peephole 182   used 16 bit load of dptr
                           1944 ; Peephole 210   simplified expression
   0A05 90 0E 5C           1945 	mov  dptr,#__str_48
   0A08 75 F0 02           1946 	mov	b,#0x02
   0A0B C0 02              1947 	push	ar2
   0A0D 12 0B 10           1948 	lcall	_prints
   0A10 D0 02              1949 	pop	ar2
                           1950 ;	usb.c 274
   0A12 AA 90              1951 	mov	r2,_IOB
                           1952 ;	usb.c 275
   0A14 7B 00              1953 	mov	r3,#0x00
   0A16                    1954 00180$:
   0A16 BB 08 00           1955 	cjne	r3,#0x08,00312$
   0A19                    1956 00312$:
                           1957 ; Peephole 108   removed ljmp by inverse jump logic
   0A19 50 28              1958 	jnc  00183$
   0A1B                    1959 00313$:
                           1960 ;	usb.c 276
   0A1B 74 80              1961 	mov	a,#0x80
   0A1D 5A                 1962 	anl	a,r2
                           1963 ; Peephole 110   removed ljmp by inverse jump logic
   0A1E 60 06              1964 	jz  00196$
   0A20                    1965 00314$:
   0A20 7C 65              1966 	mov	r4,#__str_49
   0A22 7D 0E              1967 	mov	r5,#(__str_49 >> 8)
                           1968 ; Peephole 132   changed ljmp to sjmp
   0A24 80 04              1969 	sjmp 00197$
   0A26                    1970 00196$:
   0A26 7C 67              1971 	mov	r4,#__str_50
   0A28 7D 0E              1972 	mov	r5,#(__str_50 >> 8)
   0A2A                    1973 00197$:
   0A2A 8C 82              1974 	mov	dpl,r4
   0A2C 8D 83              1975 	mov	dph,r5
   0A2E 75 F0 02           1976 	mov	b,#0x02
   0A31 C0 02              1977 	push	ar2
   0A33 C0 03              1978 	push	ar3
   0A35 12 0B 10           1979 	lcall	_prints
   0A38 D0 03              1980 	pop	ar3
   0A3A D0 02              1981 	pop	ar2
                           1982 ;	usb.c 277
   0A3C EA                 1983 	mov	a,r2
   0A3D 25 E0              1984 	add	a,acc
   0A3F FA                 1985 	mov	r2,a
                           1986 ;	usb.c 275
   0A40 0B                 1987 	inc	r3
                           1988 ; Peephole 132   changed ljmp to sjmp
   0A41 80 D3              1989 	sjmp 00180$
   0A43                    1990 00183$:
                           1991 ;	usb.c 279
                           1992 ; Peephole 182   used 16 bit load of dptr
                           1993 ; Peephole 210   simplified expression
   0A43 90 0E 69           1994 	mov  dptr,#__str_51
   0A46 75 F0 02           1995 	mov	b,#0x02
   0A49 C0 02              1996 	push	ar2
   0A4B 12 0B 10           1997 	lcall	_prints
   0A4E D0 02              1998 	pop	ar2
                           1999 ;	usb.c 281
                           2000 ; Peephole 182   used 16 bit load of dptr
                           2001 ; Peephole 210   simplified expression
   0A50 90 0E 6B           2002 	mov  dptr,#__str_52
   0A53 75 F0 02           2003 	mov	b,#0x02
   0A56 C0 02              2004 	push	ar2
   0A58 12 0B 10           2005 	lcall	_prints
   0A5B D0 02              2006 	pop	ar2
                           2007 ;	usb.c 282
   0A5D AA A0              2008 	mov	r2,_IOC
                           2009 ;	usb.c 283
   0A5F 7B 00              2010 	mov	r3,#0x00
   0A61                    2011 00184$:
   0A61 BB 08 00           2012 	cjne	r3,#0x08,00315$
   0A64                    2013 00315$:
                           2014 ; Peephole 108   removed ljmp by inverse jump logic
   0A64 50 28              2015 	jnc  00187$
   0A66                    2016 00316$:
                           2017 ;	usb.c 284
   0A66 74 80              2018 	mov	a,#0x80
   0A68 5A                 2019 	anl	a,r2
                           2020 ; Peephole 110   removed ljmp by inverse jump logic
   0A69 60 06              2021 	jz  00198$
   0A6B                    2022 00317$:
   0A6B 7C 74              2023 	mov	r4,#__str_53
   0A6D 7D 0E              2024 	mov	r5,#(__str_53 >> 8)
                           2025 ; Peephole 132   changed ljmp to sjmp
   0A6F 80 04              2026 	sjmp 00199$
   0A71                    2027 00198$:
   0A71 7C 76              2028 	mov	r4,#__str_54
   0A73 7D 0E              2029 	mov	r5,#(__str_54 >> 8)
   0A75                    2030 00199$:
   0A75 8C 82              2031 	mov	dpl,r4
   0A77 8D 83              2032 	mov	dph,r5
   0A79 75 F0 02           2033 	mov	b,#0x02
   0A7C C0 02              2034 	push	ar2
   0A7E C0 03              2035 	push	ar3
   0A80 12 0B 10           2036 	lcall	_prints
   0A83 D0 03              2037 	pop	ar3
   0A85 D0 02              2038 	pop	ar2
                           2039 ;	usb.c 285
   0A87 EA                 2040 	mov	a,r2
   0A88 25 E0              2041 	add	a,acc
   0A8A FA                 2042 	mov	r2,a
                           2043 ;	usb.c 283
   0A8B 0B                 2044 	inc	r3
                           2045 ; Peephole 132   changed ljmp to sjmp
   0A8C 80 D3              2046 	sjmp 00184$
   0A8E                    2047 00187$:
                           2048 ;	usb.c 287
                           2049 ; Peephole 182   used 16 bit load of dptr
                           2050 ; Peephole 210   simplified expression
   0A8E 90 0E 78           2051 	mov  dptr,#__str_55
   0A91 75 F0 02           2052 	mov	b,#0x02
   0A94 C0 02              2053 	push	ar2
   0A96 12 0B 10           2054 	lcall	_prints
   0A99 D0 02              2055 	pop	ar2
                           2056 ;	usb.c 289
                           2057 ; Peephole 182   used 16 bit load of dptr
                           2058 ; Peephole 210   simplified expression
   0A9B 90 0E 7A           2059 	mov  dptr,#__str_56
   0A9E 75 F0 02           2060 	mov	b,#0x02
   0AA1 C0 02              2061 	push	ar2
   0AA3 12 0B 10           2062 	lcall	_prints
   0AA6 D0 02              2063 	pop	ar2
                           2064 ;	usb.c 290
   0AA8 AA B0              2065 	mov	r2,_IOD
                           2066 ;	usb.c 291
   0AAA 7B 00              2067 	mov	r3,#0x00
   0AAC                    2068 00188$:
   0AAC BB 08 00           2069 	cjne	r3,#0x08,00318$
   0AAF                    2070 00318$:
                           2071 ; Peephole 108   removed ljmp by inverse jump logic
   0AAF 50 28              2072 	jnc  00191$
   0AB1                    2073 00319$:
                           2074 ;	usb.c 292
   0AB1 74 80              2075 	mov	a,#0x80
   0AB3 5A                 2076 	anl	a,r2
                           2077 ; Peephole 110   removed ljmp by inverse jump logic
   0AB4 60 06              2078 	jz  00200$
   0AB6                    2079 00320$:
   0AB6 7C 83              2080 	mov	r4,#__str_57
   0AB8 7D 0E              2081 	mov	r5,#(__str_57 >> 8)
                           2082 ; Peephole 132   changed ljmp to sjmp
   0ABA 80 04              2083 	sjmp 00201$
   0ABC                    2084 00200$:
   0ABC 7C 85              2085 	mov	r4,#__str_58
   0ABE 7D 0E              2086 	mov	r5,#(__str_58 >> 8)
   0AC0                    2087 00201$:
   0AC0 8C 82              2088 	mov	dpl,r4
   0AC2 8D 83              2089 	mov	dph,r5
   0AC4 75 F0 02           2090 	mov	b,#0x02
   0AC7 C0 02              2091 	push	ar2
   0AC9 C0 03              2092 	push	ar3
   0ACB 12 0B 10           2093 	lcall	_prints
   0ACE D0 03              2094 	pop	ar3
   0AD0 D0 02              2095 	pop	ar2
                           2096 ;	usb.c 293
   0AD2 EA                 2097 	mov	a,r2
   0AD3 25 E0              2098 	add	a,acc
   0AD5 FA                 2099 	mov	r2,a
                           2100 ;	usb.c 291
   0AD6 0B                 2101 	inc	r3
                           2102 ; Peephole 132   changed ljmp to sjmp
   0AD7 80 D3              2103 	sjmp 00188$
   0AD9                    2104 00191$:
                           2105 ;	usb.c 295
                           2106 ; Peephole 182   used 16 bit load of dptr
                           2107 ; Peephole 210   simplified expression
   0AD9 90 0E 87           2108 	mov  dptr,#__str_59
   0ADC 75 F0 02           2109 	mov	b,#0x02
   0ADF 12 0B 10           2110 	lcall	_prints
   0AE2                    2111 00161$:
                           2112 ;	usb.c 298
                           2113 ; Peephole 182   used 16 bit load of dptr
                           2114 ; Peephole 210   simplified expression
   0AE2 90 7D C0           2115 	mov  dptr,#_OUT2BUF
   0AE5 75 F0 01           2116 	mov	b,#0x01
   0AE8 75 53 89           2117 	mov	_strcmp_PARM_2,#__str_60
   0AEB 75 54 0E           2118 	mov	(_strcmp_PARM_2 + 1),#(__str_60 >> 8)
   0AEE 75 55 02           2119 	mov	(_strcmp_PARM_2 + 2),#0x02
   0AF1 12 11 26           2120 	lcall	_strcmp
   0AF4 AA 82              2121 	mov	r2,dpl
   0AF6 AB 83              2122 	mov	r3,dph
                           2123 ; Peephole 132   changed ljmp to sjmp
                           2124 ; Peephole 198   optimized misc jump sequence
   0AF8 BA 00 0C           2125 	cjne r2,#0x00,00163$
   0AFB BB 00 09           2126 	cjne r3,#0x00,00163$
                           2127 ;00321$:
                           2128 ; Peephole 200   removed redundant sjmp
   0AFE                    2129 00322$:
                           2130 ;	usb.c 299
                           2131 ; Peephole 182   used 16 bit load of dptr
                           2132 ; Peephole 210   simplified expression
   0AFE 90 0E 8B           2133 	mov  dptr,#__str_61
   0B01 75 F0 02           2134 	mov	b,#0x02
   0B04 12 0B 10           2135 	lcall	_prints
   0B07                    2136 00163$:
                           2137 ;	usb.c 301
   0B07 12 0B F8           2138 	lcall	_printDone
                           2139 ;	usb.c 303
   0B0A 90 7F C9           2140 	mov	dptr,#_OUT2BC
                           2141 ; Peephole 180   changed mov to clr
   0B0D E4                 2142 	clr  a
   0B0E F0                 2143 	movx	@dptr,a
   0B0F                    2144 00192$:
                    071F   2145 	C$usb.c$304$1$1 ==.
                    071F   2146 	XG$ep2outUSB$0$0 ==.
   0B0F 22                 2147 	ret
                           2148 ;------------------------------------------------------------
                           2149 ;Allocation info for local variables in function 'prints'
                           2150 ;------------------------------------------------------------
                           2151 ;s                         Allocated to registers r2 r3 r4 
                           2152 ;i                         Allocated to registers r5 
                    0720   2153 	G$prints$0$0 ==.
                           2154 ;	usb.c 307
                           2155 ;	-----------------------------------------
                           2156 ;	 function prints
                           2157 ;	-----------------------------------------
   0B10                    2158 _prints:
                           2159 ;	usb.c 328
   0B10 AA 82              2160 	mov	r2,dpl
   0B12 AB 83              2161 	mov	r3,dph
   0B14 AC F0              2162 	mov	r4,b
                           2163 ;	usb.c 311
   0B16 7D 01              2164 	mov	r5,#0x01
   0B18                    2165 00103$:
   0B18 ED                 2166 	mov	a,r5
                           2167 ; Peephole 110   removed ljmp by inverse jump logic
   0B19 60 26              2168 	jz  00106$
   0B1B                    2169 00124$:
                           2170 ;	usb.c 312
   0B1B 90 7F B8           2171 	mov	dptr,#_IN2CS
   0B1E E0                 2172 	movx	a,@dptr
   0B1F FE                 2173 	mov	r6,a
   0B20 53 06 02           2174 	anl	ar6,#0x02
   0B23 BE 00 02           2175 	cjne	r6,#0x00,00125$
                           2176 ; Peephole 132   changed ljmp to sjmp
   0B26 80 19              2177 	sjmp 00106$
   0B28                    2178 00125$:
                           2179 ;	usb.c 315
   0B28 C0 02              2180 	push	ar2
   0B2A C0 03              2181 	push	ar3
   0B2C C0 04              2182 	push	ar4
   0B2E C0 05              2183 	push	ar5
                           2184 ; Peephole 182   used 16 bit load of dptr
   0B30 90 00 0A           2185 	mov  dptr,#(((0x00)<<8) + 0x0A)
   0B33 12 03 08           2186 	lcall	_msecWait
   0B36 D0 05              2187 	pop	ar5
   0B38 D0 04              2188 	pop	ar4
   0B3A D0 03              2189 	pop	ar3
   0B3C D0 02              2190 	pop	ar2
                           2191 ;	usb.c 311
   0B3E 0D                 2192 	inc	r5
                           2193 ; Peephole 132   changed ljmp to sjmp
   0B3F 80 D7              2194 	sjmp 00103$
   0B41                    2195 00106$:
                           2196 ;	usb.c 317
   0B41 90 7F B8           2197 	mov	dptr,#_IN2CS
   0B44 E0                 2198 	movx	a,@dptr
                           2199 ; Peephole 105   removed redundant mov
   0B45 FD                 2200 	mov  r5,a
   0B46 33                 2201 	rlc	a
   0B47 95 E0              2202 	subb	a,acc
   0B49 FE                 2203 	mov	r6,a
   0B4A 53 05 02           2204 	anl	ar5,#0x02
   0B4D 7E 00              2205 	mov	r6,#0x00
   0B4F ED                 2206 	mov	a,r5
   0B50 4E                 2207 	orl	a,r6
                           2208 ; Peephole 110   removed ljmp by inverse jump logic
   0B51 60 05              2209 	jz  00108$
   0B53                    2210 00126$:
                           2211 ;	usb.c 318
   0B53 75 82 FF           2212 	mov	dpl,#0xFF
                           2213 ; Peephole 132   changed ljmp to sjmp
   0B56 80 3D              2214 	sjmp 00115$
   0B58                    2215 00108$:
                           2216 ;	usb.c 320
   0B58 90 7E 00           2217 	mov	dptr,#_IN2BUF
   0B5B 74 01              2218 	mov	a,#0x01
   0B5D F0                 2219 	movx	@dptr,a
                           2220 ;	usb.c 321
   0B5E 7D 00              2221 	mov	r5,#0x00
   0B60                    2222 00111$:
   0B60 BD 3F 00           2223 	cjne	r5,#0x3F,00127$
   0B63                    2224 00127$:
                           2225 ; Peephole 108   removed ljmp by inverse jump logic
   0B63 50 27              2226 	jnc  00114$
   0B65                    2227 00128$:
                           2228 ;	usb.c 322
   0B65 74 01              2229 	mov	a,#0x01
   0B67 2D                 2230 	add	a,r5
                           2231 ; Peephole 105   removed redundant mov
   0B68 FE                 2232 	mov  r6,a
   0B69 24 00              2233 	add	a,#_IN2BUF
   0B6B FF                 2234 	mov	r7,a
                           2235 ; Peephole 180   changed mov to clr
   0B6C E4                 2236 	clr  a
   0B6D 34 7E              2237 	addc	a,#(_IN2BUF >> 8)
   0B6F F8                 2238 	mov	r0,a
   0B70 ED                 2239 	mov	a,r5
   0B71 2A                 2240 	add	a,r2
   0B72 F5 82              2241 	mov	dpl,a
                           2242 ; Peephole 180   changed mov to clr
   0B74 E4                 2243 	clr  a
   0B75 3B                 2244 	addc	a,r3
   0B76 F5 83              2245 	mov	dph,a
   0B78 8C F0              2246 	mov	b,r4
   0B7A 12 11 8D           2247 	lcall	__gptrget
                           2248 ; Peephole 136   removed redundant moves
   0B7D F9                 2249 	mov  r1,a
   0B7E 8F 82              2250 	mov  dpl,r7
   0B80 88 83              2251 	mov  dph,r0
   0B82 F0                 2252 	movx	@dptr,a
                           2253 ;	usb.c 323
   0B83 B9 00 02           2254 	cjne	r1,#0x00,00129$
                           2255 ; Peephole 132   changed ljmp to sjmp
   0B86 80 04              2256 	sjmp 00114$
   0B88                    2257 00129$:
                           2258 ;	usb.c 321
   0B88 8E 05              2259 	mov	ar5,r6
                           2260 ; Peephole 132   changed ljmp to sjmp
   0B8A 80 D4              2261 	sjmp 00111$
   0B8C                    2262 00114$:
                           2263 ;	usb.c 327
   0B8C 90 7F B9           2264 	mov	dptr,#_IN2BC
   0B8F 74 40              2265 	mov	a,#0x40
   0B91 F0                 2266 	movx	@dptr,a
                           2267 ;	usb.c 328
   0B92 75 82 00           2268 	mov	dpl,#0x00
   0B95                    2269 00115$:
                    07A5   2270 	C$usb.c$329$1$1 ==.
                    07A5   2271 	XG$prints$0$0 ==.
   0B95 22                 2272 	ret
                           2273 ;------------------------------------------------------------
                           2274 ;Allocation info for local variables in function 'printn'
                           2275 ;------------------------------------------------------------
                           2276 ;val                       Allocated to registers r2 r3 
                           2277 ;i                         Allocated to registers 
                    07A6   2278 	G$printn$0$0 ==.
                           2279 ;	usb.c 331
                           2280 ;	-----------------------------------------
                           2281 ;	 function printn
                           2282 ;	-----------------------------------------
   0B96                    2283 _printn:
                           2284 ;	usb.c 348
   0B96 AA 82              2285 	mov	r2,dpl
   0B98 AB 83              2286 	mov	r3,dph
                           2287 ;	usb.c 335
   0B9A 7C 01              2288 	mov	r4,#0x01
   0B9C                    2289 00103$:
   0B9C EC                 2290 	mov	a,r4
                           2291 ; Peephole 110   removed ljmp by inverse jump logic
   0B9D 60 22              2292 	jz  00106$
   0B9F                    2293 00115$:
                           2294 ;	usb.c 336
   0B9F 90 7F B8           2295 	mov	dptr,#_IN2CS
   0BA2 E0                 2296 	movx	a,@dptr
   0BA3 FD                 2297 	mov	r5,a
   0BA4 53 05 02           2298 	anl	ar5,#0x02
   0BA7 BD 00 02           2299 	cjne	r5,#0x00,00116$
                           2300 ; Peephole 132   changed ljmp to sjmp
   0BAA 80 15              2301 	sjmp 00106$
   0BAC                    2302 00116$:
                           2303 ;	usb.c 339
   0BAC C0 02              2304 	push	ar2
   0BAE C0 03              2305 	push	ar3
   0BB0 C0 04              2306 	push	ar4
                           2307 ; Peephole 182   used 16 bit load of dptr
   0BB2 90 00 0A           2308 	mov  dptr,#(((0x00)<<8) + 0x0A)
   0BB5 12 03 08           2309 	lcall	_msecWait
   0BB8 D0 04              2310 	pop	ar4
   0BBA D0 03              2311 	pop	ar3
   0BBC D0 02              2312 	pop	ar2
                           2313 ;	usb.c 335
   0BBE 0C                 2314 	inc	r4
                           2315 ; Peephole 132   changed ljmp to sjmp
   0BBF 80 DB              2316 	sjmp 00103$
   0BC1                    2317 00106$:
                           2318 ;	usb.c 341
   0BC1 90 7F B8           2319 	mov	dptr,#_IN2CS
   0BC4 E0                 2320 	movx	a,@dptr
                           2321 ; Peephole 105   removed redundant mov
   0BC5 FC                 2322 	mov  r4,a
   0BC6 33                 2323 	rlc	a
   0BC7 95 E0              2324 	subb	a,acc
   0BC9 FD                 2325 	mov	r5,a
   0BCA 53 04 02           2326 	anl	ar4,#0x02
   0BCD 7D 00              2327 	mov	r5,#0x00
   0BCF EC                 2328 	mov	a,r4
   0BD0 4D                 2329 	orl	a,r5
                           2330 ; Peephole 110   removed ljmp by inverse jump logic
   0BD1 60 05              2331 	jz  00108$
   0BD3                    2332 00117$:
                           2333 ;	usb.c 342
   0BD3 75 82 FF           2334 	mov	dpl,#0xFF
                           2335 ; Peephole 132   changed ljmp to sjmp
   0BD6 80 1F              2336 	sjmp 00109$
   0BD8                    2337 00108$:
                           2338 ;	usb.c 344
   0BD8 90 7E 00           2339 	mov	dptr,#_IN2BUF
   0BDB 74 02              2340 	mov	a,#0x02
   0BDD F0                 2341 	movx	@dptr,a
                           2342 ;	usb.c 345
   0BDE 8A 04              2343 	mov	ar4,r2
   0BE0 90 7E 01           2344 	mov	dptr,#(_IN2BUF + 0x0001)
   0BE3 EC                 2345 	mov	a,r4
   0BE4 F0                 2346 	movx	@dptr,a
                           2347 ;	usb.c 346
   0BE5 8B 02              2348 	mov	ar2,r3
   0BE7 7B 00              2349 	mov	r3,#0x00
   0BE9 90 7E 02           2350 	mov	dptr,#(_IN2BUF + 0x0002)
   0BEC EA                 2351 	mov	a,r2
   0BED F0                 2352 	movx	@dptr,a
                           2353 ;	usb.c 347
   0BEE 90 7F B9           2354 	mov	dptr,#_IN2BC
   0BF1 74 40              2355 	mov	a,#0x40
   0BF3 F0                 2356 	movx	@dptr,a
                           2357 ;	usb.c 348
   0BF4 75 82 00           2358 	mov	dpl,#0x00
   0BF7                    2359 00109$:
                    0807   2360 	C$usb.c$349$1$1 ==.
                    0807   2361 	XG$printn$0$0 ==.
   0BF7 22                 2362 	ret
                           2363 ;------------------------------------------------------------
                           2364 ;Allocation info for local variables in function 'printDone'
                           2365 ;------------------------------------------------------------
                           2366 ;i                         Allocated to registers 
                    0808   2367 	G$printDone$0$0 ==.
                           2368 ;	usb.c 351
                           2369 ;	-----------------------------------------
                           2370 ;	 function printDone
                           2371 ;	-----------------------------------------
   0BF8                    2372 _printDone:
                           2373 ;	usb.c 355
   0BF8 7A 01              2374 	mov	r2,#0x01
   0BFA                    2375 00103$:
   0BFA EA                 2376 	mov	a,r2
                           2377 ; Peephole 110   removed ljmp by inverse jump logic
   0BFB 60 1A              2378 	jz  00106$
   0BFD                    2379 00115$:
                           2380 ;	usb.c 356
   0BFD 90 7F B8           2381 	mov	dptr,#_IN2CS
   0C00 E0                 2382 	movx	a,@dptr
   0C01 FB                 2383 	mov	r3,a
   0C02 53 03 02           2384 	anl	ar3,#0x02
   0C05 BB 00 02           2385 	cjne	r3,#0x00,00116$
                           2386 ; Peephole 132   changed ljmp to sjmp
   0C08 80 0D              2387 	sjmp 00106$
   0C0A                    2388 00116$:
                           2389 ;	usb.c 359
   0C0A C0 02              2390 	push	ar2
                           2391 ; Peephole 182   used 16 bit load of dptr
   0C0C 90 00 0A           2392 	mov  dptr,#(((0x00)<<8) + 0x0A)
   0C0F 12 03 08           2393 	lcall	_msecWait
   0C12 D0 02              2394 	pop	ar2
                           2395 ;	usb.c 355
   0C14 0A                 2396 	inc	r2
                           2397 ; Peephole 132   changed ljmp to sjmp
   0C15 80 E3              2398 	sjmp 00103$
   0C17                    2399 00106$:
                           2400 ;	usb.c 361
   0C17 90 7F B8           2401 	mov	dptr,#_IN2CS
   0C1A E0                 2402 	movx	a,@dptr
                           2403 ; Peephole 105   removed redundant mov
   0C1B FA                 2404 	mov  r2,a
   0C1C 33                 2405 	rlc	a
   0C1D 95 E0              2406 	subb	a,acc
   0C1F FB                 2407 	mov	r3,a
   0C20 53 02 02           2408 	anl	ar2,#0x02
   0C23 7B 00              2409 	mov	r3,#0x00
   0C25 EA                 2410 	mov	a,r2
   0C26 4B                 2411 	orl	a,r3
                           2412 ; Peephole 110   removed ljmp by inverse jump logic
   0C27 60 05              2413 	jz  00108$
   0C29                    2414 00117$:
                           2415 ;	usb.c 362
   0C29 75 82 FF           2416 	mov	dpl,#0xFF
                           2417 ; Peephole 132   changed ljmp to sjmp
   0C2C 80 0E              2418 	sjmp 00109$
   0C2E                    2419 00108$:
                           2420 ;	usb.c 364
   0C2E 90 7E 00           2421 	mov	dptr,#_IN2BUF
                           2422 ; Peephole 180   changed mov to clr
   0C31 E4                 2423 	clr  a
   0C32 F0                 2424 	movx	@dptr,a
                           2425 ;	usb.c 365
   0C33 90 7F B9           2426 	mov	dptr,#_IN2BC
   0C36 74 40              2427 	mov	a,#0x40
   0C38 F0                 2428 	movx	@dptr,a
                           2429 ;	usb.c 366
   0C39 75 82 00           2430 	mov	dpl,#0x00
   0C3C                    2431 00109$:
                    084C   2432 	C$usb.c$367$1$1 ==.
                    084C   2433 	XG$printDone$0$0 ==.
   0C3C 22                 2434 	ret
                           2435 	.area CSEG    (CODE)
                    084D   2436 Fusb$_str_0$0$0 == .
   0C3D                    2437 __str_0:
   0C3D 69 64              2438 	.ascii "id"
   0C3F 0A                 2439 	.db 0x0A
   0C40 00                 2440 	.db 0x00
                    0851   2441 Fusb$_str_1$0$0 == .
   0C41                    2442 __str_1:
   0C41 45 5A 20 50 72 6F  2443 	.ascii "EZ Protoboard Console Firmware v1.0.0"
        74 6F 62 6F 61 72
        64 20 43 6F 6E 73
        6F 6C 65 20 46 69
        72 6D 77 61 72 65
        20 76 31 2E 30 2E
        30
   0C66 0A                 2444 	.db 0x0A
   0C67 00                 2445 	.db 0x00
                    0878   2446 Fusb$_str_2$0$0 == .
   0C68                    2447 __str_2:
   0C68 43 6F 70 79 72 69  2448 	.ascii "Copyright (c) 2001, Ed Schlunder <zilym@yahoo.com>"
        67 68 74 20 28 63
        29 20 32 30 30 31
        2C 20 45 64 20 53
        63 68 6C 75 6E 64
        65 72 20 3C 7A 69
        6C 79 6D 40 79 61
        68 6F 6F 2E 63 6F
        6D 3E
   0C9A 0A                 2449 	.db 0x0A
   0C9B 0A                 2450 	.db 0x0A
   0C9C 00                 2451 	.db 0x00
                    08AD   2452 Fusb$_str_3$0$0 == .
   0C9D                    2453 __str_3:
   0C9D 73 70 65 65 64     2454 	.ascii "speed"
   0CA2 0A                 2455 	.db 0x0A
   0CA3 00                 2456 	.db 0x00
                    08B4   2457 Fusb$_str_4$0$0 == .
   0CA4                    2458 __str_4:
   0CA4 34 38 4D 48 7A     2459 	.ascii "48MHz"
   0CA9 0A                 2460 	.db 0x0A
   0CAA 0A                 2461 	.db 0x0A
   0CAB 00                 2462 	.db 0x00
                    08BC   2463 Fusb$_str_5$0$0 == .
   0CAC                    2464 __str_5:
   0CAC 32 34 4D 48 7A     2465 	.ascii "24MHz"
   0CB1 0A                 2466 	.db 0x0A
   0CB2 0A                 2467 	.db 0x0A
   0CB3 00                 2468 	.db 0x00
                    08C4   2469 Fusb$_str_6$0$0 == .
   0CB4                    2470 __str_6:
   0CB4 6E 65 78 74        2471 	.ascii "next"
   0CB8 0A                 2472 	.db 0x0A
   0CB9 00                 2473 	.db 0x00
                    08CA   2474 Fusb$_str_7$0$0 == .
   0CBA                    2475 __str_7:
   0CBA 6E 65 78 74 20 6D  2476 	.ascii "next mp3 song"
        70 33 20 73 6F 6E
        67
   0CC7 0A                 2477 	.db 0x0A
   0CC8 00                 2478 	.db 0x00
                    08D9   2479 Fusb$_str_8$0$0 == .
   0CC9                    2480 __str_8:
   0CC9 70 61 73 73        2481 	.ascii "pass"
   0CCD 0A                 2482 	.db 0x0A
   0CCE 00                 2483 	.db 0x00
                    08DF   2484 Fusb$_str_9$0$0 == .
   0CCF                    2485 __str_9:
   0CCF 53 74 61 74 65 20  2486 	.ascii "State Change: CD Passthrough"
        43 68 61 6E 67 65
        3A 20 43 44 20 50
        61 73 73 74 68 72
        6F 75 67 68
   0CEB 0A                 2487 	.db 0x0A
   0CEC 00                 2488 	.db 0x00
                    08FD   2489 Fusb$_str_10$0$0 == .
   0CED                    2490 __str_10:
   0CED 72 78 62 75 66     2491 	.ascii "rxbuf"
   0CF2 0A                 2492 	.db 0x0A
   0CF3 00                 2493 	.db 0x00
                    0904   2494 Fusb$_str_11$0$0 == .
   0CF4                    2495 __str_11:
   0CF4 52 58 42 55 46 3A  2496 	.ascii "RXBUF: ["
        20 5B
   0CFC 00                 2497 	.db 0x00
                    090D   2498 Fusb$_str_12$0$0 == .
   0CFD                    2499 __str_12:
   0CFD 5D                 2500 	.ascii "]"
   0CFE 0A                 2501 	.db 0x0A
   0CFF 00                 2502 	.db 0x00
                    0910   2503 Fusb$_str_13$0$0 == .
   0D00                    2504 __str_13:
   0D00 69 64 6C 65        2505 	.ascii "idle"
   0D04 0A                 2506 	.db 0x0A
   0D05 00                 2507 	.db 0x00
                    0916   2508 Fusb$_str_14$0$0 == .
   0D06                    2509 __str_14:
   0D06 53 74 61 74 65 20  2510 	.ascii "State Change: Idle"
        43 68 61 6E 67 65
        3A 20 49 64 6C 65
   0D18 0A                 2511 	.db 0x0A
   0D19 00                 2512 	.db 0x00
                    092A   2513 Fusb$_str_15$0$0 == .
   0D1A                    2514 __str_15:
   0D1A 74 69 6D 65        2515 	.ascii "time"
   0D1E 0A                 2516 	.db 0x0A
   0D1F 00                 2517 	.db 0x00
                    0930   2518 Fusb$_str_16$0$0 == .
   0D20                    2519 __str_16:
   0D20 74 69 6D 65 53 61  2520 	.ascii "timeSave: "
        76 65 3A 20
   0D2A 00                 2521 	.db 0x00
                    093B   2522 Fusb$_str_17$0$0 == .
   0D2B                    2523 __str_17:
   0D2B 0A                 2524 	.db 0x0A
   0D2C 00                 2525 	.db 0x00
                    093D   2526 Fusb$_str_18$0$0 == .
   0D2D                    2527 __str_18:
   0D2D 74 2B              2528 	.ascii "t+"
   0D2F 0A                 2529 	.db 0x0A
   0D30 00                 2530 	.db 0x00
                    0941   2531 Fusb$_str_19$0$0 == .
   0D31                    2532 __str_19:
   0D31 74 2D              2533 	.ascii "t-"
   0D33 0A                 2534 	.db 0x0A
   0D34 00                 2535 	.db 0x00
                    0945   2536 Fusb$_str_20$0$0 == .
   0D35                    2537 __str_20:
   0D35 64 2B              2538 	.ascii "d+"
   0D37 0A                 2539 	.db 0x0A
   0D38 00                 2540 	.db 0x00
                    0949   2541 Fusb$_str_21$0$0 == .
   0D39                    2542 __str_21:
   0D39 64 2D              2543 	.ascii "d-"
   0D3B 0A                 2544 	.db 0x0A
   0D3C 00                 2545 	.db 0x00
                    094D   2546 Fusb$_str_22$0$0 == .
   0D3D                    2547 __str_22:
   0D3D 73 74 6F 70        2548 	.ascii "stop"
   0D41 0A                 2549 	.db 0x0A
   0D42 00                 2550 	.db 0x00
                    0953   2551 Fusb$_str_23$0$0 == .
   0D43                    2552 __str_23:
   0D43 63 64 20 65 6D 75  2553 	.ascii "cd emulator timer disabled"
        6C 61 74 6F 72 20
        74 69 6D 65 72 20
        64 69 73 61 62 6C
        65 64
   0D5D 0A                 2554 	.db 0x0A
   0D5E 00                 2555 	.db 0x00
                    096F   2556 Fusb$_str_24$0$0 == .
   0D5F                    2557 __str_24:
   0D5F 6D 69 78           2558 	.ascii "mix"
   0D62 0A                 2559 	.db 0x0A
   0D63 00                 2560 	.db 0x00
                    0974   2561 Fusb$_str_25$0$0 == .
   0D64                    2562 __str_25:
   0D64 6D 69 78 20 6F 66  2563 	.ascii "mix off"
        66
   0D6B 0A                 2564 	.db 0x0A
   0D6C 00                 2565 	.db 0x00
                    097D   2566 Fusb$_str_26$0$0 == .
   0D6D                    2567 __str_26:
   0D6D 6D 69 78 20 6F 6E  2568 	.ascii "mix on"
   0D73 0A                 2569 	.db 0x0A
   0D74 00                 2570 	.db 0x00
                    0985   2571 Fusb$_str_27$0$0 == .
   0D75                    2572 __str_27:
   0D75 73 69 6D 70 6C 65  2573 	.ascii "simple"
   0D7B 0A                 2574 	.db 0x0A
   0D7C 00                 2575 	.db 0x00
                    098D   2576 Fusb$_str_28$0$0 == .
   0D7D                    2577 __str_28:
   0D7D 67 6F 69 6E 67 20  2578 	.ascii "going to simple mode"
        74 6F 20 73 69 6D
        70 6C 65 20 6D 6F
        64 65
   0D91 0A                 2579 	.db 0x0A
   0D92 00                 2580 	.db 0x00
                    09A3   2581 Fusb$_str_29$0$0 == .
   0D93                    2582 __str_29:
   0D93 73 63 61 6E        2583 	.ascii "scan"
   0D97 0A                 2584 	.db 0x0A
   0D98 00                 2585 	.db 0x00
                    09A9   2586 Fusb$_str_30$0$0 == .
   0D99                    2587 __str_30:
   0D99 73 63 61 6E 20 6F  2588 	.ascii "scan off"
        66 66
   0DA1 0A                 2589 	.db 0x0A
   0DA2 00                 2590 	.db 0x00
                    09B3   2591 Fusb$_str_31$0$0 == .
   0DA3                    2592 __str_31:
   0DA3 73 63 61 6E 20 6F  2593 	.ascii "scan on"
        6E
   0DAA 0A                 2594 	.db 0x0A
   0DAB 00                 2595 	.db 0x00
                    09BC   2596 Fusb$_str_32$0$0 == .
   0DAC                    2597 __str_32:
   0DAC 67 6F              2598 	.ascii "go"
   0DAE 0A                 2599 	.db 0x0A
   0DAF 00                 2600 	.db 0x00
                    09C0   2601 Fusb$_str_33$0$0 == .
   0DB0                    2602 __str_33:
   0DB0 63 64 20 65 6D 75  2603 	.ascii "cd emulator timer enabled"
        6C 61 74 6F 72 20
        74 69 6D 65 72 20
        65 6E 61 62 6C 65
        64
   0DC9 0A                 2604 	.db 0x0A
   0DCA 00                 2605 	.db 0x00
                    09DB   2606 Fusb$_str_34$0$0 == .
   0DCB                    2607 __str_34:
   0DCB 73 74 61 74 65     2608 	.ascii "state"
   0DD0 0A                 2609 	.db 0x0A
   0DD1 00                 2610 	.db 0x00
                    09E2   2611 Fusb$_str_35$0$0 == .
   0DD2                    2612 __str_35:
   0DD2 69 64 6C 65        2613 	.ascii "idle"
   0DD6 0A                 2614 	.db 0x0A
   0DD7 00                 2615 	.db 0x00
                    09E8   2616 Fusb$_str_36$0$0 == .
   0DD8                    2617 __str_36:
   0DD8 63 64 20 70 61 73  2618 	.ascii "cd passthrough"
        73 74 68 72 6F 75
        67 68
   0DE6 0A                 2619 	.db 0x0A
   0DE7 00                 2620 	.db 0x00
                    09F8   2621 Fusb$_str_37$0$0 == .
   0DE8                    2622 __str_37:
   0DE8 73 69 6D 70 6C 65  2623 	.ascii "simple"
   0DEE 0A                 2624 	.db 0x0A
   0DEF 00                 2625 	.db 0x00
                    0A00   2626 Fusb$_str_38$0$0 == .
   0DF0                    2627 __str_38:
   0DF0 63 61 70 74 75 72  2628 	.ascii "capture"
        65
   0DF7 0A                 2629 	.db 0x0A
   0DF8 00                 2630 	.db 0x00
                    0A09   2631 Fusb$_str_39$0$0 == .
   0DF9                    2632 __str_39:
   0DF9 73 74 61 72 74 69  2633 	.ascii "starting capture..."
        6E 67 20 63 61 70
        74 75 72 65 2E 2E
        2E
   0E0C 0A                 2634 	.db 0x0A
   0E0D 00                 2635 	.db 0x00
                    0A1E   2636 Fusb$_str_40$0$0 == .
   0E0E                    2637 __str_40:
   0E0E 68 65 61 64        2638 	.ascii "head"
   0E12 0A                 2639 	.db 0x0A
   0E13 00                 2640 	.db 0x00
                    0A24   2641 Fusb$_str_41$0$0 == .
   0E14                    2642 __str_41:
   0E14 73 74 61 72 74 69  2643 	.ascii "starting head unit capture..."
        6E 67 20 68 65 61
        64 20 75 6E 69 74
        20 63 61 70 74 75
        72 65 2E 2E 2E
   0E31 0A                 2644 	.db 0x0A
   0E32 00                 2645 	.db 0x00
                    0A43   2646 Fusb$_str_42$0$0 == .
   0E33                    2647 __str_42:
   0E33 73 74 61 74 75 73  2648 	.ascii "status"
   0E39 0A                 2649 	.db 0x0A
   0E3A 00                 2650 	.db 0x00
                    0A4B   2651 Fusb$_str_43$0$0 == .
   0E3B                    2652 __str_43:
   0E3B 45 5A 20 55 53 42  2653 	.ascii "EZ USB Status..."
        20 53 74 61 74 75
        73 2E 2E 2E
   0E4B 0A                 2654 	.db 0x0A
   0E4C 00                 2655 	.db 0x00
                    0A5D   2656 Fusb$_str_44$0$0 == .
   0E4D                    2657 __str_44:
   0E4D 50 6F 72 74 20 41  2658 	.ascii "Port A: "
        3A 20
   0E55 00                 2659 	.db 0x00
                    0A66   2660 Fusb$_str_45$0$0 == .
   0E56                    2661 __str_45:
   0E56 31                 2662 	.ascii "1"
   0E57 00                 2663 	.db 0x00
                    0A68   2664 Fusb$_str_46$0$0 == .
   0E58                    2665 __str_46:
   0E58 30                 2666 	.ascii "0"
   0E59 00                 2667 	.db 0x00
                    0A6A   2668 Fusb$_str_47$0$0 == .
   0E5A                    2669 __str_47:
   0E5A 0A                 2670 	.db 0x0A
   0E5B 00                 2671 	.db 0x00
                    0A6C   2672 Fusb$_str_48$0$0 == .
   0E5C                    2673 __str_48:
   0E5C 50 6F 72 74 20 42  2674 	.ascii "Port B: "
        3A 20
   0E64 00                 2675 	.db 0x00
                    0A75   2676 Fusb$_str_49$0$0 == .
   0E65                    2677 __str_49:
   0E65 31                 2678 	.ascii "1"
   0E66 00                 2679 	.db 0x00
                    0A77   2680 Fusb$_str_50$0$0 == .
   0E67                    2681 __str_50:
   0E67 30                 2682 	.ascii "0"
   0E68 00                 2683 	.db 0x00
                    0A79   2684 Fusb$_str_51$0$0 == .
   0E69                    2685 __str_51:
   0E69 0A                 2686 	.db 0x0A
   0E6A 00                 2687 	.db 0x00
                    0A7B   2688 Fusb$_str_52$0$0 == .
   0E6B                    2689 __str_52:
   0E6B 50 6F 72 74 20 43  2690 	.ascii "Port C: "
        3A 20
   0E73 00                 2691 	.db 0x00
                    0A84   2692 Fusb$_str_53$0$0 == .
   0E74                    2693 __str_53:
   0E74 31                 2694 	.ascii "1"
   0E75 00                 2695 	.db 0x00
                    0A86   2696 Fusb$_str_54$0$0 == .
   0E76                    2697 __str_54:
   0E76 30                 2698 	.ascii "0"
   0E77 00                 2699 	.db 0x00
                    0A88   2700 Fusb$_str_55$0$0 == .
   0E78                    2701 __str_55:
   0E78 0A                 2702 	.db 0x0A
   0E79 00                 2703 	.db 0x00
                    0A8A   2704 Fusb$_str_56$0$0 == .
   0E7A                    2705 __str_56:
   0E7A 50 6F 72 74 20 44  2706 	.ascii "Port D: "
        3A 20
   0E82 00                 2707 	.db 0x00
                    0A93   2708 Fusb$_str_57$0$0 == .
   0E83                    2709 __str_57:
   0E83 31                 2710 	.ascii "1"
   0E84 00                 2711 	.db 0x00
                    0A95   2712 Fusb$_str_58$0$0 == .
   0E85                    2713 __str_58:
   0E85 30                 2714 	.ascii "0"
   0E86 00                 2715 	.db 0x00
                    0A97   2716 Fusb$_str_59$0$0 == .
   0E87                    2717 __str_59:
   0E87 0A                 2718 	.db 0x0A
   0E88 00                 2719 	.db 0x00
                    0A99   2720 Fusb$_str_60$0$0 == .
   0E89                    2721 __str_60:
   0E89 0A                 2722 	.db 0x0A
   0E8A 00                 2723 	.db 0x00
                    0A9B   2724 Fusb$_str_61$0$0 == .
   0E8B                    2725 __str_61:
   0E8B 63 6F 6D 6D 61 6E  2726 	.ascii "commands: id status capture speed pass idle"
        64 73 3A 20 69 64
        20 73 74 61 74 75
        73 20 63 61 70 74
        75 72 65 20 73 70
        65 65 64 20 70 61
        73 73 20 69 64 6C
        65
   0EB6 0A                 2727 	.db 0x0A
   0EB7 00                 2728 	.db 0x00
