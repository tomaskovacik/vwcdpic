// EZ Console Firmware
// Copyright (c) 2001, Ed Schlunder <zilym@yahoo.com>

#include <string.h>
#include "ezusbfx.h"
#include "usb.h"
#include "serial.h"

void idle(void);
void sendByte(unsigned short a);

idata unsigned short volatile state, disc, track, mix, scan;
unsigned short volatile timeCount;
unsigned int volatile timeSave;

void main(void) {
  PSW = 0;
  DPS = 0;                // select first data pointer (dptr)
  CKCON = 0;              // no external waitstates
  IE = 0;                 // disable all interrupts
  EIE = 0;

  I2CMODE = I2400KHZ;     // set high speed I2C bus
  PORTSETUP = 1;          // enable using SFRs for I/O port control

  OEA = 0x1F;             // port a pins outputs (blinking LEDs)
  OEB = 0;                // inputs
  OEC = 0;
  OED = 0;
  OEE = 0xFF;             // drive port E pins, save power on 80 pin chip

  IOA = 0;

  initUSB();
  initSerial();

  // need 2200K timer pules for 550ms interval = 22000 * 100
  // 0xFFFF - 22000 = 0xAA0F
  TMOD = TIMER0_16 | TIMER1_STOP; // t0 = 16 bit timer t1 = stop
  TCON = 0;
  TL0 = 0x0F;             // Hz clock (assuming 48MHz system clock)
  TH0 = 0xAA;
  TR0 = 1;                // enable timer 0

  // enable interrupts
  ET0 = 1;  // enable timer 0 interrupt
  EA = 1;   // global interrupt enable

  state = STATE_IDLE;
  disc = 1;
  track = 1;
  mix = 0;
  scan = 0;
  idle();
}

#define DATAMASK 0x0F

void idle(void) {
  //  xdata unsigned short buf[2048];
  unsigned short j;
  unsigned int i;

  for(;;) {
    switch(state) {
    case STATE_IDLE:
      if(rxbuf[5] == 0xAB && rxbuf[6] == 0xAD) {
	mix ^= 0xFF;
	mixMP3();
	clearRX();
      }
      if(rxbuf[5] == 0xAD && rxbuf[6] == 0xD5) {
	scan ^= 0xFF;
	playMP3();
	clearRX();
      }
      if(rxbuf[5] == 0xBB && rxbuf[6] == 0xD5) {
	track--;
	previousMP3();
	clearRX();
      }
      if(rxbuf[5] == 0xBB && rxbuf[6] == 0xAB) {
	track++;
	nextMP3();
	clearRX();
      }

      break;
    case STATE_SIMPLE:
      msecWait(100);
      sendByte(0);
      break;
    case STATE_CAP:
      captureCD();
      prints("capture complete!\n");
      printDone();
      // wait here to try and send the captured data to the host
      AUTOPTRL = 00;
      AUTOPTRH = 0x20;
      j = 0;
      for(i = 0; i < 2048; i++) {
	// wait for endpoint to become available
	while((IN4CS & EPBUSY) && state == STATE_CAP);
	if(state != STATE_CAP)
	  break;

	IN4BUF[j++] = AUTODATA;
	if(j >= 64) {
	  IN4BC = 64;  // buffer filled, ship it!
	  j = 0;
	}
      }
      if(state == STATE_CAP)
	state = STATE_IDLE;
      break;
    case STATE_CDPASS:
      ET0 = 0; // disable our CD emulator timer
      while(state == STATE_CDPASS) {
	_asm
	  mov c,_IOA_6 ;; STX from changer
          mov _IOA_1,c ;; STX to head unit
	  mov c,_IOA_5 ;; SRX from head unit
          mov _IOA_4,c ;; SRX to changer
          mov c,_IOA_7 ;; SCLK from changer
          mov _IOA_0,c ;; SCLK to head unit
        _endasm;
      }
      IOA_1 = 0;
      IOA_0 = 0;
      IOA_4 = 0;
      ET0 = 1; // re-enable CD emulator
      break;
    case STATE_HEAD:
      captureHead();
      state = STATE_IDLE;
      break;
    }
  }
}

void sendByte2(unsigned short a) {
  unsigned short i = 8;
  while(i--) {
    IOA_0 = 1;            // SCLK HIGH
    IOA_1 = ((a & 0x80) ? 1:0);
    IOA_0 = 0;            // SCLK HIGH
  }
}


void sendByte(unsigned short a) {
  _asm
    mov  a, dpl
    mov  r2, #8
  00000$:
    setb _IOA_0           ;; 2 cycles set head unit SCLK HIGH
  00002$:
    rlc  a                ;; 1 cycle
    mov  _IOA_1,c         ;; 2 cycles
    clr  _IOA_0           ;; 2 cycles
    djnz r2,00000$        ;; 3 cycles

    
    ;; forced delay inbetween bytes. this value was found by trial and error.
    mov  r2,#180
  00001$:
    nop                   ;; 1 cycle
    nop
    djnz r2,00001$        ;; 3 cycles
    ret
  _endasm;
  // execution never reaches here due to "ret" above
  a = 0; // get SDCC to stop bitching...
}

void timer0(void) interrupt 1 {
  timeCount++;
  if(timeCount >= 100) {
    // We send the Head Unit a data packet every ~550ms as seen on the original
    // VW OEM CD Changer with my standard oscilloscope.
    timeCount = 0;

    sendByte(0x34);
    sendByte(0x80 | (0x0F - disc));
    sendByte(0xFF - track);
    sendByte(0xFF);
    sendByte(0xFF);
    sendByte((scan ? 0x20:0xF0) | (mix ? 0x0B:0x0F));
    sendByte(0xFF);
    sendByte(0x3C);
  }

  // reload timer count
  TR0 = 0;
  TL0 = 0x0F;            // 0.55ms clock (assuming 48MHz system clock)
  TH0 = 0xAA;
  TR0 = 1;
}

short _sdcc_external_startup() { return 0; }
