                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : FreeWare ANSI-C Compiler
                              3 ; Version 2.2.2 Tue Apr 17 02:00:26 2001
                              4 
                              5 ;--------------------------------------------------------
                              6 	.module vwhack
                              7 	
                              8 ;--------------------------------------------------------
                              9 ; Public variables in this module
                             10 ;--------------------------------------------------------
                             11 	.globl __sdcc_external_startup
                             12 	.globl _timer0
                             13 	.globl _sendByte2
                             14 	.globl _main
                             15 	.globl _IN4CS
                             16 	.globl _IN4BUF
                             17 	.globl _AUTODATA
                             18 	.globl _scan
                             19 	.globl _mix
                             20 	.globl _track
                             21 	.globl _disc
                             22 	.globl _state
                             23 	.globl _timeCount
                             24 	.globl _idle
                             25 	.globl _sendByte
                             26 ;--------------------------------------------------------
                             27 ; special function registers
                             28 ;--------------------------------------------------------
                    0081     29 G$SP$0$0 == 0x0081
                    0081     30 _SP	=	0x0081
                    0082     31 G$DPL$0$0 == 0x0082
                    0082     32 _DPL	=	0x0082
                    0083     33 G$DPH$0$0 == 0x0083
                    0083     34 _DPH	=	0x0083
                    0082     35 G$DPL0$0$0 == 0x0082
                    0082     36 _DPL0	=	0x0082
                    0083     37 G$DPH0$0$0 == 0x0083
                    0083     38 _DPH0	=	0x0083
                    0084     39 G$DPL1$0$0 == 0x0084
                    0084     40 _DPL1	=	0x0084
                    0085     41 G$DPH1$0$0 == 0x0085
                    0085     42 _DPH1	=	0x0085
                    0086     43 G$DPS$0$0 == 0x0086
                    0086     44 _DPS	=	0x0086
                    008E     45 G$CKCON$0$0 == 0x008e
                    008E     46 _CKCON	=	0x008e
                    00A2     47 G$INT4CLR$0$0 == 0x00a2
                    00A2     48 _INT4CLR	=	0x00a2
                    00F8     49 G$EIP$0$0 == 0x00f8
                    00F8     50 _EIP	=	0x00f8
                    0087     51 G$PCON$0$0 == 0x0087
                    0087     52 _PCON	=	0x0087
                    0088     53 G$TCON$0$0 == 0x0088
                    0088     54 _TCON	=	0x0088
                    0080     55 G$IOA$0$0 == 0x0080
                    0080     56 _IOA	=	0x0080
                    0090     57 G$IOB$0$0 == 0x0090
                    0090     58 _IOB	=	0x0090
                    00A0     59 G$IOC$0$0 == 0x00a0
                    00A0     60 _IOC	=	0x00a0
                    00B0     61 G$IOD$0$0 == 0x00b0
                    00B0     62 _IOD	=	0x00b0
                    00B1     63 G$IOE$0$0 == 0x00b1
                    00B1     64 _IOE	=	0x00b1
                    0089     65 G$TMOD$0$0 == 0x0089
                    0089     66 _TMOD	=	0x0089
                    008A     67 G$TL0$0$0 == 0x008a
                    008A     68 _TL0	=	0x008a
                    008B     69 G$TL1$0$0 == 0x008b
                    008B     70 _TL1	=	0x008b
                    008C     71 G$TH0$0$0 == 0x008c
                    008C     72 _TH0	=	0x008c
                    008D     73 G$TH1$0$0 == 0x008d
                    008D     74 _TH1	=	0x008d
                    008F     75 G$SPC_FNC$0$0 == 0x008f
                    008F     76 _SPC_FNC	=	0x008f
                    0091     77 G$EXIF$0$0 == 0x0091
                    0091     78 _EXIF	=	0x0091
                    0092     79 G$MPAGE$0$0 == 0x0092
                    0092     80 _MPAGE	=	0x0092
                    0098     81 G$SCON0$0$0 == 0x0098
                    0098     82 _SCON0	=	0x0098
                    0099     83 G$SBUF0$0$0 == 0x0099
                    0099     84 _SBUF0	=	0x0099
                    00A8     85 G$IE$0$0 == 0x00a8
                    00A8     86 _IE	=	0x00a8
                    00B8     87 G$IP$0$0 == 0x00b8
                    00B8     88 _IP	=	0x00b8
                    00C0     89 G$SCON1$0$0 == 0x00c0
                    00C0     90 _SCON1	=	0x00c0
                    00C1     91 G$SBUF1$0$0 == 0x00c1
                    00C1     92 _SBUF1	=	0x00c1
                    00C8     93 G$T2CON$0$0 == 0x00c8
                    00C8     94 _T2CON	=	0x00c8
                    00CA     95 G$RCAP2L$0$0 == 0x00ca
                    00CA     96 _RCAP2L	=	0x00ca
                    00CB     97 G$RCAP2H$0$0 == 0x00cb
                    00CB     98 _RCAP2H	=	0x00cb
                    00CC     99 G$TL2$0$0 == 0x00cc
                    00CC    100 _TL2	=	0x00cc
                    00CD    101 G$TH2$0$0 == 0x00cd
                    00CD    102 _TH2	=	0x00cd
                    00D0    103 G$PSW$0$0 == 0x00d0
                    00D0    104 _PSW	=	0x00d0
                    00D8    105 G$EICON$0$0 == 0x00d8
                    00D8    106 _EICON	=	0x00d8
                    00E0    107 G$ACC$0$0 == 0x00e0
                    00E0    108 _ACC	=	0x00e0
                    00E8    109 G$EIE$0$0 == 0x00e8
                    00E8    110 _EIE	=	0x00e8
                    00F0    111 G$B$0$0 == 0x00f0
                    00F0    112 _B	=	0x00f0
                            113 ;--------------------------------------------------------
                            114 ; special function bits 
                            115 ;--------------------------------------------------------
                    00FC    116 G$PX6$0$0 == 0x00fc
                    00FC    117 _PX6	=	0x00fc
                    00FB    118 G$PX5$0$0 == 0x00fb
                    00FB    119 _PX5	=	0x00fb
                    00FA    120 G$PX4$0$0 == 0x00fa
                    00FA    121 _PX4	=	0x00fa
                    00F9    122 G$PI2C$0$0 == 0x00f9
                    00F9    123 _PI2C	=	0x00f9
                    00F8    124 G$PUSB$0$0 == 0x00f8
                    00F8    125 _PUSB	=	0x00f8
                    008F    126 G$TF1$0$0 == 0x008f
                    008F    127 _TF1	=	0x008f
                    008E    128 G$TR1$0$0 == 0x008e
                    008E    129 _TR1	=	0x008e
                    008D    130 G$TF0$0$0 == 0x008d
                    008D    131 _TF0	=	0x008d
                    008C    132 G$TR0$0$0 == 0x008c
                    008C    133 _TR0	=	0x008c
                    008B    134 G$IE1$0$0 == 0x008b
                    008B    135 _IE1	=	0x008b
                    008A    136 G$IT1$0$0 == 0x008a
                    008A    137 _IT1	=	0x008a
                    0089    138 G$IE0$0$0 == 0x0089
                    0089    139 _IE0	=	0x0089
                    0088    140 G$IT0$0$0 == 0x0088
                    0088    141 _IT0	=	0x0088
                    0080    142 G$IOA_0$0$0 == 0x0080
                    0080    143 _IOA_0	=	0x0080
                    0081    144 G$IOA_1$0$0 == 0x0081
                    0081    145 _IOA_1	=	0x0081
                    0082    146 G$IOA_2$0$0 == 0x0082
                    0082    147 _IOA_2	=	0x0082
                    0083    148 G$IOA_3$0$0 == 0x0083
                    0083    149 _IOA_3	=	0x0083
                    0084    150 G$IOA_4$0$0 == 0x0084
                    0084    151 _IOA_4	=	0x0084
                    0085    152 G$IOA_5$0$0 == 0x0085
                    0085    153 _IOA_5	=	0x0085
                    0086    154 G$IOA_6$0$0 == 0x0086
                    0086    155 _IOA_6	=	0x0086
                    0087    156 G$IOA_7$0$0 == 0x0087
                    0087    157 _IOA_7	=	0x0087
                    0090    158 G$IOB_0$0$0 == 0x0090
                    0090    159 _IOB_0	=	0x0090
                    0091    160 G$IOB_1$0$0 == 0x0091
                    0091    161 _IOB_1	=	0x0091
                    0092    162 G$IOB_2$0$0 == 0x0092
                    0092    163 _IOB_2	=	0x0092
                    0093    164 G$IOB_3$0$0 == 0x0093
                    0093    165 _IOB_3	=	0x0093
                    0094    166 G$IOB_4$0$0 == 0x0094
                    0094    167 _IOB_4	=	0x0094
                    0095    168 G$IOB_5$0$0 == 0x0095
                    0095    169 _IOB_5	=	0x0095
                    0096    170 G$IOB_6$0$0 == 0x0096
                    0096    171 _IOB_6	=	0x0096
                    0097    172 G$IOB_7$0$0 == 0x0097
                    0097    173 _IOB_7	=	0x0097
                    00A0    174 G$IOC_0$0$0 == 0x00a0
                    00A0    175 _IOC_0	=	0x00a0
                    00A1    176 G$IOC_1$0$0 == 0x00a1
                    00A1    177 _IOC_1	=	0x00a1
                    00A2    178 G$IOC_2$0$0 == 0x00a2
                    00A2    179 _IOC_2	=	0x00a2
                    00A3    180 G$IOC_3$0$0 == 0x00a3
                    00A3    181 _IOC_3	=	0x00a3
                    00A4    182 G$IOC_4$0$0 == 0x00a4
                    00A4    183 _IOC_4	=	0x00a4
                    00A5    184 G$IOC_5$0$0 == 0x00a5
                    00A5    185 _IOC_5	=	0x00a5
                    00A6    186 G$IOC_6$0$0 == 0x00a6
                    00A6    187 _IOC_6	=	0x00a6
                    00A7    188 G$IOC_7$0$0 == 0x00a7
                    00A7    189 _IOC_7	=	0x00a7
                    00B0    190 G$IOD_0$0$0 == 0x00b0
                    00B0    191 _IOD_0	=	0x00b0
                    00B1    192 G$IOD_1$0$0 == 0x00b1
                    00B1    193 _IOD_1	=	0x00b1
                    00B2    194 G$IOD_2$0$0 == 0x00b2
                    00B2    195 _IOD_2	=	0x00b2
                    00B3    196 G$IOD_3$0$0 == 0x00b3
                    00B3    197 _IOD_3	=	0x00b3
                    00B4    198 G$IOD_4$0$0 == 0x00b4
                    00B4    199 _IOD_4	=	0x00b4
                    00B5    200 G$IOD_5$0$0 == 0x00b5
                    00B5    201 _IOD_5	=	0x00b5
                    00B6    202 G$IOD_6$0$0 == 0x00b6
                    00B6    203 _IOD_6	=	0x00b6
                    00B7    204 G$IOD_7$0$0 == 0x00b7
                    00B7    205 _IOD_7	=	0x00b7
                    009F    206 G$SM0_0$0$0 == 0x009f
                    009F    207 _SM0_0	=	0x009f
                    009E    208 G$SM1_0$0$0 == 0x009e
                    009E    209 _SM1_0	=	0x009e
                    009D    210 G$SM2_0$0$0 == 0x009d
                    009D    211 _SM2_0	=	0x009d
                    009C    212 G$REN_0$0$0 == 0x009c
                    009C    213 _REN_0	=	0x009c
                    009B    214 G$TB8_0$0$0 == 0x009b
                    009B    215 _TB8_0	=	0x009b
                    009A    216 G$RB8_0$0$0 == 0x009a
                    009A    217 _RB8_0	=	0x009a
                    0099    218 G$TI_0$0$0 == 0x0099
                    0099    219 _TI_0	=	0x0099
                    0098    220 G$RI_0$0$0 == 0x0098
                    0098    221 _RI_0	=	0x0098
                    00AF    222 G$EA$0$0 == 0x00af
                    00AF    223 _EA	=	0x00af
                    00AE    224 G$ES1$0$0 == 0x00ae
                    00AE    225 _ES1	=	0x00ae
                    00AD    226 G$ET2$0$0 == 0x00ad
                    00AD    227 _ET2	=	0x00ad
                    00AC    228 G$ES0$0$0 == 0x00ac
                    00AC    229 _ES0	=	0x00ac
                    00AB    230 G$ET1$0$0 == 0x00ab
                    00AB    231 _ET1	=	0x00ab
                    00AA    232 G$EX1$0$0 == 0x00aa
                    00AA    233 _EX1	=	0x00aa
                    00A9    234 G$ET0$0$0 == 0x00a9
                    00A9    235 _ET0	=	0x00a9
                    00A8    236 G$EX0$0$0 == 0x00a8
                    00A8    237 _EX0	=	0x00a8
                    00BE    238 G$PS1$0$0 == 0x00be
                    00BE    239 _PS1	=	0x00be
                    00BD    240 G$PT2$0$0 == 0x00bd
                    00BD    241 _PT2	=	0x00bd
                    00BC    242 G$PS0$0$0 == 0x00bc
                    00BC    243 _PS0	=	0x00bc
                    00BB    244 G$PT1$0$0 == 0x00bb
                    00BB    245 _PT1	=	0x00bb
                    00BA    246 G$PX1$0$0 == 0x00ba
                    00BA    247 _PX1	=	0x00ba
                    00B9    248 G$PT0$0$0 == 0x00b9
                    00B9    249 _PT0	=	0x00b9
                    00B8    250 G$PX0$0$0 == 0x00b8
                    00B8    251 _PX0	=	0x00b8
                    00C7    252 G$SM0_1$0$0 == 0x00c7
                    00C7    253 _SM0_1	=	0x00c7
                    00C6    254 G$SM1_1$0$0 == 0x00c6
                    00C6    255 _SM1_1	=	0x00c6
                    00C5    256 G$SM2_1$0$0 == 0x00c5
                    00C5    257 _SM2_1	=	0x00c5
                    00C4    258 G$REN_1$0$0 == 0x00c4
                    00C4    259 _REN_1	=	0x00c4
                    00C3    260 G$TB8_1$0$0 == 0x00c3
                    00C3    261 _TB8_1	=	0x00c3
                    00C2    262 G$RB8_1$0$0 == 0x00c2
                    00C2    263 _RB8_1	=	0x00c2
                    00C1    264 G$TI_1$0$0 == 0x00c1
                    00C1    265 _TI_1	=	0x00c1
                    00C0    266 G$RI_1$0$0 == 0x00c0
                    00C0    267 _RI_1	=	0x00c0
                    00CF    268 G$TF2$0$0 == 0x00cf
                    00CF    269 _TF2	=	0x00cf
                    00CE    270 G$EXF2$0$0 == 0x00ce
                    00CE    271 _EXF2	=	0x00ce
                    00CD    272 G$RCLK$0$0 == 0x00cd
                    00CD    273 _RCLK	=	0x00cd
                    00CC    274 G$TCLK$0$0 == 0x00cc
                    00CC    275 _TCLK	=	0x00cc
                    00CB    276 G$EXEN2$0$0 == 0x00cb
                    00CB    277 _EXEN2	=	0x00cb
                    00CA    278 G$TR2$0$0 == 0x00ca
                    00CA    279 _TR2	=	0x00ca
                    00C9    280 G$CT2$0$0 == 0x00c9
                    00C9    281 _CT2	=	0x00c9
                    00C8    282 G$CPRL2$0$0 == 0x00c8
                    00C8    283 _CPRL2	=	0x00c8
                    00D7    284 G$CY$0$0 == 0x00d7
                    00D7    285 _CY	=	0x00d7
                    00D6    286 G$AC$0$0 == 0x00d6
                    00D6    287 _AC	=	0x00d6
                    00D5    288 G$F0$0$0 == 0x00d5
                    00D5    289 _F0	=	0x00d5
                    00D4    290 G$RS1$0$0 == 0x00d4
                    00D4    291 _RS1	=	0x00d4
                    00D3    292 G$RS0$0$0 == 0x00d3
                    00D3    293 _RS0	=	0x00d3
                    00D2    294 G$OV$0$0 == 0x00d2
                    00D2    295 _OV	=	0x00d2
                    00D0    296 G$P$0$0 == 0x00d0
                    00D0    297 _P	=	0x00d0
                    00DF    298 G$SMOD1$0$0 == 0x00df
                    00DF    299 _SMOD1	=	0x00df
                    00DD    300 G$ERESI$0$0 == 0x00dd
                    00DD    301 _ERESI	=	0x00dd
                    00DC    302 G$RESI$0$0 == 0x00dc
                    00DC    303 _RESI	=	0x00dc
                    00DB    304 G$INT6$0$0 == 0x00db
                    00DB    305 _INT6	=	0x00db
                    00EC    306 G$EWDI$0$0 == 0x00ec
                    00EC    307 _EWDI	=	0x00ec
                    00EB    308 G$EX5$0$0 == 0x00eb
                    00EB    309 _EX5	=	0x00eb
                    00EA    310 G$EX4$0$0 == 0x00ea
                    00EA    311 _EX4	=	0x00ea
                    00E9    312 G$EI2C$0$0 == 0x00e9
                    00E9    313 _EI2C	=	0x00e9
                    00E8    314 G$EUSB$0$0 == 0x00e8
                    00E8    315 _EUSB	=	0x00e8
                            316 ;--------------------------------------------------------
                            317 ; internal ram data
                            318 ;--------------------------------------------------------
                            319 	.area DSEG    (DATA)
                    0000    320 G$timeCount$0$0==.
   0030                     321 _timeCount::
   0030                     322 	.ds 1
                    0001    323 G$timeSave$0$0==.
   0031                     324 _timeSave::
   0031                     325 	.ds 2
                            326 ;--------------------------------------------------------
                            327 ; overlayable items in internal ram 
                            328 ;--------------------------------------------------------
                            329 	.area OSEG    (OVR,DATA)
                            330 ;--------------------------------------------------------
                            331 ; Stack segment in internal ram 
                            332 ;--------------------------------------------------------
                            333 	.area	SSEG	(DATA)
   0058                     334 __start__stack:
   0058                     335 	.ds	1
                            336 
                            337 ;--------------------------------------------------------
                            338 ; indirectly addressable internal ram data
                            339 ;--------------------------------------------------------
                            340 	.area ISEG    (DATA)
                    0000    341 G$state$0$0==.
   0080                     342 _state::
   0080                     343 	.ds 1
                    0001    344 G$disc$0$0==.
   0081                     345 _disc::
   0081                     346 	.ds 1
                    0002    347 G$track$0$0==.
   0082                     348 _track::
   0082                     349 	.ds 1
                    0003    350 G$mix$0$0==.
   0083                     351 _mix::
   0083                     352 	.ds 1
                    0004    353 G$scan$0$0==.
   0084                     354 _scan::
   0084                     355 	.ds 1
                            356 ;--------------------------------------------------------
                            357 ; bit data
                            358 ;--------------------------------------------------------
                            359 	.area BSEG    (BIT)
                            360 ;--------------------------------------------------------
                            361 ; external ram data
                            362 ;--------------------------------------------------------
                            363 	.area XSEG    (XDATA)
                    7800    364 G$AINDATA$0$0 == 0x7800
                    7800    365 _AINDATA	=	0x7800
                    7801    366 G$AINBC$0$0 == 0x7801
                    7801    367 _AINBC	=	0x7801
                    7802    368 G$AINPF$0$0 == 0x7802
                    7802    369 _AINPF	=	0x7802
                    7803    370 G$AINPFPIN$0$0 == 0x7803
                    7803    371 _AINPFPIN	=	0x7803
                    7805    372 G$BINDATA$0$0 == 0x7805
                    7805    373 _BINDATA	=	0x7805
                    7806    374 G$BINBC$0$0 == 0x7806
                    7806    375 _BINBC	=	0x7806
                    7807    376 G$BINPF$0$0 == 0x7807
                    7807    377 _BINPF	=	0x7807
                    7808    378 G$BINPFPIN$0$0 == 0x7808
                    7808    379 _BINPFPIN	=	0x7808
                    780A    380 G$ABINTF$0$0 == 0x780a
                    780A    381 _ABINTF	=	0x780a
                    780B    382 G$ABINIE$0$0 == 0x780b
                    780B    383 _ABINIE	=	0x780b
                    780C    384 G$ABINIRQ$0$0 == 0x780c
                    780C    385 _ABINIRQ	=	0x780c
                    780E    386 G$AOUTDATA$0$0 == 0x780e
                    780E    387 _AOUTDATA	=	0x780e
                    780F    388 G$AOUTBC$0$0 == 0x780f
                    780F    389 _AOUTBC	=	0x780f
                    7810    390 G$AOUTPF$0$0 == 0x7810
                    7810    391 _AOUTPF	=	0x7810
                    7811    392 G$AOUTPFPIN$0$0 == 0x7811
                    7811    393 _AOUTPFPIN	=	0x7811
                    7813    394 G$BOUTDATA$0$0 == 0x7813
                    7813    395 _BOUTDATA	=	0x7813
                    7814    396 G$BOUTBC$0$0 == 0x7814
                    7814    397 _BOUTBC	=	0x7814
                    7815    398 G$BOUTPF$0$0 == 0x7815
                    7815    399 _BOUTPF	=	0x7815
                    7816    400 G$BOUTPFPIN$0$0 == 0x7816
                    7816    401 _BOUTPFPIN	=	0x7816
                    7818    402 G$ABOUTTF$0$0 == 0x7818
                    7818    403 _ABOUTTF	=	0x7818
                    7819    404 G$ABOUTIE$0$0 == 0x7819
                    7819    405 _ABOUTIE	=	0x7819
                    781A    406 G$ABOUTIRQ$0$0 == 0x781a
                    781A    407 _ABOUTIRQ	=	0x781a
                    781C    408 G$ABSETUP$0$0 == 0x781c
                    781C    409 _ABSETUP	=	0x781c
                    781D    410 G$ABPOLAR$0$0 == 0x781d
                    781D    411 _ABPOLAR	=	0x781d
                    781E    412 G$ABFLUSH$0$0 == 0x781e
                    781E    413 _ABFLUSH	=	0x781e
                    7824    414 G$WFSELECT$0$0 == 0x7824
                    7824    415 _WFSELECT	=	0x7824
                    7825    416 G$IDLE_CS$0$0 == 0x7825
                    7825    417 _IDLE_CS	=	0x7825
                    7826    418 G$IDLE_CTLOUT$0$0 == 0x7826
                    7826    419 _IDLE_CTLOUT	=	0x7826
                    7827    420 G$CTLOUTCFG$0$0 == 0x7827
                    7827    421 _CTLOUTCFG	=	0x7827
                    782A    422 G$GPIFADRL$0$0 == 0x782a
                    782A    423 _GPIFADRL	=	0x782a
                    7900    424 G$WFDESC$0$0 == 0x7900
                    7900    425 _WFDESC	=	0x7900
                    7900    426 G$WFDESC0$0$0 == 0x7900
                    7900    427 _WFDESC0	=	0x7900
                    7920    428 G$WFDESC1$0$0 == 0x7920
                    7920    429 _WFDESC1	=	0x7920
                    7940    430 G$WFDESC2$0$0 == 0x7940
                    7940    431 _WFDESC2	=	0x7940
                    7960    432 G$WFDESC3$0$0 == 0x7960
                    7960    433 _WFDESC3	=	0x7960
                    782C    434 G$AINTC$0$0 == 0x782c
                    782C    435 _AINTC	=	0x782c
                    782D    436 G$AOUTTC$0$0 == 0x782d
                    782D    437 _AOUTTC	=	0x782d
                    782E    438 G$ATRIG$0$0 == 0x782e
                    782E    439 _ATRIG	=	0x782e
                    7830    440 G$BINTC$0$0 == 0x7830
                    7830    441 _BINTC	=	0x7830
                    7831    442 G$BOUTTC$0$0 == 0x7831
                    7831    443 _BOUTTC	=	0x7831
                    7832    444 G$BTRIG$0$0 == 0x7832
                    7832    445 _BTRIG	=	0x7832
                    7834    446 G$SGLDATH$0$0 == 0x7834
                    7834    447 _SGLDATH	=	0x7834
                    7835    448 G$SGLDATLTRIG$0$0 == 0x7835
                    7835    449 _SGLDATLTRIG	=	0x7835
                    7836    450 G$SGLDATLNTRIG$0$0 == 0x7836
                    7836    451 _SGLDATLNTRIG	=	0x7836
                    7838    452 G$READY$0$0 == 0x7838
                    7838    453 _READY	=	0x7838
                    7839    454 G$ABORT$0$0 == 0x7839
                    7839    455 _ABORT	=	0x7839
                    783B    456 G$GENIE$0$0 == 0x783b
                    783B    457 _GENIE	=	0x783b
                    783C    458 G$GENIRQ$0$0 == 0x783c
                    783C    459 _GENIRQ	=	0x783c
                    784A    460 G$IFCONFIG$0$0 == 0x784a
                    784A    461 _IFCONFIG	=	0x784a
                    7FE3    462 G$AUTOPTRH$0$0 == 0x7fe3
                    7FE3    463 _AUTOPTRH	=	0x7fe3
                    7FE4    464 G$AUTOPTRL$0$0 == 0x7fe4
                    7FE4    465 _AUTOPTRL	=	0x7fe4
                    7FE5    466 G$AUTODATA$0$0 == 0x7fe5
                    7FE5    467 _AUTODATA	=	0x7fe5
                    7F96    468 G$OUTA$0$0 == 0x7f96
                    7F96    469 _OUTA	=	0x7f96
                    7F97    470 G$OUTB$0$0 == 0x7f97
                    7F97    471 _OUTB	=	0x7f97
                    7F98    472 G$OUTC$0$0 == 0x7f98
                    7F98    473 _OUTC	=	0x7f98
                    7841    474 G$OUTD$0$0 == 0x7841
                    7841    475 _OUTD	=	0x7841
                    7845    476 G$OUTE$0$0 == 0x7845
                    7845    477 _OUTE	=	0x7845
                    7F99    478 G$PINSA$0$0 == 0x7f99
                    7F99    479 _PINSA	=	0x7f99
                    7F9A    480 G$PINSB$0$0 == 0x7f9a
                    7F9A    481 _PINSB	=	0x7f9a
                    7F9B    482 G$PINSC$0$0 == 0x7f9b
                    7F9B    483 _PINSC	=	0x7f9b
                    7842    484 G$PINSD$0$0 == 0x7842
                    7842    485 _PINSD	=	0x7842
                    7846    486 G$PINSE$0$0 == 0x7846
                    7846    487 _PINSE	=	0x7846
                    7F9C    488 G$OEA$0$0 == 0x7f9c
                    7F9C    489 _OEA	=	0x7f9c
                    7F9D    490 G$OEB$0$0 == 0x7f9d
                    7F9D    491 _OEB	=	0x7f9d
                    7F9E    492 G$OEC$0$0 == 0x7f9e
                    7F9E    493 _OEC	=	0x7f9e
                    7843    494 G$OED$0$0 == 0x7843
                    7843    495 _OED	=	0x7843
                    7847    496 G$OEE$0$0 == 0x7847
                    7847    497 _OEE	=	0x7847
                    7F93    498 G$PORTACFG$0$0 == 0x7f93
                    7F93    499 _PORTACFG	=	0x7f93
                    7F94    500 G$PORTBCFG$0$0 == 0x7f94
                    7F94    501 _PORTBCFG	=	0x7f94
                    7F95    502 G$PORTCCFG$0$0 == 0x7f95
                    7F95    503 _PORTCCFG	=	0x7f95
                    784C    504 G$PORTCCF2$0$0 == 0x784c
                    784C    505 _PORTCCF2	=	0x784c
                    7849    506 G$PORTSETUP$0$0 == 0x7849
                    7849    507 _PORTSETUP	=	0x7849
                    785D    508 G$INT4IVEC$0$0 == 0x785d
                    785D    509 _INT4IVEC	=	0x785d
                    785E    510 G$INT4SETUP$0$0 == 0x785e
                    785E    511 _INT4SETUP	=	0x785e
                    784F    512 G$DMASRCH$0$0 == 0x784f
                    784F    513 _DMASRCH	=	0x784f
                    7850    514 G$DMASRCL$0$0 == 0x7850
                    7850    515 _DMASRCL	=	0x7850
                    7851    516 G$DMADESTH$0$0 == 0x7851
                    7851    517 _DMADESTH	=	0x7851
                    7852    518 G$DMADESTL$0$0 == 0x7852
                    7852    519 _DMADESTL	=	0x7852
                    7857    520 G$DMABURST$0$0 == 0x7857
                    7857    521 _DMABURST	=	0x7857
                    7854    522 G$DMALEN$0$0 == 0x7854
                    7854    523 _DMALEN	=	0x7854
                    7855    524 G$DMAGO$0$0 == 0x7855
                    7855    525 _DMAGO	=	0x7855
                    7FA6    526 G$I2DAT$0$0 == 0x7fa6
                    7FA6    527 _I2DAT	=	0x7fa6
                    7FA5    528 G$I2CS$0$0 == 0x7fa5
                    7FA5    529 _I2CS	=	0x7fa5
                    7FA7    530 G$I2CMODE$0$0 == 0x7fa7
                    7FA7    531 _I2CMODE	=	0x7fa7
                    7F92    532 G$CPUCS$0$0 == 0x7f92
                    7F92    533 _CPUCS	=	0x7f92
                    7FA0    534 G$ISOERR$0$0 == 0x7fa0
                    7FA0    535 _ISOERR	=	0x7fa0
                    7FA1    536 G$ISOCTL$0$0 == 0x7fa1
                    7FA1    537 _ISOCTL	=	0x7fa1
                    7FA2    538 G$ZBCOUNT$0$0 == 0x7fa2
                    7FA2    539 _ZBCOUNT	=	0x7fa2
                    7F00    540 G$IN0BUF$0$0 == 0x7f00
                    7F00    541 _IN0BUF	=	0x7f00
                    7EC0    542 G$OUT0BUF$0$0 == 0x7ec0
                    7EC0    543 _OUT0BUF	=	0x7ec0
                    7E80    544 G$IN1BUF$0$0 == 0x7e80
                    7E80    545 _IN1BUF	=	0x7e80
                    7E40    546 G$OUT1BUF$0$0 == 0x7e40
                    7E40    547 _OUT1BUF	=	0x7e40
                    7E00    548 G$IN2BUF$0$0 == 0x7e00
                    7E00    549 _IN2BUF	=	0x7e00
                    7DC0    550 G$OUT2BUF$0$0 == 0x7dc0
                    7DC0    551 _OUT2BUF	=	0x7dc0
                    7D80    552 G$IN3BUF$0$0 == 0x7d80
                    7D80    553 _IN3BUF	=	0x7d80
                    7D40    554 G$OUT3BUF$0$0 == 0x7d40
                    7D40    555 _OUT3BUF	=	0x7d40
                    7D00    556 G$IN4BUF$0$0 == 0x7d00
                    7D00    557 _IN4BUF	=	0x7d00
                    7CC0    558 G$OUT4BUF$0$0 == 0x7cc0
                    7CC0    559 _OUT4BUF	=	0x7cc0
                    7C80    560 G$IN5BUF$0$0 == 0x7c80
                    7C80    561 _IN5BUF	=	0x7c80
                    7C40    562 G$OUT5BUF$0$0 == 0x7c40
                    7C40    563 _OUT5BUF	=	0x7c40
                    7C00    564 G$IN6BUF$0$0 == 0x7c00
                    7C00    565 _IN6BUF	=	0x7c00
                    7BC0    566 G$OUT6BUF$0$0 == 0x7bc0
                    7BC0    567 _OUT6BUF	=	0x7bc0
                    7B80    568 G$IN7BUF$0$0 == 0x7b80
                    7B80    569 _IN7BUF	=	0x7b80
                    7B40    570 G$OUT7BUF$0$0 == 0x7b40
                    7B40    571 _OUT7BUF	=	0x7b40
                    7FE8    572 G$SETUPBUF$0$0 == 0x7fe8
                    7FE8    573 _SETUPBUF	=	0x7fe8
                    7FE8    574 G$SETUPDAT$0$0 == 0x7fe8
                    7FE8    575 _SETUPDAT	=	0x7fe8
                    7FB4    576 G$EP0CS$0$0 == 0x7fb4
                    7FB4    577 _EP0CS	=	0x7fb4
                    7FB5    578 G$IN0BC$0$0 == 0x7fb5
                    7FB5    579 _IN0BC	=	0x7fb5
                    7FB6    580 G$IN1CS$0$0 == 0x7fb6
                    7FB6    581 _IN1CS	=	0x7fb6
                    7FB7    582 G$IN1BC$0$0 == 0x7fb7
                    7FB7    583 _IN1BC	=	0x7fb7
                    7FB8    584 G$IN2CS$0$0 == 0x7fb8
                    7FB8    585 _IN2CS	=	0x7fb8
                    7FB9    586 G$IN2BC$0$0 == 0x7fb9
                    7FB9    587 _IN2BC	=	0x7fb9
                    7FBA    588 G$IN3CS$0$0 == 0x7fba
                    7FBA    589 _IN3CS	=	0x7fba
                    7FBB    590 G$IN3BC$0$0 == 0x7fbb
                    7FBB    591 _IN3BC	=	0x7fbb
                    7FBC    592 G$IN4CS$0$0 == 0x7fbc
                    7FBC    593 _IN4CS	=	0x7fbc
                    7FBD    594 G$IN4BC$0$0 == 0x7fbd
                    7FBD    595 _IN4BC	=	0x7fbd
                    7FBE    596 G$IN5CS$0$0 == 0x7fbe
                    7FBE    597 _IN5CS	=	0x7fbe
                    7FBF    598 G$IN5BC$0$0 == 0x7fbf
                    7FBF    599 _IN5BC	=	0x7fbf
                    7FC0    600 G$IN6CS$0$0 == 0x7fc0
                    7FC0    601 _IN6CS	=	0x7fc0
                    7FC1    602 G$IN6BC$0$0 == 0x7fc1
                    7FC1    603 _IN6BC	=	0x7fc1
                    7FC2    604 G$IN7CS$0$0 == 0x7fc2
                    7FC2    605 _IN7CS	=	0x7fc2
                    7FC3    606 G$IN7BC$0$0 == 0x7fc3
                    7FC3    607 _IN7BC	=	0x7fc3
                    7FC5    608 G$OUT0BC$0$0 == 0x7fc5
                    7FC5    609 _OUT0BC	=	0x7fc5
                    7FC6    610 G$OUT1CS$0$0 == 0x7fc6
                    7FC6    611 _OUT1CS	=	0x7fc6
                    7FC7    612 G$OUT1BC$0$0 == 0x7fc7
                    7FC7    613 _OUT1BC	=	0x7fc7
                    7FC8    614 G$OUT2CS$0$0 == 0x7fc8
                    7FC8    615 _OUT2CS	=	0x7fc8
                    7FC9    616 G$OUT2BC$0$0 == 0x7fc9
                    7FC9    617 _OUT2BC	=	0x7fc9
                    7FCA    618 G$OUT3CS$0$0 == 0x7fca
                    7FCA    619 _OUT3CS	=	0x7fca
                    7FCB    620 G$OUT3BC$0$0 == 0x7fcb
                    7FCB    621 _OUT3BC	=	0x7fcb
                    7FCC    622 G$OUT4CS$0$0 == 0x7fcc
                    7FCC    623 _OUT4CS	=	0x7fcc
                    7FCD    624 G$OUT4BC$0$0 == 0x7fcd
                    7FCD    625 _OUT4BC	=	0x7fcd
                    7FCE    626 G$OUT5CS$0$0 == 0x7fce
                    7FCE    627 _OUT5CS	=	0x7fce
                    7FCF    628 G$OUT5BC$0$0 == 0x7fcf
                    7FCF    629 _OUT5BC	=	0x7fcf
                    7FD0    630 G$OUT6CS$0$0 == 0x7fd0
                    7FD0    631 _OUT6CS	=	0x7fd0
                    7FD1    632 G$OUT6BC$0$0 == 0x7fd1
                    7FD1    633 _OUT6BC	=	0x7fd1
                    7FD2    634 G$OUT7CS$0$0 == 0x7fd2
                    7FD2    635 _OUT7CS	=	0x7fd2
                    7FD3    636 G$OUT7BC$0$0 == 0x7fd3
                    7FD3    637 _OUT7BC	=	0x7fd3
                    7FA8    638 G$IVEC$0$0 == 0x7fa8
                    7FA8    639 _IVEC	=	0x7fa8
                    7FA9    640 G$IN07IRQ$0$0 == 0x7fa9
                    7FA9    641 _IN07IRQ	=	0x7fa9
                    7FAA    642 G$OUT07IRQ$0$0 == 0x7faa
                    7FAA    643 _OUT07IRQ	=	0x7faa
                    7FAB    644 G$USBIRQ$0$0 == 0x7fab
                    7FAB    645 _USBIRQ	=	0x7fab
                    7FAC    646 G$IN07IEN$0$0 == 0x7fac
                    7FAC    647 _IN07IEN	=	0x7fac
                    7FAD    648 G$OUT07IEN$0$0 == 0x7fad
                    7FAD    649 _OUT07IEN	=	0x7fad
                    7FAE    650 G$USBIEN$0$0 == 0x7fae
                    7FAE    651 _USBIEN	=	0x7fae
                    7FAF    652 G$USBBAV$0$0 == 0x7faf
                    7FAF    653 _USBBAV	=	0x7faf
                    7FB2    654 G$BPADDRH$0$0 == 0x7fb2
                    7FB2    655 _BPADDRH	=	0x7fb2
                    7FB3    656 G$BPADDRL$0$0 == 0x7fb3
                    7FB3    657 _BPADDRL	=	0x7fb3
                    7FD4    658 G$SUDPTRH$0$0 == 0x7fd4
                    7FD4    659 _SUDPTRH	=	0x7fd4
                    7FD5    660 G$SUDPTRL$0$0 == 0x7fd5
                    7FD5    661 _SUDPTRL	=	0x7fd5
                    7FD6    662 G$USBCS$0$0 == 0x7fd6
                    7FD6    663 _USBCS	=	0x7fd6
                    7FD7    664 G$TOGCTL$0$0 == 0x7fd7
                    7FD7    665 _TOGCTL	=	0x7fd7
                    7FD8    666 G$USBFRAMEL$0$0 == 0x7fd8
                    7FD8    667 _USBFRAMEL	=	0x7fd8
                    7FD9    668 G$USBFRAMEH$0$0 == 0x7fd9
                    7FD9    669 _USBFRAMEH	=	0x7fd9
                    7FDB    670 G$FNADDR$0$0 == 0x7fdb
                    7FDB    671 _FNADDR	=	0x7fdb
                    7FDD    672 G$USBPAIR$0$0 == 0x7fdd
                    7FDD    673 _USBPAIR	=	0x7fdd
                    7FDE    674 G$IN07VAL$0$0 == 0x7fde
                    7FDE    675 _IN07VAL	=	0x7fde
                    7FDF    676 G$OUT07VAL$0$0 == 0x7fdf
                    7FDF    677 _OUT07VAL	=	0x7fdf
                    7F60    678 G$OUT8DATA$0$0 == 0x7f60
                    7F60    679 _OUT8DATA	=	0x7f60
                    7F61    680 G$OUT9DATA$0$0 == 0x7f61
                    7F61    681 _OUT9DATA	=	0x7f61
                    7F62    682 G$OUT10DATA$0$0 == 0x7f62
                    7F62    683 _OUT10DATA	=	0x7f62
                    7F63    684 G$OUT11DATA$0$0 == 0x7f63
                    7F63    685 _OUT11DATA	=	0x7f63
                    7F64    686 G$OUT12DATA$0$0 == 0x7f64
                    7F64    687 _OUT12DATA	=	0x7f64
                    7F65    688 G$OUT13DATA$0$0 == 0x7f65
                    7F65    689 _OUT13DATA	=	0x7f65
                    7F66    690 G$OUT14DATA$0$0 == 0x7f66
                    7F66    691 _OUT14DATA	=	0x7f66
                    7F67    692 G$OUT15DATA$0$0 == 0x7f67
                    7F67    693 _OUT15DATA	=	0x7f67
                    7F68    694 G$IN8DATA$0$0 == 0x7f68
                    7F68    695 _IN8DATA	=	0x7f68
                    7F69    696 G$IN9DATA$0$0 == 0x7f69
                    7F69    697 _IN9DATA	=	0x7f69
                    7F6A    698 G$IN10DATA$0$0 == 0x7f6a
                    7F6A    699 _IN10DATA	=	0x7f6a
                    7F6B    700 G$IN11DATA$0$0 == 0x7f6b
                    7F6B    701 _IN11DATA	=	0x7f6b
                    7F6C    702 G$IN12DATA$0$0 == 0x7f6c
                    7F6C    703 _IN12DATA	=	0x7f6c
                    7F6D    704 G$IN13DATA$0$0 == 0x7f6d
                    7F6D    705 _IN13DATA	=	0x7f6d
                    7F6E    706 G$IN14DATA$0$0 == 0x7f6e
                    7F6E    707 _IN14DATA	=	0x7f6e
                    7F6F    708 G$IN15DATA$0$0 == 0x7f6f
                    7F6F    709 _IN15DATA	=	0x7f6f
                    7F70    710 G$OUT8BCH$0$0 == 0x7f70
                    7F70    711 _OUT8BCH	=	0x7f70
                    7F71    712 G$OUT8BCL$0$0 == 0x7f71
                    7F71    713 _OUT8BCL	=	0x7f71
                    7F72    714 G$OUT9BCH$0$0 == 0x7f72
                    7F72    715 _OUT9BCH	=	0x7f72
                    7F73    716 G$OUT9BCL$0$0 == 0x7f73
                    7F73    717 _OUT9BCL	=	0x7f73
                    7F74    718 G$OUT10BCH$0$0 == 0x7f74
                    7F74    719 _OUT10BCH	=	0x7f74
                    7F75    720 G$OUT10BCL$0$0 == 0x7f75
                    7F75    721 _OUT10BCL	=	0x7f75
                    7F76    722 G$OUT11BCH$0$0 == 0x7f76
                    7F76    723 _OUT11BCH	=	0x7f76
                    7F77    724 G$OUT11BCL$0$0 == 0x7f77
                    7F77    725 _OUT11BCL	=	0x7f77
                    7F78    726 G$OUT12BCH$0$0 == 0x7f78
                    7F78    727 _OUT12BCH	=	0x7f78
                    7F79    728 G$OUT12BCL$0$0 == 0x7f79
                    7F79    729 _OUT12BCL	=	0x7f79
                    7F7A    730 G$OUT13BCH$0$0 == 0x7f7a
                    7F7A    731 _OUT13BCH	=	0x7f7a
                    7F7B    732 G$OUT13BCL$0$0 == 0x7f7b
                    7F7B    733 _OUT13BCL	=	0x7f7b
                    7F7C    734 G$OUT14BCH$0$0 == 0x7f7c
                    7F7C    735 _OUT14BCH	=	0x7f7c
                    7F7D    736 G$OUT14BCL$0$0 == 0x7f7d
                    7F7D    737 _OUT14BCL	=	0x7f7d
                    7F7E    738 G$OUT15BCH$0$0 == 0x7f7e
                    7F7E    739 _OUT15BCH	=	0x7f7e
                    7F7F    740 G$OUT15BCL$0$0 == 0x7f7f
                    7F7F    741 _OUT15BCL	=	0x7f7f
                    7FF0    742 G$OUT8ADDR$0$0 == 0x7ff0
                    7FF0    743 _OUT8ADDR	=	0x7ff0
                    7FF1    744 G$OUT9ADDR$0$0 == 0x7ff1
                    7FF1    745 _OUT9ADDR	=	0x7ff1
                    7FF2    746 G$OUT10ADDR$0$0 == 0x7ff2
                    7FF2    747 _OUT10ADDR	=	0x7ff2
                    7FF3    748 G$OUT11ADDR$0$0 == 0x7ff3
                    7FF3    749 _OUT11ADDR	=	0x7ff3
                    7FF4    750 G$OUT12ADDR$0$0 == 0x7ff4
                    7FF4    751 _OUT12ADDR	=	0x7ff4
                    7FF5    752 G$OUT13ADDR$0$0 == 0x7ff5
                    7FF5    753 _OUT13ADDR	=	0x7ff5
                    7FF6    754 G$OUT14ADDR$0$0 == 0x7ff6
                    7FF6    755 _OUT14ADDR	=	0x7ff6
                    7FF7    756 G$OUT15ADDR$0$0 == 0x7ff7
                    7FF7    757 _OUT15ADDR	=	0x7ff7
                    7FF8    758 G$IN8ADDR$0$0 == 0x7ff8
                    7FF8    759 _IN8ADDR	=	0x7ff8
                    7FF9    760 G$IN9ADDR$0$0 == 0x7ff9
                    7FF9    761 _IN9ADDR	=	0x7ff9
                    7FFA    762 G$IN10ADDR$0$0 == 0x7ffa
                    7FFA    763 _IN10ADDR	=	0x7ffa
                    7FFB    764 G$IN11ADDR$0$0 == 0x7ffb
                    7FFB    765 _IN11ADDR	=	0x7ffb
                    7FFC    766 G$IN12ADDR$0$0 == 0x7ffc
                    7FFC    767 _IN12ADDR	=	0x7ffc
                    7FFD    768 G$IN13ADDR$0$0 == 0x7ffd
                    7FFD    769 _IN13ADDR	=	0x7ffd
                    7FFE    770 G$IN14ADDR$0$0 == 0x7ffe
                    7FFE    771 _IN14ADDR	=	0x7ffe
                    7FFF    772 G$IN15ADDR$0$0 == 0x7fff
                    7FFF    773 _IN15ADDR	=	0x7fff
                    7FE0    774 G$INISOVAL$0$0 == 0x7fe0
                    7FE0    775 _INISOVAL	=	0x7fe0
                    7FE1    776 G$OUTISOVAL$0$0 == 0x7fe1
                    7FE1    777 _OUTISOVAL	=	0x7fe1
                    7FE2    778 G$FASTXFR$0$0 == 0x7fe2
                    7FE2    779 _FASTXFR	=	0x7fe2
                            780 ;--------------------------------------------------------
                            781 ; interrupt vector 
                            782 ;--------------------------------------------------------
                            783 	.area CSEG    (CODE)
   0000                     784 __interrupt_vect:
   0000 02 11 B5            785 	ljmp	__sdcc_gsinit_startup
   0003 32                  786 	reti
   0004                     787 	.ds	7
   000B 02 02 38            788 	ljmp	_timer0
   000E                     789 	.ds	5
   0013 32                  790 	reti
   0014                     791 	.ds	7
   001B 32                  792 	reti
   001C                     793 	.ds	7
   0023 02 0F 82            794 	ljmp	_serial0
   0026                     795 	.ds	5
   002B 32                  796 	reti
   002C                     797 	.ds	7
   0033 32                  798 	reti
   0034                     799 	.ds	7
   003B 32                  800 	reti
   003C                     801 	.ds	7
   0043 02 04 5B            802 	ljmp	_intUSB
   0046                     803 	.ds	5
                            804 ;--------------------------------------------------------
                            805 ; global & static initialisations
                            806 ;--------------------------------------------------------
                            807 	.area GSINIT  (CODE)
                            808 	.area GSFINAL (CODE)
                            809 	.area GSINIT  (CODE)
   11B5                     810 __sdcc_gsinit_startup:
   11B5 75 81 07            811 	mov	sp,#7
   11B8 12 02 DB            812 	lcall	__sdcc_external_startup
   11BB E5 82               813 	mov	a,dpl
   11BD 60 03               814 	jz	__sdcc_init_data
   11BF 02 00 4B            815 	ljmp	__sdcc_program_startup
   11C2                     816 __sdcc_init_data:
                            817 	.area GSFINAL (CODE)
   11D1 02 00 4B            818 	ljmp	__sdcc_program_startup
                            819 ;--------------------------------------------------------
                            820 ; Home
                            821 ;--------------------------------------------------------
                            822 	.area HOME	 (CODE)
                            823 	.area CSEG    (CODE)
                            824 ;--------------------------------------------------------
                            825 ; code
                            826 ;--------------------------------------------------------
                            827 	.area CSEG    (CODE)
   004B                     828 __sdcc_program_startup:
   004B 12 00 50            829 	lcall	_main
                            830 ;	return from main will lock up
   004E 80 FE               831 	sjmp .
                            832 ;------------------------------------------------------------
                            833 ;Allocation info for local variables in function 'main'
                            834 ;------------------------------------------------------------
                    0050    835 	G$main$0$0 ==.
                            836 ;	vwhack.c 16
                            837 ;	-----------------------------------------
                            838 ;	 function main
                            839 ;	-----------------------------------------
   0050                     840 _main:
                    0002    841 	ar2 = 0x02
                    0003    842 	ar3 = 0x03
                    0004    843 	ar4 = 0x04
                    0005    844 	ar5 = 0x05
                    0006    845 	ar6 = 0x06
                    0007    846 	ar7 = 0x07
                    0000    847 	ar0 = 0x00
                    0001    848 	ar1 = 0x01
                            849 ;	vwhack.c 17
   0050 75 D0 00            850 	mov	_PSW,#0x00
                            851 ;	vwhack.c 18
   0053 75 86 00            852 	mov	_DPS,#0x00
                            853 ;	vwhack.c 19
   0056 75 8E 00            854 	mov	_CKCON,#0x00
                            855 ;	vwhack.c 20
   0059 75 A8 00            856 	mov	_IE,#0x00
                            857 ;	vwhack.c 21
   005C 75 E8 00            858 	mov	_EIE,#0x00
                            859 ;	vwhack.c 23
   005F 90 7F A7            860 	mov	dptr,#_I2CMODE
   0062 74 01               861 	mov	a,#0x01
   0064 F0                  862 	movx	@dptr,a
                            863 ;	vwhack.c 24
   0065 90 78 49            864 	mov	dptr,#_PORTSETUP
   0068 74 01               865 	mov	a,#0x01
   006A F0                  866 	movx	@dptr,a
                            867 ;	vwhack.c 26
   006B 90 7F 9C            868 	mov	dptr,#_OEA
   006E 74 1F               869 	mov	a,#0x1F
   0070 F0                  870 	movx	@dptr,a
                            871 ;	vwhack.c 27
   0071 90 7F 9D            872 	mov	dptr,#_OEB
                            873 ; Peephole 180   changed mov to clr
                            874 ;	vwhack.c 28
                            875 ; Peephole 180   changed mov to clr
                            876 ; Peephole 219 removed redundant clear
                            877 ;	vwhack.c 29
                            878 ; Peephole 180   changed mov to clr
                            879 ; Peephole 219a removed redundant clear
   0074 E4                  880 	clr   a
   0075 F0                  881 	movx  @dptr,a
   0076 90 7F 9E            882 	mov   dptr,#_OEC
   0079 F0                  883 	movx  @dptr,a
   007A 90 78 43            884 	mov   dptr,#_OED
   007D F0                  885 	movx  @dptr,a
                            886 ;	vwhack.c 30
   007E 90 78 47            887 	mov	dptr,#_OEE
   0081 74 FF               888 	mov	a,#0xFF
   0083 F0                  889 	movx	@dptr,a
                            890 ;	vwhack.c 32
   0084 75 80 00            891 	mov	_IOA,#0x00
                            892 ;	vwhack.c 34
   0087 12 03 F0            893 	lcall	_initUSB
                            894 ;	vwhack.c 35
   008A 12 0E B8            895 	lcall	_initSerial
                            896 ;	vwhack.c 39
   008D 75 89 31            897 	mov	_TMOD,#0x31
                            898 ;	vwhack.c 40
   0090 75 88 00            899 	mov	_TCON,#0x00
                            900 ;	vwhack.c 41
   0093 75 8A 0F            901 	mov	_TL0,#0x0F
                            902 ;	vwhack.c 42
   0096 75 8C AA            903 	mov	_TH0,#0xAA
                            904 ;	vwhack.c 43
   0099 D2 8C               905 	setb	_TR0
                            906 ;	vwhack.c 46
   009B D2 A9               907 	setb	_ET0
                            908 ;	vwhack.c 47
   009D D2 AF               909 	setb	_EA
                            910 ;	vwhack.c 49
   009F 78 80               911 	mov	r0,#_state
   00A1 76 00               912 	mov	@r0,#0x00
                            913 ;	vwhack.c 50
   00A3 78 81               914 	mov	r0,#_disc
   00A5 76 01               915 	mov	@r0,#0x01
                            916 ;	vwhack.c 51
   00A7 78 82               917 	mov	r0,#_track
   00A9 76 01               918 	mov	@r0,#0x01
                            919 ;	vwhack.c 52
   00AB 78 83               920 	mov	r0,#_mix
   00AD 76 00               921 	mov	@r0,#0x00
                            922 ;	vwhack.c 53
   00AF 78 84               923 	mov	r0,#_scan
   00B1 76 00               924 	mov	@r0,#0x00
                            925 ;	vwhack.c 54
   00B3 12 00 B7            926 	lcall	_idle
   00B6                     927 00101$:
                    00B6    928 	C$vwhack.c$55$1$1 ==.
                    00B6    929 	XG$main$0$0 ==.
   00B6 22                  930 	ret
                            931 ;------------------------------------------------------------
                            932 ;Allocation info for local variables in function 'idle'
                            933 ;------------------------------------------------------------
                            934 ;j                         Allocated to registers r2 
                            935 ;i                         Allocated to registers 
                    00B7    936 	G$idle$0$0 ==.
                            937 ;	vwhack.c 59
                            938 ;	-----------------------------------------
                            939 ;	 function idle
                            940 ;	-----------------------------------------
   00B7                     941 _idle:
                            942 ;	vwhack.c 0
   00B7                     943 00137$:
                            944 ;	vwhack.c 65
   00B7 78 80               945 	mov	r0,#_state
   00B9 B6 00 02            946 	cjne	@r0,#0x00,00163$
                            947 ; Peephole 132   changed ljmp to sjmp
   00BC 80 22               948 	sjmp 00104$
   00BE                     949 00163$:
   00BE 78 80               950 	mov	r0,#_state
   00C0 B6 01 03            951 	cjne	@r0,#0x01,00164$
   00C3 02 01 4E            952 	ljmp	00115$
   00C6                     953 00164$:
   00C6 78 80               954 	mov	r0,#_state
   00C8 B6 02 03            955 	cjne	@r0,#0x02,00165$
   00CB 02 01 F3            956 	ljmp	00134$
   00CE                     957 00165$:
   00CE 78 80               958 	mov	r0,#_state
   00D0 B6 03 03            959 	cjne	@r0,#0x03,00166$
   00D3 02 01 D3            960 	ljmp	00130$
   00D6                     961 00166$:
   00D6 78 80               962 	mov	r0,#_state
   00D8 B6 05 03            963 	cjne	@r0,#0x05,00167$
   00DB 02 01 3F            964 	ljmp	00114$
   00DE                     965 00167$:
                            966 ;	vwhack.c 72
                            967 ; Peephole 132   changed ljmp to sjmp
   00DE 80 D7               968 	sjmp 00137$
   00E0                     969 00104$:
                            970 ;	vwhack.c 67
                            971 ; Peephole 221a remove redundant move
   00E0 E5 44               972 	mov	a,0x0005 + _rxbuf
                            973 ; Peephole 132   changed ljmp to sjmp
                            974 ; Peephole 199   optimized misc jump sequence
   00E2 B4 AB 11            975 	cjne a,#0xAB,00102$
                            976 ;00168$:
                            977 ; Peephole 200   removed redundant sjmp
   00E5                     978 00169$:
                            979 ; Peephole 221a remove redundant move
   00E5 E5 45               980 	mov	a,0x0006 + _rxbuf
                            981 ; Peephole 132   changed ljmp to sjmp
                            982 ; Peephole 199   optimized misc jump sequence
   00E7 B4 AD 0C            983 	cjne a,#0xAD,00102$
                            984 ;00170$:
                            985 ; Peephole 200   removed redundant sjmp
   00EA                     986 00171$:
                            987 ;	vwhack.c 68
   00EA 78 83               988 	mov	r0,#_mix
   00EC 74 FF               989 	mov	a,#0xFF
   00EE 66                  990 	xrl	a,@r0
   00EF F6                  991 	mov	@r0,a
                            992 ;	vwhack.c 69
   00F0 12 0F 4A            993 	lcall	_mixMP3
                            994 ;	vwhack.c 70
   00F3 12 0F 00            995 	lcall	_clearRX
   00F6                     996 00102$:
                            997 ;	vwhack.c 72
                            998 ; Peephole 221a remove redundant move
   00F6 E5 44               999 	mov	a,0x0005 + _rxbuf
                           1000 ; Peephole 132   changed ljmp to sjmp
                           1001 ; Peephole 199   optimized misc jump sequence
   00F8 B4 AD 11           1002 	cjne a,#0xAD,00106$
                           1003 ;00172$:
                           1004 ; Peephole 200   removed redundant sjmp
   00FB                    1005 00173$:
                           1006 ; Peephole 221a remove redundant move
   00FB E5 45              1007 	mov	a,0x0006 + _rxbuf
                           1008 ; Peephole 132   changed ljmp to sjmp
                           1009 ; Peephole 199   optimized misc jump sequence
   00FD B4 D5 0C           1010 	cjne a,#0xD5,00106$
                           1011 ;00174$:
                           1012 ; Peephole 200   removed redundant sjmp
   0100                    1013 00175$:
                           1014 ;	vwhack.c 73
   0100 78 84              1015 	mov	r0,#_scan
   0102 74 FF              1016 	mov	a,#0xFF
   0104 66                 1017 	xrl	a,@r0
   0105 F6                 1018 	mov	@r0,a
                           1019 ;	vwhack.c 74
   0106 12 0F 66           1020 	lcall	_playMP3
                           1021 ;	vwhack.c 75
   0109 12 0F 00           1022 	lcall	_clearRX
   010C                    1023 00106$:
                           1024 ;	vwhack.c 77
                           1025 ; Peephole 221a remove redundant move
   010C E5 44              1026 	mov	a,0x0005 + _rxbuf
                           1027 ; Peephole 132   changed ljmp to sjmp
                           1028 ; Peephole 199   optimized misc jump sequence
   010E B4 BB 0E           1029 	cjne a,#0xBB,00109$
                           1030 ;00176$:
                           1031 ; Peephole 200   removed redundant sjmp
   0111                    1032 00177$:
                           1033 ; Peephole 221a remove redundant move
   0111 E5 45              1034 	mov	a,0x0006 + _rxbuf
                           1035 ; Peephole 132   changed ljmp to sjmp
                           1036 ; Peephole 199   optimized misc jump sequence
   0113 B4 D5 09           1037 	cjne a,#0xD5,00109$
                           1038 ;00178$:
                           1039 ; Peephole 200   removed redundant sjmp
   0116                    1040 00179$:
                           1041 ;	vwhack.c 78
   0116 78 82              1042 	mov	r0,#_track
   0118 16                 1043 	dec	@r0
                           1044 ;	vwhack.c 79
   0119 12 0F 2E           1045 	lcall	_previousMP3
                           1046 ;	vwhack.c 80
   011C 12 0F 00           1047 	lcall	_clearRX
   011F                    1048 00109$:
                           1049 ;	vwhack.c 82
                           1050 ; Peephole 221a remove redundant move
   011F E5 44              1051 	mov	a,0x0005 + _rxbuf
   0121 B4 BB 02           1052 	cjne	a,#0xBB,00180$
   0124 80 03              1053 	sjmp	00181$
   0126                    1054 00180$:
   0126 02 00 B7           1055 	ljmp	00137$
   0129                    1056 00181$:
                           1057 ; Peephole 221a remove redundant move
   0129 E5 45              1058 	mov	a,0x0006 + _rxbuf
   012B B4 AB 02           1059 	cjne	a,#0xAB,00182$
   012E 80 03              1060 	sjmp	00183$
   0130                    1061 00182$:
   0130 02 00 B7           1062 	ljmp	00137$
   0133                    1063 00183$:
                           1064 ;	vwhack.c 83
   0133 78 82              1065 	mov	r0,#_track
   0135 06                 1066 	inc	@r0
                           1067 ;	vwhack.c 84
   0136 12 0F 12           1068 	lcall	_nextMP3
                           1069 ;	vwhack.c 85
   0139 12 0F 00           1070 	lcall	_clearRX
                           1071 ;	vwhack.c 88
   013C 02 00 B7           1072 	ljmp	00137$
                           1073 ;	vwhack.c 90
   013F                    1074 00114$:
                           1075 ; Peephole 182   used 16 bit load of dptr
   013F 90 00 64           1076 	mov  dptr,#(((0x00)<<8) + 0x64)
   0142 12 03 08           1077 	lcall	_msecWait
                           1078 ;	vwhack.c 91
   0145 75 82 00           1079 	mov	dpl,#0x00
   0148 12 02 23           1080 	lcall	_sendByte
                           1081 ;	vwhack.c 92
   014B 02 00 B7           1082 	ljmp	00137$
                           1083 ;	vwhack.c 94
   014E                    1084 00115$:
   014E 12 10 3F           1085 	lcall	_captureCD
                           1086 ;	vwhack.c 95
                           1087 ; Peephole 182   used 16 bit load of dptr
                           1088 ; Peephole 210   simplified expression
   0151 90 02 DF           1089 	mov  dptr,#__str_0
   0154 75 F0 02           1090 	mov	b,#0x02
   0157 12 0B 10           1091 	lcall	_prints
                           1092 ;	vwhack.c 96
   015A 12 0B F8           1093 	lcall	_printDone
                           1094 ;	vwhack.c 98
   015D 90 7F E4           1095 	mov	dptr,#_AUTOPTRL
                           1096 ; Peephole 180   changed mov to clr
   0160 E4                 1097 	clr  a
   0161 F0                 1098 	movx	@dptr,a
                           1099 ;	vwhack.c 99
   0162 90 7F E3           1100 	mov	dptr,#_AUTOPTRH
   0165 74 20              1101 	mov	a,#0x20
   0167 F0                 1102 	movx	@dptr,a
                           1103 ;	vwhack.c 100
   0168 7A 00              1104 	mov	r2,#0x00
                           1105 ;	vwhack.c 101
   016A 7B 00              1106 	mov	r3,#0x00
   016C 7C 00              1107 	mov	r4,#0x00
   016E                    1108 00124$:
   016E C3                 1109 	clr	c
   016F EB                 1110 	mov	a,r3
   0170 94 00              1111 	subb	a,#0x00
   0172 EC                 1112 	mov	a,r4
   0173 94 08              1113 	subb	a,#0x08
   0175 40 03              1114 	jc	00184$
   0177 02 01 C2           1115 	ljmp	00127$
   017A                    1116 00184$:
                           1117 ;	vwhack.c 103
   017A                    1118 00117$:
   017A 90 7F BC           1119 	mov	dptr,#_IN4CS
   017D E0                 1120 	movx	a,@dptr
                           1121 ; Peephole 105   removed redundant mov
   017E FD                 1122 	mov  r5,a
   017F 33                 1123 	rlc	a
   0180 95 E0              1124 	subb	a,acc
   0182 FE                 1125 	mov	r6,a
   0183 53 05 02           1126 	anl	ar5,#0x02
   0186 7E 00              1127 	mov	r6,#0x00
   0188 ED                 1128 	mov	a,r5
   0189 4E                 1129 	orl	a,r6
                           1130 ; Peephole 110   removed ljmp by inverse jump logic
   018A 60 07              1131 	jz  00119$
   018C                    1132 00185$:
   018C 78 80              1133 	mov	r0,#_state
   018E B6 01 02           1134 	cjne	@r0,#0x01,00186$
                           1135 ; Peephole 132   changed ljmp to sjmp
   0191 80 E7              1136 	sjmp 00117$
   0193                    1137 00186$:
   0193                    1138 00119$:
                           1139 ;	vwhack.c 104
   0193 78 80              1140 	mov	r0,#_state
                           1141 ; Peephole 132   changed ljmp to sjmp
                           1142 ; Peephole 199   optimized misc jump sequence
   0195 B6 01 2A           1143 	cjne @r0,#0x01,00127$
                           1144 ;00187$:
                           1145 ; Peephole 200   removed redundant sjmp
   0198                    1146 00188$:
                           1147 ;	vwhack.c 107
   0198 8A 05              1148 	mov	ar5,r2
   019A 0A                 1149 	inc	r2
   019B ED                 1150 	mov	a,r5
   019C 24 00              1151 	add	a,#_IN4BUF
   019E FD                 1152 	mov	r5,a
                           1153 ; Peephole 180   changed mov to clr
   019F E4                 1154 	clr  a
   01A0 34 7D              1155 	addc	a,#(_IN4BUF >> 8)
   01A2 FE                 1156 	mov	r6,a
   01A3 90 7F E5           1157 	mov	dptr,#_AUTODATA
   01A6 E0                 1158 	movx	a,@dptr
                           1159 ; Peephole 136   removed redundant moves
   01A7 FF                 1160 	mov  r7,a
   01A8 8D 82              1161 	mov  dpl,r5
   01AA 8E 83              1162 	mov  dph,r6
   01AC F0                 1163 	movx	@dptr,a
                           1164 ;	vwhack.c 108
   01AD BA 40 00           1165 	cjne	r2,#0x40,00189$
   01B0                    1166 00189$:
                           1167 ; Peephole 132   changed ljmp to sjmp
                           1168 ; Peephole 160   removed sjmp by inverse jump logic
   01B0 40 08              1169 	jc   00126$
   01B2                    1170 00190$:
                           1171 ;	vwhack.c 109
   01B2 90 7F BD           1172 	mov	dptr,#_IN4BC
   01B5 74 40              1173 	mov	a,#0x40
   01B7 F0                 1174 	movx	@dptr,a
                           1175 ;	vwhack.c 110
   01B8 7A 00              1176 	mov	r2,#0x00
   01BA                    1177 00126$:
                           1178 ;	vwhack.c 101
   01BA 0B                 1179 	inc	r3
   01BB BB 00 01           1180 	cjne	r3,#0x00,00191$
   01BE 0C                 1181 	inc	r4
   01BF                    1182 00191$:
   01BF 02 01 6E           1183 	ljmp	00124$
   01C2                    1184 00127$:
                           1185 ;	vwhack.c 113
   01C2 78 80              1186 	mov	r0,#_state
   01C4 B6 01 02           1187 	cjne	@r0,#0x01,00192$
   01C7 80 03              1188 	sjmp	00193$
   01C9                    1189 00192$:
   01C9 02 00 B7           1190 	ljmp	00137$
   01CC                    1191 00193$:
                           1192 ;	vwhack.c 114
   01CC 78 80              1193 	mov	r0,#_state
   01CE 76 00              1194 	mov	@r0,#0x00
                           1195 ;	vwhack.c 115
   01D0 02 00 B7           1196 	ljmp	00137$
                           1197 ;	vwhack.c 117
   01D3                    1198 00130$:
   01D3 C2 A9              1199 	clr	_ET0
                           1200 ;	vwhack.c 118
   01D5                    1201 00131$:
   01D5 78 80              1202 	mov	r0,#_state
                           1203 ; Peephole 132   changed ljmp to sjmp
                           1204 ; Peephole 199   optimized misc jump sequence
   01D7 B6 03 0E           1205 	cjne @r0,#0x03,00133$
                           1206 ;00194$:
                           1207 ; Peephole 200   removed redundant sjmp
   01DA                    1208 00195$:
                           1209 ;	vwhack.c 126
   01DA A2 86              1210 		  mov c,_IOA_6 ;; STX from changer
   01DC 92 81              1211 	          mov _IOA_1,c ;; STX to head unit
   01DE A2 85              1212 		  mov c,_IOA_5 ;; SRX from head unit
   01E0 92 84              1213 	          mov _IOA_4,c ;; SRX to changer
   01E2 A2 87              1214 	          mov c,_IOA_7 ;; SCLK from changer
   01E4 92 80              1215 	          mov _IOA_0,c ;; SCLK to head unit
                           1216 ; Peephole 132   changed ljmp to sjmp
   01E6 80 ED              1217 	sjmp 00131$
   01E8                    1218 00133$:
                           1219 ;	vwhack.c 128
   01E8 C2 81              1220 	clr	_IOA_1
                           1221 ;	vwhack.c 129
   01EA C2 80              1222 	clr	_IOA_0
                           1223 ;	vwhack.c 130
   01EC C2 84              1224 	clr	_IOA_4
                           1225 ;	vwhack.c 131
   01EE D2 A9              1226 	setb	_ET0
                           1227 ;	vwhack.c 132
   01F0 02 00 B7           1228 	ljmp	00137$
                           1229 ;	vwhack.c 134
   01F3                    1230 00134$:
   01F3 C0 02              1231 	push	ar2
   01F5 12 10 1C           1232 	lcall	_captureHead
   01F8 D0 02              1233 	pop	ar2
                           1234 ;	vwhack.c 135
   01FA 78 80              1235 	mov	r0,#_state
   01FC 76 00              1236 	mov	@r0,#0x00
                           1237 ;	vwhack.c 137
   01FE 02 00 B7           1238 	ljmp	00137$
   0201                    1239 00139$:
                    0201   1240 	C$vwhack.c$139$2$2 ==.
                    0201   1241 	XG$idle$0$0 ==.
   0201 22                 1242 	ret
                           1243 ;------------------------------------------------------------
                           1244 ;Allocation info for local variables in function 'sendByte2'
                           1245 ;------------------------------------------------------------
                           1246 ;a                         Allocated to registers r2 
                           1247 ;i                         Allocated to registers 
                    0202   1248 	G$sendByte2$0$0 ==.
                           1249 ;	vwhack.c 141
                           1250 ;	-----------------------------------------
                           1251 ;	 function sendByte2
                           1252 ;	-----------------------------------------
   0202                    1253 _sendByte2:
                           1254 ;	vwhack.c 0
   0202 AA 82              1255 	mov	r2,dpl
                           1256 ;	vwhack.c 143
   0204 53 02 80           1257 	anl	ar2,#0x80
   0207 7B 08              1258 	mov	r3,#0x08
   0209                    1259 00101$:
   0209 8B 04              1260 	mov	ar4,r3
   020B 1B                 1261 	dec	r3
   020C EC                 1262 	mov	a,r4
                           1263 ; Peephole 110   removed ljmp by inverse jump logic
   020D 60 13              1264 	jz  00104$
   020F                    1265 00111$:
                           1266 ;	vwhack.c 144
   020F D2 80              1267 	setb	_IOA_0
                           1268 ;	vwhack.c 145
   0211 EA                 1269 	mov	a,r2
                           1270 ; Peephole 110   removed ljmp by inverse jump logic
   0212 60 04              1271 	jz  00106$
   0214                    1272 00112$:
   0214 7C 01              1273 	mov	r4,#0x01
                           1274 ; Peephole 132   changed ljmp to sjmp
   0216 80 02              1275 	sjmp 00107$
   0218                    1276 00106$:
   0218 7C 00              1277 	mov	r4,#0x00
   021A                    1278 00107$:
   021A EC                 1279 	mov	a,r4
   021B 85 E0 81           1280 	mov	_IOA_1,acc.0
                           1281 ;	vwhack.c 146
   021E C2 80              1282 	clr	_IOA_0
                           1283 ; Peephole 132   changed ljmp to sjmp
   0220 80 E7              1284 	sjmp 00101$
   0222                    1285 00104$:
                    0222   1286 	C$vwhack.c$148$1$1 ==.
                    0222   1287 	XG$sendByte2$0$0 ==.
   0222 22                 1288 	ret
                           1289 ;------------------------------------------------------------
                           1290 ;Allocation info for local variables in function 'sendByte'
                           1291 ;------------------------------------------------------------
                           1292 ;a                         Allocated to registers 
                    0223   1293 	G$sendByte$0$0 ==.
                           1294 ;	vwhack.c 151
                           1295 ;	-----------------------------------------
                           1296 ;	 function sendByte
                           1297 ;	-----------------------------------------
   0223                    1298 _sendByte:
                           1299 ;	vwhack.c 171
   0223 E5 82              1300 	    mov  a, dpl
   0225 7A 08              1301 	    mov  r2, #8
   0227                    1302   00000$:
   0227 D2 80              1303 	    setb _IOA_0           ;; 2 cycles set head unit SCLK HIGH
   0229                    1304   00002$:
   0229 33                 1305 	    rlc  a                ;; 1 cycle
   022A 92 81              1306 	    mov  _IOA_1,c         ;; 2 cycles
   022C C2 80              1307 	    clr  _IOA_0           ;; 2 cycles
   022E DA F7              1308 	    djnz r2,00000$        ;; 3 cycles
                           1309 	    ;; forced delay inbetween bytes. this value was found by trial and error.
   0230 7A B4              1310 	    mov  r2,#180
   0232                    1311   00001$:
   0232 00                 1312 	    nop                   ;; 1 cycle
   0233 00                 1313 	    nop
   0234 DA FC              1314 	    djnz r2,00001$        ;; 3 cycles
   0236 22                 1315 	    ret
                           1316 ;	vwhack.c 173
   0237                    1317 00101$:
                    0237   1318 	C$vwhack.c$174$1$1 ==.
                    0237   1319 	XG$sendByte$0$0 ==.
   0237 22                 1320 	ret
                           1321 ;------------------------------------------------------------
                           1322 ;Allocation info for local variables in function 'timer0'
                           1323 ;------------------------------------------------------------
                    0238   1324 	G$timer0$0$0 ==.
                           1325 ;	vwhack.c 176
                           1326 ;	-----------------------------------------
                           1327 ;	 function timer0
                           1328 ;	-----------------------------------------
   0238                    1329 _timer0:
   0238 C0 E0              1330 	push	acc
   023A C0 F0              1331 	push	b
   023C C0 82              1332 	push	dpl
   023E C0 83              1333 	push	dph
   0240 C0 02              1334 	push	(0+2)
   0242 C0 03              1335 	push	(0+3)
   0244 C0 04              1336 	push	(0+4)
   0246 C0 05              1337 	push	(0+5)
   0248 C0 06              1338 	push	(0+6)
   024A C0 07              1339 	push	(0+7)
   024C C0 00              1340 	push	(0+0)
   024E C0 01              1341 	push	(0+1)
   0250 C0 D0              1342 	push	psw
   0252 75 D0 00           1343 	mov	psw,#0x00
                           1344 ;	vwhack.c 177
   0255 05 30              1345 	inc	_timeCount
                           1346 ;	vwhack.c 178
   0257 C3                 1347 	clr	c
   0258 E5 30              1348 	mov	a,_timeCount
   025A 94 64              1349 	subb	a,#0x64
                           1350 ; Peephole 132   changed ljmp to sjmp
                           1351 ; Peephole 160   removed sjmp by inverse jump logic
   025C 40 58              1352 	jc   00102$
   025E                    1353 00112$:
                           1354 ;	vwhack.c 181
   025E 75 30 00           1355 	mov	_timeCount,#0x00
                           1356 ;	vwhack.c 183
   0261 75 82 34           1357 	mov	dpl,#0x34
   0264 12 02 23           1358 	lcall	_sendByte
                           1359 ;	vwhack.c 184
   0267 78 81              1360 	mov	r0,#_disc
   0269 C3                 1361 	clr	c
   026A 74 0F              1362 	mov	a,#0x0F
   026C 96                 1363 	subb	a,@r0
   026D FA                 1364 	mov	r2,a
   026E 74 80              1365 	mov	a,#0x80
   0270 4A                 1366 	orl	a,r2
   0271 F5 82              1367 	mov	dpl,a
   0273 12 02 23           1368 	lcall	_sendByte
                           1369 ;	vwhack.c 185
   0276 78 82              1370 	mov	r0,#_track
   0278 C3                 1371 	clr	c
   0279 74 FF              1372 	mov	a,#0xFF
   027B 96                 1373 	subb	a,@r0
   027C F5 82              1374 	mov	dpl,a
   027E 12 02 23           1375 	lcall	_sendByte
                           1376 ;	vwhack.c 186
   0281 75 82 FF           1377 	mov	dpl,#0xFF
   0284 12 02 23           1378 	lcall	_sendByte
                           1379 ;	vwhack.c 187
   0287 75 82 FF           1380 	mov	dpl,#0xFF
   028A 12 02 23           1381 	lcall	_sendByte
                           1382 ;	vwhack.c 188
   028D 78 84              1383 	mov	r0,#_scan
   028F E6                 1384 	mov	a,@r0
                           1385 ; Peephole 110   removed ljmp by inverse jump logic
   0290 60 04              1386 	jz  00105$
   0292                    1387 00113$:
   0292 7A 20              1388 	mov	r2,#0x20
                           1389 ; Peephole 132   changed ljmp to sjmp
   0294 80 02              1390 	sjmp 00106$
   0296                    1391 00105$:
   0296 7A F0              1392 	mov	r2,#0xF0
   0298                    1393 00106$:
   0298 78 83              1394 	mov	r0,#_mix
   029A E6                 1395 	mov	a,@r0
                           1396 ; Peephole 110   removed ljmp by inverse jump logic
   029B 60 04              1397 	jz  00107$
   029D                    1398 00114$:
   029D 7B 0B              1399 	mov	r3,#0x0B
                           1400 ; Peephole 132   changed ljmp to sjmp
   029F 80 02              1401 	sjmp 00108$
   02A1                    1402 00107$:
   02A1 7B 0F              1403 	mov	r3,#0x0F
   02A3                    1404 00108$:
   02A3 EB                 1405 	mov	a,r3
   02A4 4A                 1406 	orl	a,r2
   02A5 F5 82              1407 	mov	dpl,a
   02A7 12 02 23           1408 	lcall	_sendByte
                           1409 ;	vwhack.c 189
   02AA 75 82 FF           1410 	mov	dpl,#0xFF
   02AD 12 02 23           1411 	lcall	_sendByte
                           1412 ;	vwhack.c 190
   02B0 75 82 3C           1413 	mov	dpl,#0x3C
   02B3 12 02 23           1414 	lcall	_sendByte
   02B6                    1415 00102$:
                           1416 ;	vwhack.c 194
   02B6 C2 8C              1417 	clr	_TR0
                           1418 ;	vwhack.c 195
   02B8 75 8A 0F           1419 	mov	_TL0,#0x0F
                           1420 ;	vwhack.c 196
   02BB 75 8C AA           1421 	mov	_TH0,#0xAA
                           1422 ;	vwhack.c 197
   02BE D2 8C              1423 	setb	_TR0
   02C0                    1424 00103$:
   02C0 D0 D0              1425 	pop	psw
   02C2 D0 01              1426 	pop	(0+1)
   02C4 D0 00              1427 	pop	(0+0)
   02C6 D0 07              1428 	pop	(0+7)
   02C8 D0 06              1429 	pop	(0+6)
   02CA D0 05              1430 	pop	(0+5)
   02CC D0 04              1431 	pop	(0+4)
   02CE D0 03              1432 	pop	(0+3)
   02D0 D0 02              1433 	pop	(0+2)
   02D2 D0 83              1434 	pop	dph
   02D4 D0 82              1435 	pop	dpl
   02D6 D0 F0              1436 	pop	b
   02D8 D0 E0              1437 	pop	acc
                    02DA   1438 	C$vwhack.c$198$1$1 ==.
                    02DA   1439 	XG$timer0$0$0 ==.
   02DA 32                 1440 	reti
                           1441 ;------------------------------------------------------------
                           1442 ;Allocation info for local variables in function '_sdcc_external_startup'
                           1443 ;------------------------------------------------------------
                    02DB   1444 	G$_sdcc_external_startup$0$0 ==.
                           1445 ;	vwhack.c 200
                           1446 ;	-----------------------------------------
                           1447 ;	 function _sdcc_external_startup
                           1448 ;	-----------------------------------------
   02DB                    1449 __sdcc_external_startup:
   02DB 75 82 00           1450 	mov	dpl,#0x00
   02DE                    1451 00101$:
                    02DE   1452 	C$vwhack.c$200$1$1 ==.
                    02DE   1453 	XG$_sdcc_external_startup$0$0 ==.
   02DE 22                 1454 	ret
                           1455 	.area CSEG    (CODE)
                    02DF   1456 Fvwhack$_str_0$0$0 == .
   02DF                    1457 __str_0:
   02DF 63 61 70 74 75 72  1458 	.ascii "capture complete!"
        65 20 63 6F 6D 70
        6C 65 74 65 21
   02F0 0A                 1459 	.db 0x0A
   02F1 00                 1460 	.db 0x00
