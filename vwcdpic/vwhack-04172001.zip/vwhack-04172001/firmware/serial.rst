                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : FreeWare ANSI-C Compiler
                              3 ; Version 2.2.2 Tue Apr 17 02:00:29 2001
                              4 
                              5 ;--------------------------------------------------------
                              6 	.module serial
                              7 	
                              8 ;--------------------------------------------------------
                              9 ; Public variables in this module
                             10 ;--------------------------------------------------------
                             11 	.globl _timeClocks
                             12 	.globl _IN4CS
                             13 	.globl _OEC
                             14 	.globl _rxloc
                             15 	.globl _rxbuf
                             16 	.globl _txloc
                             17 	.globl _txlen
                             18 	.globl _txbuf
                             19 	.globl _initSerial
                             20 	.globl _clearRX
                             21 	.globl _nextMP3
                             22 	.globl _previousMP3
                             23 	.globl _mixMP3
                             24 	.globl _playMP3
                             25 	.globl _serial0
                             26 	.globl _captureHead
                             27 	.globl _captureCD
                             28 ;--------------------------------------------------------
                             29 ; special function registers
                             30 ;--------------------------------------------------------
                    0081     31 G$SP$0$0 == 0x0081
                    0081     32 _SP	=	0x0081
                    0082     33 G$DPL$0$0 == 0x0082
                    0082     34 _DPL	=	0x0082
                    0083     35 G$DPH$0$0 == 0x0083
                    0083     36 _DPH	=	0x0083
                    0082     37 G$DPL0$0$0 == 0x0082
                    0082     38 _DPL0	=	0x0082
                    0083     39 G$DPH0$0$0 == 0x0083
                    0083     40 _DPH0	=	0x0083
                    0084     41 G$DPL1$0$0 == 0x0084
                    0084     42 _DPL1	=	0x0084
                    0085     43 G$DPH1$0$0 == 0x0085
                    0085     44 _DPH1	=	0x0085
                    0086     45 G$DPS$0$0 == 0x0086
                    0086     46 _DPS	=	0x0086
                    008E     47 G$CKCON$0$0 == 0x008e
                    008E     48 _CKCON	=	0x008e
                    00A2     49 G$INT4CLR$0$0 == 0x00a2
                    00A2     50 _INT4CLR	=	0x00a2
                    00F8     51 G$EIP$0$0 == 0x00f8
                    00F8     52 _EIP	=	0x00f8
                    0087     53 G$PCON$0$0 == 0x0087
                    0087     54 _PCON	=	0x0087
                    0088     55 G$TCON$0$0 == 0x0088
                    0088     56 _TCON	=	0x0088
                    0080     57 G$IOA$0$0 == 0x0080
                    0080     58 _IOA	=	0x0080
                    0090     59 G$IOB$0$0 == 0x0090
                    0090     60 _IOB	=	0x0090
                    00A0     61 G$IOC$0$0 == 0x00a0
                    00A0     62 _IOC	=	0x00a0
                    00B0     63 G$IOD$0$0 == 0x00b0
                    00B0     64 _IOD	=	0x00b0
                    00B1     65 G$IOE$0$0 == 0x00b1
                    00B1     66 _IOE	=	0x00b1
                    0089     67 G$TMOD$0$0 == 0x0089
                    0089     68 _TMOD	=	0x0089
                    008A     69 G$TL0$0$0 == 0x008a
                    008A     70 _TL0	=	0x008a
                    008B     71 G$TL1$0$0 == 0x008b
                    008B     72 _TL1	=	0x008b
                    008C     73 G$TH0$0$0 == 0x008c
                    008C     74 _TH0	=	0x008c
                    008D     75 G$TH1$0$0 == 0x008d
                    008D     76 _TH1	=	0x008d
                    008F     77 G$SPC_FNC$0$0 == 0x008f
                    008F     78 _SPC_FNC	=	0x008f
                    0091     79 G$EXIF$0$0 == 0x0091
                    0091     80 _EXIF	=	0x0091
                    0092     81 G$MPAGE$0$0 == 0x0092
                    0092     82 _MPAGE	=	0x0092
                    0098     83 G$SCON0$0$0 == 0x0098
                    0098     84 _SCON0	=	0x0098
                    0099     85 G$SBUF0$0$0 == 0x0099
                    0099     86 _SBUF0	=	0x0099
                    00A8     87 G$IE$0$0 == 0x00a8
                    00A8     88 _IE	=	0x00a8
                    00B8     89 G$IP$0$0 == 0x00b8
                    00B8     90 _IP	=	0x00b8
                    00C0     91 G$SCON1$0$0 == 0x00c0
                    00C0     92 _SCON1	=	0x00c0
                    00C1     93 G$SBUF1$0$0 == 0x00c1
                    00C1     94 _SBUF1	=	0x00c1
                    00C8     95 G$T2CON$0$0 == 0x00c8
                    00C8     96 _T2CON	=	0x00c8
                    00CA     97 G$RCAP2L$0$0 == 0x00ca
                    00CA     98 _RCAP2L	=	0x00ca
                    00CB     99 G$RCAP2H$0$0 == 0x00cb
                    00CB    100 _RCAP2H	=	0x00cb
                    00CC    101 G$TL2$0$0 == 0x00cc
                    00CC    102 _TL2	=	0x00cc
                    00CD    103 G$TH2$0$0 == 0x00cd
                    00CD    104 _TH2	=	0x00cd
                    00D0    105 G$PSW$0$0 == 0x00d0
                    00D0    106 _PSW	=	0x00d0
                    00D8    107 G$EICON$0$0 == 0x00d8
                    00D8    108 _EICON	=	0x00d8
                    00E0    109 G$ACC$0$0 == 0x00e0
                    00E0    110 _ACC	=	0x00e0
                    00E8    111 G$EIE$0$0 == 0x00e8
                    00E8    112 _EIE	=	0x00e8
                    00F0    113 G$B$0$0 == 0x00f0
                    00F0    114 _B	=	0x00f0
                            115 ;--------------------------------------------------------
                            116 ; special function bits 
                            117 ;--------------------------------------------------------
                    00FC    118 G$PX6$0$0 == 0x00fc
                    00FC    119 _PX6	=	0x00fc
                    00FB    120 G$PX5$0$0 == 0x00fb
                    00FB    121 _PX5	=	0x00fb
                    00FA    122 G$PX4$0$0 == 0x00fa
                    00FA    123 _PX4	=	0x00fa
                    00F9    124 G$PI2C$0$0 == 0x00f9
                    00F9    125 _PI2C	=	0x00f9
                    00F8    126 G$PUSB$0$0 == 0x00f8
                    00F8    127 _PUSB	=	0x00f8
                    008F    128 G$TF1$0$0 == 0x008f
                    008F    129 _TF1	=	0x008f
                    008E    130 G$TR1$0$0 == 0x008e
                    008E    131 _TR1	=	0x008e
                    008D    132 G$TF0$0$0 == 0x008d
                    008D    133 _TF0	=	0x008d
                    008C    134 G$TR0$0$0 == 0x008c
                    008C    135 _TR0	=	0x008c
                    008B    136 G$IE1$0$0 == 0x008b
                    008B    137 _IE1	=	0x008b
                    008A    138 G$IT1$0$0 == 0x008a
                    008A    139 _IT1	=	0x008a
                    0089    140 G$IE0$0$0 == 0x0089
                    0089    141 _IE0	=	0x0089
                    0088    142 G$IT0$0$0 == 0x0088
                    0088    143 _IT0	=	0x0088
                    0080    144 G$IOA_0$0$0 == 0x0080
                    0080    145 _IOA_0	=	0x0080
                    0081    146 G$IOA_1$0$0 == 0x0081
                    0081    147 _IOA_1	=	0x0081
                    0082    148 G$IOA_2$0$0 == 0x0082
                    0082    149 _IOA_2	=	0x0082
                    0083    150 G$IOA_3$0$0 == 0x0083
                    0083    151 _IOA_3	=	0x0083
                    0084    152 G$IOA_4$0$0 == 0x0084
                    0084    153 _IOA_4	=	0x0084
                    0085    154 G$IOA_5$0$0 == 0x0085
                    0085    155 _IOA_5	=	0x0085
                    0086    156 G$IOA_6$0$0 == 0x0086
                    0086    157 _IOA_6	=	0x0086
                    0087    158 G$IOA_7$0$0 == 0x0087
                    0087    159 _IOA_7	=	0x0087
                    0090    160 G$IOB_0$0$0 == 0x0090
                    0090    161 _IOB_0	=	0x0090
                    0091    162 G$IOB_1$0$0 == 0x0091
                    0091    163 _IOB_1	=	0x0091
                    0092    164 G$IOB_2$0$0 == 0x0092
                    0092    165 _IOB_2	=	0x0092
                    0093    166 G$IOB_3$0$0 == 0x0093
                    0093    167 _IOB_3	=	0x0093
                    0094    168 G$IOB_4$0$0 == 0x0094
                    0094    169 _IOB_4	=	0x0094
                    0095    170 G$IOB_5$0$0 == 0x0095
                    0095    171 _IOB_5	=	0x0095
                    0096    172 G$IOB_6$0$0 == 0x0096
                    0096    173 _IOB_6	=	0x0096
                    0097    174 G$IOB_7$0$0 == 0x0097
                    0097    175 _IOB_7	=	0x0097
                    00A0    176 G$IOC_0$0$0 == 0x00a0
                    00A0    177 _IOC_0	=	0x00a0
                    00A1    178 G$IOC_1$0$0 == 0x00a1
                    00A1    179 _IOC_1	=	0x00a1
                    00A2    180 G$IOC_2$0$0 == 0x00a2
                    00A2    181 _IOC_2	=	0x00a2
                    00A3    182 G$IOC_3$0$0 == 0x00a3
                    00A3    183 _IOC_3	=	0x00a3
                    00A4    184 G$IOC_4$0$0 == 0x00a4
                    00A4    185 _IOC_4	=	0x00a4
                    00A5    186 G$IOC_5$0$0 == 0x00a5
                    00A5    187 _IOC_5	=	0x00a5
                    00A6    188 G$IOC_6$0$0 == 0x00a6
                    00A6    189 _IOC_6	=	0x00a6
                    00A7    190 G$IOC_7$0$0 == 0x00a7
                    00A7    191 _IOC_7	=	0x00a7
                    00B0    192 G$IOD_0$0$0 == 0x00b0
                    00B0    193 _IOD_0	=	0x00b0
                    00B1    194 G$IOD_1$0$0 == 0x00b1
                    00B1    195 _IOD_1	=	0x00b1
                    00B2    196 G$IOD_2$0$0 == 0x00b2
                    00B2    197 _IOD_2	=	0x00b2
                    00B3    198 G$IOD_3$0$0 == 0x00b3
                    00B3    199 _IOD_3	=	0x00b3
                    00B4    200 G$IOD_4$0$0 == 0x00b4
                    00B4    201 _IOD_4	=	0x00b4
                    00B5    202 G$IOD_5$0$0 == 0x00b5
                    00B5    203 _IOD_5	=	0x00b5
                    00B6    204 G$IOD_6$0$0 == 0x00b6
                    00B6    205 _IOD_6	=	0x00b6
                    00B7    206 G$IOD_7$0$0 == 0x00b7
                    00B7    207 _IOD_7	=	0x00b7
                    009F    208 G$SM0_0$0$0 == 0x009f
                    009F    209 _SM0_0	=	0x009f
                    009E    210 G$SM1_0$0$0 == 0x009e
                    009E    211 _SM1_0	=	0x009e
                    009D    212 G$SM2_0$0$0 == 0x009d
                    009D    213 _SM2_0	=	0x009d
                    009C    214 G$REN_0$0$0 == 0x009c
                    009C    215 _REN_0	=	0x009c
                    009B    216 G$TB8_0$0$0 == 0x009b
                    009B    217 _TB8_0	=	0x009b
                    009A    218 G$RB8_0$0$0 == 0x009a
                    009A    219 _RB8_0	=	0x009a
                    0099    220 G$TI_0$0$0 == 0x0099
                    0099    221 _TI_0	=	0x0099
                    0098    222 G$RI_0$0$0 == 0x0098
                    0098    223 _RI_0	=	0x0098
                    00AF    224 G$EA$0$0 == 0x00af
                    00AF    225 _EA	=	0x00af
                    00AE    226 G$ES1$0$0 == 0x00ae
                    00AE    227 _ES1	=	0x00ae
                    00AD    228 G$ET2$0$0 == 0x00ad
                    00AD    229 _ET2	=	0x00ad
                    00AC    230 G$ES0$0$0 == 0x00ac
                    00AC    231 _ES0	=	0x00ac
                    00AB    232 G$ET1$0$0 == 0x00ab
                    00AB    233 _ET1	=	0x00ab
                    00AA    234 G$EX1$0$0 == 0x00aa
                    00AA    235 _EX1	=	0x00aa
                    00A9    236 G$ET0$0$0 == 0x00a9
                    00A9    237 _ET0	=	0x00a9
                    00A8    238 G$EX0$0$0 == 0x00a8
                    00A8    239 _EX0	=	0x00a8
                    00BE    240 G$PS1$0$0 == 0x00be
                    00BE    241 _PS1	=	0x00be
                    00BD    242 G$PT2$0$0 == 0x00bd
                    00BD    243 _PT2	=	0x00bd
                    00BC    244 G$PS0$0$0 == 0x00bc
                    00BC    245 _PS0	=	0x00bc
                    00BB    246 G$PT1$0$0 == 0x00bb
                    00BB    247 _PT1	=	0x00bb
                    00BA    248 G$PX1$0$0 == 0x00ba
                    00BA    249 _PX1	=	0x00ba
                    00B9    250 G$PT0$0$0 == 0x00b9
                    00B9    251 _PT0	=	0x00b9
                    00B8    252 G$PX0$0$0 == 0x00b8
                    00B8    253 _PX0	=	0x00b8
                    00C7    254 G$SM0_1$0$0 == 0x00c7
                    00C7    255 _SM0_1	=	0x00c7
                    00C6    256 G$SM1_1$0$0 == 0x00c6
                    00C6    257 _SM1_1	=	0x00c6
                    00C5    258 G$SM2_1$0$0 == 0x00c5
                    00C5    259 _SM2_1	=	0x00c5
                    00C4    260 G$REN_1$0$0 == 0x00c4
                    00C4    261 _REN_1	=	0x00c4
                    00C3    262 G$TB8_1$0$0 == 0x00c3
                    00C3    263 _TB8_1	=	0x00c3
                    00C2    264 G$RB8_1$0$0 == 0x00c2
                    00C2    265 _RB8_1	=	0x00c2
                    00C1    266 G$TI_1$0$0 == 0x00c1
                    00C1    267 _TI_1	=	0x00c1
                    00C0    268 G$RI_1$0$0 == 0x00c0
                    00C0    269 _RI_1	=	0x00c0
                    00CF    270 G$TF2$0$0 == 0x00cf
                    00CF    271 _TF2	=	0x00cf
                    00CE    272 G$EXF2$0$0 == 0x00ce
                    00CE    273 _EXF2	=	0x00ce
                    00CD    274 G$RCLK$0$0 == 0x00cd
                    00CD    275 _RCLK	=	0x00cd
                    00CC    276 G$TCLK$0$0 == 0x00cc
                    00CC    277 _TCLK	=	0x00cc
                    00CB    278 G$EXEN2$0$0 == 0x00cb
                    00CB    279 _EXEN2	=	0x00cb
                    00CA    280 G$TR2$0$0 == 0x00ca
                    00CA    281 _TR2	=	0x00ca
                    00C9    282 G$CT2$0$0 == 0x00c9
                    00C9    283 _CT2	=	0x00c9
                    00C8    284 G$CPRL2$0$0 == 0x00c8
                    00C8    285 _CPRL2	=	0x00c8
                    00D7    286 G$CY$0$0 == 0x00d7
                    00D7    287 _CY	=	0x00d7
                    00D6    288 G$AC$0$0 == 0x00d6
                    00D6    289 _AC	=	0x00d6
                    00D5    290 G$F0$0$0 == 0x00d5
                    00D5    291 _F0	=	0x00d5
                    00D4    292 G$RS1$0$0 == 0x00d4
                    00D4    293 _RS1	=	0x00d4
                    00D3    294 G$RS0$0$0 == 0x00d3
                    00D3    295 _RS0	=	0x00d3
                    00D2    296 G$OV$0$0 == 0x00d2
                    00D2    297 _OV	=	0x00d2
                    00D0    298 G$P$0$0 == 0x00d0
                    00D0    299 _P	=	0x00d0
                    00DF    300 G$SMOD1$0$0 == 0x00df
                    00DF    301 _SMOD1	=	0x00df
                    00DD    302 G$ERESI$0$0 == 0x00dd
                    00DD    303 _ERESI	=	0x00dd
                    00DC    304 G$RESI$0$0 == 0x00dc
                    00DC    305 _RESI	=	0x00dc
                    00DB    306 G$INT6$0$0 == 0x00db
                    00DB    307 _INT6	=	0x00db
                    00EC    308 G$EWDI$0$0 == 0x00ec
                    00EC    309 _EWDI	=	0x00ec
                    00EB    310 G$EX5$0$0 == 0x00eb
                    00EB    311 _EX5	=	0x00eb
                    00EA    312 G$EX4$0$0 == 0x00ea
                    00EA    313 _EX4	=	0x00ea
                    00E9    314 G$EI2C$0$0 == 0x00e9
                    00E9    315 _EI2C	=	0x00e9
                    00E8    316 G$EUSB$0$0 == 0x00e8
                    00E8    317 _EUSB	=	0x00e8
                            318 ;--------------------------------------------------------
                            319 ; internal ram data
                            320 ;--------------------------------------------------------
                            321 	.area DSEG    (DATA)
                    0000    322 G$txbuf$0$0==.
   0033                     323 _txbuf::
   0033                     324 	.ds 10
                    000A    325 G$txlen$0$0==.
   003D                     326 _txlen::
   003D                     327 	.ds 1
                    000B    328 G$txloc$0$0==.
   003E                     329 _txloc::
   003E                     330 	.ds 1
                    000C    331 G$rxbuf$0$0==.
   003F                     332 _rxbuf::
   003F                     333 	.ds 16
                    001C    334 G$rxloc$0$0==.
   004F                     335 _rxloc::
   004F                     336 	.ds 1
                            337 ;--------------------------------------------------------
                            338 ; overlayable items in internal ram 
                            339 ;--------------------------------------------------------
                            340 	.area OSEG    (OVR,DATA)
                            341 ;--------------------------------------------------------
                            342 ; indirectly addressable internal ram data
                            343 ;--------------------------------------------------------
                            344 	.area ISEG    (DATA)
                            345 ;--------------------------------------------------------
                            346 ; bit data
                            347 ;--------------------------------------------------------
                            348 	.area BSEG    (BIT)
                            349 ;--------------------------------------------------------
                            350 ; external ram data
                            351 ;--------------------------------------------------------
                            352 	.area XSEG    (XDATA)
                    7800    353 G$AINDATA$0$0 == 0x7800
                    7800    354 _AINDATA	=	0x7800
                    7801    355 G$AINBC$0$0 == 0x7801
                    7801    356 _AINBC	=	0x7801
                    7802    357 G$AINPF$0$0 == 0x7802
                    7802    358 _AINPF	=	0x7802
                    7803    359 G$AINPFPIN$0$0 == 0x7803
                    7803    360 _AINPFPIN	=	0x7803
                    7805    361 G$BINDATA$0$0 == 0x7805
                    7805    362 _BINDATA	=	0x7805
                    7806    363 G$BINBC$0$0 == 0x7806
                    7806    364 _BINBC	=	0x7806
                    7807    365 G$BINPF$0$0 == 0x7807
                    7807    366 _BINPF	=	0x7807
                    7808    367 G$BINPFPIN$0$0 == 0x7808
                    7808    368 _BINPFPIN	=	0x7808
                    780A    369 G$ABINTF$0$0 == 0x780a
                    780A    370 _ABINTF	=	0x780a
                    780B    371 G$ABINIE$0$0 == 0x780b
                    780B    372 _ABINIE	=	0x780b
                    780C    373 G$ABINIRQ$0$0 == 0x780c
                    780C    374 _ABINIRQ	=	0x780c
                    780E    375 G$AOUTDATA$0$0 == 0x780e
                    780E    376 _AOUTDATA	=	0x780e
                    780F    377 G$AOUTBC$0$0 == 0x780f
                    780F    378 _AOUTBC	=	0x780f
                    7810    379 G$AOUTPF$0$0 == 0x7810
                    7810    380 _AOUTPF	=	0x7810
                    7811    381 G$AOUTPFPIN$0$0 == 0x7811
                    7811    382 _AOUTPFPIN	=	0x7811
                    7813    383 G$BOUTDATA$0$0 == 0x7813
                    7813    384 _BOUTDATA	=	0x7813
                    7814    385 G$BOUTBC$0$0 == 0x7814
                    7814    386 _BOUTBC	=	0x7814
                    7815    387 G$BOUTPF$0$0 == 0x7815
                    7815    388 _BOUTPF	=	0x7815
                    7816    389 G$BOUTPFPIN$0$0 == 0x7816
                    7816    390 _BOUTPFPIN	=	0x7816
                    7818    391 G$ABOUTTF$0$0 == 0x7818
                    7818    392 _ABOUTTF	=	0x7818
                    7819    393 G$ABOUTIE$0$0 == 0x7819
                    7819    394 _ABOUTIE	=	0x7819
                    781A    395 G$ABOUTIRQ$0$0 == 0x781a
                    781A    396 _ABOUTIRQ	=	0x781a
                    781C    397 G$ABSETUP$0$0 == 0x781c
                    781C    398 _ABSETUP	=	0x781c
                    781D    399 G$ABPOLAR$0$0 == 0x781d
                    781D    400 _ABPOLAR	=	0x781d
                    781E    401 G$ABFLUSH$0$0 == 0x781e
                    781E    402 _ABFLUSH	=	0x781e
                    7824    403 G$WFSELECT$0$0 == 0x7824
                    7824    404 _WFSELECT	=	0x7824
                    7825    405 G$IDLE_CS$0$0 == 0x7825
                    7825    406 _IDLE_CS	=	0x7825
                    7826    407 G$IDLE_CTLOUT$0$0 == 0x7826
                    7826    408 _IDLE_CTLOUT	=	0x7826
                    7827    409 G$CTLOUTCFG$0$0 == 0x7827
                    7827    410 _CTLOUTCFG	=	0x7827
                    782A    411 G$GPIFADRL$0$0 == 0x782a
                    782A    412 _GPIFADRL	=	0x782a
                    7900    413 G$WFDESC$0$0 == 0x7900
                    7900    414 _WFDESC	=	0x7900
                    7900    415 G$WFDESC0$0$0 == 0x7900
                    7900    416 _WFDESC0	=	0x7900
                    7920    417 G$WFDESC1$0$0 == 0x7920
                    7920    418 _WFDESC1	=	0x7920
                    7940    419 G$WFDESC2$0$0 == 0x7940
                    7940    420 _WFDESC2	=	0x7940
                    7960    421 G$WFDESC3$0$0 == 0x7960
                    7960    422 _WFDESC3	=	0x7960
                    782C    423 G$AINTC$0$0 == 0x782c
                    782C    424 _AINTC	=	0x782c
                    782D    425 G$AOUTTC$0$0 == 0x782d
                    782D    426 _AOUTTC	=	0x782d
                    782E    427 G$ATRIG$0$0 == 0x782e
                    782E    428 _ATRIG	=	0x782e
                    7830    429 G$BINTC$0$0 == 0x7830
                    7830    430 _BINTC	=	0x7830
                    7831    431 G$BOUTTC$0$0 == 0x7831
                    7831    432 _BOUTTC	=	0x7831
                    7832    433 G$BTRIG$0$0 == 0x7832
                    7832    434 _BTRIG	=	0x7832
                    7834    435 G$SGLDATH$0$0 == 0x7834
                    7834    436 _SGLDATH	=	0x7834
                    7835    437 G$SGLDATLTRIG$0$0 == 0x7835
                    7835    438 _SGLDATLTRIG	=	0x7835
                    7836    439 G$SGLDATLNTRIG$0$0 == 0x7836
                    7836    440 _SGLDATLNTRIG	=	0x7836
                    7838    441 G$READY$0$0 == 0x7838
                    7838    442 _READY	=	0x7838
                    7839    443 G$ABORT$0$0 == 0x7839
                    7839    444 _ABORT	=	0x7839
                    783B    445 G$GENIE$0$0 == 0x783b
                    783B    446 _GENIE	=	0x783b
                    783C    447 G$GENIRQ$0$0 == 0x783c
                    783C    448 _GENIRQ	=	0x783c
                    784A    449 G$IFCONFIG$0$0 == 0x784a
                    784A    450 _IFCONFIG	=	0x784a
                    7FE3    451 G$AUTOPTRH$0$0 == 0x7fe3
                    7FE3    452 _AUTOPTRH	=	0x7fe3
                    7FE4    453 G$AUTOPTRL$0$0 == 0x7fe4
                    7FE4    454 _AUTOPTRL	=	0x7fe4
                    7FE5    455 G$AUTODATA$0$0 == 0x7fe5
                    7FE5    456 _AUTODATA	=	0x7fe5
                    7F96    457 G$OUTA$0$0 == 0x7f96
                    7F96    458 _OUTA	=	0x7f96
                    7F97    459 G$OUTB$0$0 == 0x7f97
                    7F97    460 _OUTB	=	0x7f97
                    7F98    461 G$OUTC$0$0 == 0x7f98
                    7F98    462 _OUTC	=	0x7f98
                    7841    463 G$OUTD$0$0 == 0x7841
                    7841    464 _OUTD	=	0x7841
                    7845    465 G$OUTE$0$0 == 0x7845
                    7845    466 _OUTE	=	0x7845
                    7F99    467 G$PINSA$0$0 == 0x7f99
                    7F99    468 _PINSA	=	0x7f99
                    7F9A    469 G$PINSB$0$0 == 0x7f9a
                    7F9A    470 _PINSB	=	0x7f9a
                    7F9B    471 G$PINSC$0$0 == 0x7f9b
                    7F9B    472 _PINSC	=	0x7f9b
                    7842    473 G$PINSD$0$0 == 0x7842
                    7842    474 _PINSD	=	0x7842
                    7846    475 G$PINSE$0$0 == 0x7846
                    7846    476 _PINSE	=	0x7846
                    7F9C    477 G$OEA$0$0 == 0x7f9c
                    7F9C    478 _OEA	=	0x7f9c
                    7F9D    479 G$OEB$0$0 == 0x7f9d
                    7F9D    480 _OEB	=	0x7f9d
                    7F9E    481 G$OEC$0$0 == 0x7f9e
                    7F9E    482 _OEC	=	0x7f9e
                    7843    483 G$OED$0$0 == 0x7843
                    7843    484 _OED	=	0x7843
                    7847    485 G$OEE$0$0 == 0x7847
                    7847    486 _OEE	=	0x7847
                    7F93    487 G$PORTACFG$0$0 == 0x7f93
                    7F93    488 _PORTACFG	=	0x7f93
                    7F94    489 G$PORTBCFG$0$0 == 0x7f94
                    7F94    490 _PORTBCFG	=	0x7f94
                    7F95    491 G$PORTCCFG$0$0 == 0x7f95
                    7F95    492 _PORTCCFG	=	0x7f95
                    784C    493 G$PORTCCF2$0$0 == 0x784c
                    784C    494 _PORTCCF2	=	0x784c
                    7849    495 G$PORTSETUP$0$0 == 0x7849
                    7849    496 _PORTSETUP	=	0x7849
                    785D    497 G$INT4IVEC$0$0 == 0x785d
                    785D    498 _INT4IVEC	=	0x785d
                    785E    499 G$INT4SETUP$0$0 == 0x785e
                    785E    500 _INT4SETUP	=	0x785e
                    784F    501 G$DMASRCH$0$0 == 0x784f
                    784F    502 _DMASRCH	=	0x784f
                    7850    503 G$DMASRCL$0$0 == 0x7850
                    7850    504 _DMASRCL	=	0x7850
                    7851    505 G$DMADESTH$0$0 == 0x7851
                    7851    506 _DMADESTH	=	0x7851
                    7852    507 G$DMADESTL$0$0 == 0x7852
                    7852    508 _DMADESTL	=	0x7852
                    7857    509 G$DMABURST$0$0 == 0x7857
                    7857    510 _DMABURST	=	0x7857
                    7854    511 G$DMALEN$0$0 == 0x7854
                    7854    512 _DMALEN	=	0x7854
                    7855    513 G$DMAGO$0$0 == 0x7855
                    7855    514 _DMAGO	=	0x7855
                    7FA6    515 G$I2DAT$0$0 == 0x7fa6
                    7FA6    516 _I2DAT	=	0x7fa6
                    7FA5    517 G$I2CS$0$0 == 0x7fa5
                    7FA5    518 _I2CS	=	0x7fa5
                    7FA7    519 G$I2CMODE$0$0 == 0x7fa7
                    7FA7    520 _I2CMODE	=	0x7fa7
                    7F92    521 G$CPUCS$0$0 == 0x7f92
                    7F92    522 _CPUCS	=	0x7f92
                    7FA0    523 G$ISOERR$0$0 == 0x7fa0
                    7FA0    524 _ISOERR	=	0x7fa0
                    7FA1    525 G$ISOCTL$0$0 == 0x7fa1
                    7FA1    526 _ISOCTL	=	0x7fa1
                    7FA2    527 G$ZBCOUNT$0$0 == 0x7fa2
                    7FA2    528 _ZBCOUNT	=	0x7fa2
                    7F00    529 G$IN0BUF$0$0 == 0x7f00
                    7F00    530 _IN0BUF	=	0x7f00
                    7EC0    531 G$OUT0BUF$0$0 == 0x7ec0
                    7EC0    532 _OUT0BUF	=	0x7ec0
                    7E80    533 G$IN1BUF$0$0 == 0x7e80
                    7E80    534 _IN1BUF	=	0x7e80
                    7E40    535 G$OUT1BUF$0$0 == 0x7e40
                    7E40    536 _OUT1BUF	=	0x7e40
                    7E00    537 G$IN2BUF$0$0 == 0x7e00
                    7E00    538 _IN2BUF	=	0x7e00
                    7DC0    539 G$OUT2BUF$0$0 == 0x7dc0
                    7DC0    540 _OUT2BUF	=	0x7dc0
                    7D80    541 G$IN3BUF$0$0 == 0x7d80
                    7D80    542 _IN3BUF	=	0x7d80
                    7D40    543 G$OUT3BUF$0$0 == 0x7d40
                    7D40    544 _OUT3BUF	=	0x7d40
                    7D00    545 G$IN4BUF$0$0 == 0x7d00
                    7D00    546 _IN4BUF	=	0x7d00
                    7CC0    547 G$OUT4BUF$0$0 == 0x7cc0
                    7CC0    548 _OUT4BUF	=	0x7cc0
                    7C80    549 G$IN5BUF$0$0 == 0x7c80
                    7C80    550 _IN5BUF	=	0x7c80
                    7C40    551 G$OUT5BUF$0$0 == 0x7c40
                    7C40    552 _OUT5BUF	=	0x7c40
                    7C00    553 G$IN6BUF$0$0 == 0x7c00
                    7C00    554 _IN6BUF	=	0x7c00
                    7BC0    555 G$OUT6BUF$0$0 == 0x7bc0
                    7BC0    556 _OUT6BUF	=	0x7bc0
                    7B80    557 G$IN7BUF$0$0 == 0x7b80
                    7B80    558 _IN7BUF	=	0x7b80
                    7B40    559 G$OUT7BUF$0$0 == 0x7b40
                    7B40    560 _OUT7BUF	=	0x7b40
                    7FE8    561 G$SETUPBUF$0$0 == 0x7fe8
                    7FE8    562 _SETUPBUF	=	0x7fe8
                    7FE8    563 G$SETUPDAT$0$0 == 0x7fe8
                    7FE8    564 _SETUPDAT	=	0x7fe8
                    7FB4    565 G$EP0CS$0$0 == 0x7fb4
                    7FB4    566 _EP0CS	=	0x7fb4
                    7FB5    567 G$IN0BC$0$0 == 0x7fb5
                    7FB5    568 _IN0BC	=	0x7fb5
                    7FB6    569 G$IN1CS$0$0 == 0x7fb6
                    7FB6    570 _IN1CS	=	0x7fb6
                    7FB7    571 G$IN1BC$0$0 == 0x7fb7
                    7FB7    572 _IN1BC	=	0x7fb7
                    7FB8    573 G$IN2CS$0$0 == 0x7fb8
                    7FB8    574 _IN2CS	=	0x7fb8
                    7FB9    575 G$IN2BC$0$0 == 0x7fb9
                    7FB9    576 _IN2BC	=	0x7fb9
                    7FBA    577 G$IN3CS$0$0 == 0x7fba
                    7FBA    578 _IN3CS	=	0x7fba
                    7FBB    579 G$IN3BC$0$0 == 0x7fbb
                    7FBB    580 _IN3BC	=	0x7fbb
                    7FBC    581 G$IN4CS$0$0 == 0x7fbc
                    7FBC    582 _IN4CS	=	0x7fbc
                    7FBD    583 G$IN4BC$0$0 == 0x7fbd
                    7FBD    584 _IN4BC	=	0x7fbd
                    7FBE    585 G$IN5CS$0$0 == 0x7fbe
                    7FBE    586 _IN5CS	=	0x7fbe
                    7FBF    587 G$IN5BC$0$0 == 0x7fbf
                    7FBF    588 _IN5BC	=	0x7fbf
                    7FC0    589 G$IN6CS$0$0 == 0x7fc0
                    7FC0    590 _IN6CS	=	0x7fc0
                    7FC1    591 G$IN6BC$0$0 == 0x7fc1
                    7FC1    592 _IN6BC	=	0x7fc1
                    7FC2    593 G$IN7CS$0$0 == 0x7fc2
                    7FC2    594 _IN7CS	=	0x7fc2
                    7FC3    595 G$IN7BC$0$0 == 0x7fc3
                    7FC3    596 _IN7BC	=	0x7fc3
                    7FC5    597 G$OUT0BC$0$0 == 0x7fc5
                    7FC5    598 _OUT0BC	=	0x7fc5
                    7FC6    599 G$OUT1CS$0$0 == 0x7fc6
                    7FC6    600 _OUT1CS	=	0x7fc6
                    7FC7    601 G$OUT1BC$0$0 == 0x7fc7
                    7FC7    602 _OUT1BC	=	0x7fc7
                    7FC8    603 G$OUT2CS$0$0 == 0x7fc8
                    7FC8    604 _OUT2CS	=	0x7fc8
                    7FC9    605 G$OUT2BC$0$0 == 0x7fc9
                    7FC9    606 _OUT2BC	=	0x7fc9
                    7FCA    607 G$OUT3CS$0$0 == 0x7fca
                    7FCA    608 _OUT3CS	=	0x7fca
                    7FCB    609 G$OUT3BC$0$0 == 0x7fcb
                    7FCB    610 _OUT3BC	=	0x7fcb
                    7FCC    611 G$OUT4CS$0$0 == 0x7fcc
                    7FCC    612 _OUT4CS	=	0x7fcc
                    7FCD    613 G$OUT4BC$0$0 == 0x7fcd
                    7FCD    614 _OUT4BC	=	0x7fcd
                    7FCE    615 G$OUT5CS$0$0 == 0x7fce
                    7FCE    616 _OUT5CS	=	0x7fce
                    7FCF    617 G$OUT5BC$0$0 == 0x7fcf
                    7FCF    618 _OUT5BC	=	0x7fcf
                    7FD0    619 G$OUT6CS$0$0 == 0x7fd0
                    7FD0    620 _OUT6CS	=	0x7fd0
                    7FD1    621 G$OUT6BC$0$0 == 0x7fd1
                    7FD1    622 _OUT6BC	=	0x7fd1
                    7FD2    623 G$OUT7CS$0$0 == 0x7fd2
                    7FD2    624 _OUT7CS	=	0x7fd2
                    7FD3    625 G$OUT7BC$0$0 == 0x7fd3
                    7FD3    626 _OUT7BC	=	0x7fd3
                    7FA8    627 G$IVEC$0$0 == 0x7fa8
                    7FA8    628 _IVEC	=	0x7fa8
                    7FA9    629 G$IN07IRQ$0$0 == 0x7fa9
                    7FA9    630 _IN07IRQ	=	0x7fa9
                    7FAA    631 G$OUT07IRQ$0$0 == 0x7faa
                    7FAA    632 _OUT07IRQ	=	0x7faa
                    7FAB    633 G$USBIRQ$0$0 == 0x7fab
                    7FAB    634 _USBIRQ	=	0x7fab
                    7FAC    635 G$IN07IEN$0$0 == 0x7fac
                    7FAC    636 _IN07IEN	=	0x7fac
                    7FAD    637 G$OUT07IEN$0$0 == 0x7fad
                    7FAD    638 _OUT07IEN	=	0x7fad
                    7FAE    639 G$USBIEN$0$0 == 0x7fae
                    7FAE    640 _USBIEN	=	0x7fae
                    7FAF    641 G$USBBAV$0$0 == 0x7faf
                    7FAF    642 _USBBAV	=	0x7faf
                    7FB2    643 G$BPADDRH$0$0 == 0x7fb2
                    7FB2    644 _BPADDRH	=	0x7fb2
                    7FB3    645 G$BPADDRL$0$0 == 0x7fb3
                    7FB3    646 _BPADDRL	=	0x7fb3
                    7FD4    647 G$SUDPTRH$0$0 == 0x7fd4
                    7FD4    648 _SUDPTRH	=	0x7fd4
                    7FD5    649 G$SUDPTRL$0$0 == 0x7fd5
                    7FD5    650 _SUDPTRL	=	0x7fd5
                    7FD6    651 G$USBCS$0$0 == 0x7fd6
                    7FD6    652 _USBCS	=	0x7fd6
                    7FD7    653 G$TOGCTL$0$0 == 0x7fd7
                    7FD7    654 _TOGCTL	=	0x7fd7
                    7FD8    655 G$USBFRAMEL$0$0 == 0x7fd8
                    7FD8    656 _USBFRAMEL	=	0x7fd8
                    7FD9    657 G$USBFRAMEH$0$0 == 0x7fd9
                    7FD9    658 _USBFRAMEH	=	0x7fd9
                    7FDB    659 G$FNADDR$0$0 == 0x7fdb
                    7FDB    660 _FNADDR	=	0x7fdb
                    7FDD    661 G$USBPAIR$0$0 == 0x7fdd
                    7FDD    662 _USBPAIR	=	0x7fdd
                    7FDE    663 G$IN07VAL$0$0 == 0x7fde
                    7FDE    664 _IN07VAL	=	0x7fde
                    7FDF    665 G$OUT07VAL$0$0 == 0x7fdf
                    7FDF    666 _OUT07VAL	=	0x7fdf
                    7F60    667 G$OUT8DATA$0$0 == 0x7f60
                    7F60    668 _OUT8DATA	=	0x7f60
                    7F61    669 G$OUT9DATA$0$0 == 0x7f61
                    7F61    670 _OUT9DATA	=	0x7f61
                    7F62    671 G$OUT10DATA$0$0 == 0x7f62
                    7F62    672 _OUT10DATA	=	0x7f62
                    7F63    673 G$OUT11DATA$0$0 == 0x7f63
                    7F63    674 _OUT11DATA	=	0x7f63
                    7F64    675 G$OUT12DATA$0$0 == 0x7f64
                    7F64    676 _OUT12DATA	=	0x7f64
                    7F65    677 G$OUT13DATA$0$0 == 0x7f65
                    7F65    678 _OUT13DATA	=	0x7f65
                    7F66    679 G$OUT14DATA$0$0 == 0x7f66
                    7F66    680 _OUT14DATA	=	0x7f66
                    7F67    681 G$OUT15DATA$0$0 == 0x7f67
                    7F67    682 _OUT15DATA	=	0x7f67
                    7F68    683 G$IN8DATA$0$0 == 0x7f68
                    7F68    684 _IN8DATA	=	0x7f68
                    7F69    685 G$IN9DATA$0$0 == 0x7f69
                    7F69    686 _IN9DATA	=	0x7f69
                    7F6A    687 G$IN10DATA$0$0 == 0x7f6a
                    7F6A    688 _IN10DATA	=	0x7f6a
                    7F6B    689 G$IN11DATA$0$0 == 0x7f6b
                    7F6B    690 _IN11DATA	=	0x7f6b
                    7F6C    691 G$IN12DATA$0$0 == 0x7f6c
                    7F6C    692 _IN12DATA	=	0x7f6c
                    7F6D    693 G$IN13DATA$0$0 == 0x7f6d
                    7F6D    694 _IN13DATA	=	0x7f6d
                    7F6E    695 G$IN14DATA$0$0 == 0x7f6e
                    7F6E    696 _IN14DATA	=	0x7f6e
                    7F6F    697 G$IN15DATA$0$0 == 0x7f6f
                    7F6F    698 _IN15DATA	=	0x7f6f
                    7F70    699 G$OUT8BCH$0$0 == 0x7f70
                    7F70    700 _OUT8BCH	=	0x7f70
                    7F71    701 G$OUT8BCL$0$0 == 0x7f71
                    7F71    702 _OUT8BCL	=	0x7f71
                    7F72    703 G$OUT9BCH$0$0 == 0x7f72
                    7F72    704 _OUT9BCH	=	0x7f72
                    7F73    705 G$OUT9BCL$0$0 == 0x7f73
                    7F73    706 _OUT9BCL	=	0x7f73
                    7F74    707 G$OUT10BCH$0$0 == 0x7f74
                    7F74    708 _OUT10BCH	=	0x7f74
                    7F75    709 G$OUT10BCL$0$0 == 0x7f75
                    7F75    710 _OUT10BCL	=	0x7f75
                    7F76    711 G$OUT11BCH$0$0 == 0x7f76
                    7F76    712 _OUT11BCH	=	0x7f76
                    7F77    713 G$OUT11BCL$0$0 == 0x7f77
                    7F77    714 _OUT11BCL	=	0x7f77
                    7F78    715 G$OUT12BCH$0$0 == 0x7f78
                    7F78    716 _OUT12BCH	=	0x7f78
                    7F79    717 G$OUT12BCL$0$0 == 0x7f79
                    7F79    718 _OUT12BCL	=	0x7f79
                    7F7A    719 G$OUT13BCH$0$0 == 0x7f7a
                    7F7A    720 _OUT13BCH	=	0x7f7a
                    7F7B    721 G$OUT13BCL$0$0 == 0x7f7b
                    7F7B    722 _OUT13BCL	=	0x7f7b
                    7F7C    723 G$OUT14BCH$0$0 == 0x7f7c
                    7F7C    724 _OUT14BCH	=	0x7f7c
                    7F7D    725 G$OUT14BCL$0$0 == 0x7f7d
                    7F7D    726 _OUT14BCL	=	0x7f7d
                    7F7E    727 G$OUT15BCH$0$0 == 0x7f7e
                    7F7E    728 _OUT15BCH	=	0x7f7e
                    7F7F    729 G$OUT15BCL$0$0 == 0x7f7f
                    7F7F    730 _OUT15BCL	=	0x7f7f
                    7FF0    731 G$OUT8ADDR$0$0 == 0x7ff0
                    7FF0    732 _OUT8ADDR	=	0x7ff0
                    7FF1    733 G$OUT9ADDR$0$0 == 0x7ff1
                    7FF1    734 _OUT9ADDR	=	0x7ff1
                    7FF2    735 G$OUT10ADDR$0$0 == 0x7ff2
                    7FF2    736 _OUT10ADDR	=	0x7ff2
                    7FF3    737 G$OUT11ADDR$0$0 == 0x7ff3
                    7FF3    738 _OUT11ADDR	=	0x7ff3
                    7FF4    739 G$OUT12ADDR$0$0 == 0x7ff4
                    7FF4    740 _OUT12ADDR	=	0x7ff4
                    7FF5    741 G$OUT13ADDR$0$0 == 0x7ff5
                    7FF5    742 _OUT13ADDR	=	0x7ff5
                    7FF6    743 G$OUT14ADDR$0$0 == 0x7ff6
                    7FF6    744 _OUT14ADDR	=	0x7ff6
                    7FF7    745 G$OUT15ADDR$0$0 == 0x7ff7
                    7FF7    746 _OUT15ADDR	=	0x7ff7
                    7FF8    747 G$IN8ADDR$0$0 == 0x7ff8
                    7FF8    748 _IN8ADDR	=	0x7ff8
                    7FF9    749 G$IN9ADDR$0$0 == 0x7ff9
                    7FF9    750 _IN9ADDR	=	0x7ff9
                    7FFA    751 G$IN10ADDR$0$0 == 0x7ffa
                    7FFA    752 _IN10ADDR	=	0x7ffa
                    7FFB    753 G$IN11ADDR$0$0 == 0x7ffb
                    7FFB    754 _IN11ADDR	=	0x7ffb
                    7FFC    755 G$IN12ADDR$0$0 == 0x7ffc
                    7FFC    756 _IN12ADDR	=	0x7ffc
                    7FFD    757 G$IN13ADDR$0$0 == 0x7ffd
                    7FFD    758 _IN13ADDR	=	0x7ffd
                    7FFE    759 G$IN14ADDR$0$0 == 0x7ffe
                    7FFE    760 _IN14ADDR	=	0x7ffe
                    7FFF    761 G$IN15ADDR$0$0 == 0x7fff
                    7FFF    762 _IN15ADDR	=	0x7fff
                    7FE0    763 G$INISOVAL$0$0 == 0x7fe0
                    7FE0    764 _INISOVAL	=	0x7fe0
                    7FE1    765 G$OUTISOVAL$0$0 == 0x7fe1
                    7FE1    766 _OUTISOVAL	=	0x7fe1
                    7FE2    767 G$FASTXFR$0$0 == 0x7fe2
                    7FE2    768 _FASTXFR	=	0x7fe2
                            769 ;--------------------------------------------------------
                            770 ; global & static initialisations
                            771 ;--------------------------------------------------------
                            772 	.area GSINIT  (CODE)
                            773 	.area GSFINAL (CODE)
                            774 	.area GSINIT  (CODE)
                    0000    775 	G$captureCD$0$0 ==.
                            776 ;	serial.c 234
   11C2 75 33 4E            777 	mov	_txbuf,#0x4E
   11C5 75 34 45            778 	mov	(_txbuf + 0x0001),#0x45
   11C8 75 35 58            779 	mov	(_txbuf + 0x0002),#0x58
   11CB 75 36 54            780 	mov	(_txbuf + 0x0003),#0x54
   11CE 75 37 00            781 	mov	(_txbuf + 0x0004),#0x00
                            782 ;--------------------------------------------------------
                            783 ; Home
                            784 ;--------------------------------------------------------
                            785 	.area HOME	 (CODE)
                            786 	.area CSEG    (CODE)
                            787 ;--------------------------------------------------------
                            788 ; code
                            789 ;--------------------------------------------------------
                            790 	.area CSEG    (CODE)
                            791 ;------------------------------------------------------------
                            792 ;Allocation info for local variables in function 'initSerial'
                            793 ;------------------------------------------------------------
                    0000    794 	G$initSerial$0$0 ==.
                            795 ;	serial.c 13
                            796 ;	-----------------------------------------
                            797 ;	 function initSerial
                            798 ;	-----------------------------------------
   0EB8                     799 _initSerial:
                    0002    800 	ar2 = 0x02
                    0003    801 	ar3 = 0x03
                    0004    802 	ar4 = 0x04
                    0005    803 	ar5 = 0x05
                    0006    804 	ar6 = 0x06
                    0007    805 	ar7 = 0x07
                    0000    806 	ar0 = 0x00
                    0001    807 	ar1 = 0x01
                            808 ;	serial.c 14
   0EB8 75 98 50            809 	mov	_SCON0,#0x50
                            810 ;	serial.c 15
   0EBB 90 7F 9E            811 	mov	dptr,#_OEC
   0EBE E0                  812 	movx	a,@dptr
                            813 ; Peephole 105   removed redundant mov
   0EBF FA                  814 	mov  r2,a
   0EC0 33                  815 	rlc	a
   0EC1 95 E0               816 	subb	a,acc
   0EC3 FB                  817 	mov	r3,a
   0EC4 43 02 02            818 	orl	ar2,#0x02
   0EC7 90 7F 9E            819 	mov	dptr,#_OEC
   0ECA EA                  820 	mov	a,r2
   0ECB F0                  821 	movx	@dptr,a
                            822 ;	serial.c 16
   0ECC 90 7F 9E            823 	mov	dptr,#_OEC
   0ECF E0                  824 	movx	a,@dptr
                            825 ; Peephole 105   removed redundant mov
   0ED0 FA                  826 	mov  r2,a
   0ED1 33                  827 	rlc	a
   0ED2 95 E0               828 	subb	a,acc
   0ED4 FB                  829 	mov	r3,a
   0ED5 53 02 FE            830 	anl	ar2,#0xFE
   0ED8 90 7F 9E            831 	mov	dptr,#_OEC
   0EDB EA                  832 	mov	a,r2
   0EDC F0                  833 	movx	@dptr,a
                            834 ;	serial.c 17
   0EDD C2 A1               835 	clr	_IOC_1
                            836 ;	serial.c 20
   0EDF 90 78 4C            837 	mov	dptr,#_PORTCCF2
                            838 ; Peephole 180   changed mov to clr
   0EE2 E4                  839 	clr  a
   0EE3 F0                  840 	movx	@dptr,a
                            841 ;	serial.c 21
   0EE4 90 7F 95            842 	mov	dptr,#_PORTCCFG
   0EE7 74 03               843 	mov	a,#0x03
   0EE9 F0                  844 	movx	@dptr,a
                            845 ;	serial.c 24
   0EEA 75 C8 34            846 	mov	_T2CON,#0x34
                            847 ;	serial.c 25
   0EED C2 CA               848 	clr	_TR2
                            849 ;	serial.c 28
   0EEF 75 CB FB            850 	mov	_RCAP2H,#0xFB
                            851 ;	serial.c 29
   0EF2 75 CA E6            852 	mov	_RCAP2L,#0xE6
                            853 ;	serial.c 33
   0EF5 75 4F 00            854 	mov	_rxloc,#0x00
                            855 ;	serial.c 34
   0EF8 12 0F 00            856 	lcall	_clearRX
                            857 ;	serial.c 36
   0EFB D2 CA               858 	setb	_TR2
                            859 ;	serial.c 37
   0EFD D2 AC               860 	setb	_ES0
   0EFF                     861 00101$:
                    0047    862 	C$serial.c$38$1$1 ==.
                    0047    863 	XG$initSerial$0$0 ==.
   0EFF 22                  864 	ret
                            865 ;------------------------------------------------------------
                            866 ;Allocation info for local variables in function 'clearRX'
                            867 ;------------------------------------------------------------
                            868 ;i                         Allocated to registers 
                    0048    869 	G$clearRX$0$0 ==.
                            870 ;	serial.c 40
                            871 ;	-----------------------------------------
                            872 ;	 function clearRX
                            873 ;	-----------------------------------------
   0F00                     874 _clearRX:
                            875 ;	serial.c 43
   0F00 7A 00               876 	mov	r2,#0x00
   0F02                     877 00101$:
   0F02 BA 10 00            878 	cjne	r2,#0x10,00109$
   0F05                     879 00109$:
                            880 ; Peephole 108   removed ljmp by inverse jump logic
   0F05 50 0A               881 	jnc  00105$
   0F07                     882 00110$:
                            883 ;	serial.c 44
   0F07 EA                  884 	mov	a,r2
   0F08 24 3F               885 	add	a,#_rxbuf
   0F0A A8 E0               886 	mov	r0,acc
   0F0C 76 00               887 	mov	@r0,#0x00
                            888 ;	serial.c 43
   0F0E 0A                  889 	inc	r2
                            890 ; Peephole 132   changed ljmp to sjmp
   0F0F 80 F1               891 	sjmp 00101$
   0F11                     892 00105$:
                    0059    893 	C$serial.c$45$1$1 ==.
                    0059    894 	XG$clearRX$0$0 ==.
   0F11 22                  895 	ret
                            896 ;------------------------------------------------------------
                            897 ;Allocation info for local variables in function 'nextMP3'
                            898 ;------------------------------------------------------------
                    005A    899 	G$nextMP3$0$0 ==.
                            900 ;	serial.c 47
                            901 ;	-----------------------------------------
                            902 ;	 function nextMP3
                            903 ;	-----------------------------------------
   0F12                     904 _nextMP3:
                            905 ;	serial.c 48
                            906 ; Peephole 182   used 16 bit load of dptr
   0F12 90 00 33            907 	mov  dptr,#(((0x00)<<8) + _txbuf)
   0F15 75 F0 00            908 	mov	b,#0x00
   0F18 75 50 9F            909 	mov	_strcpy_PARM_2,#__str_0
   0F1B 75 51 10            910 	mov	(_strcpy_PARM_2 + 1),#(__str_0 >> 8)
   0F1E 75 52 02            911 	mov	(_strcpy_PARM_2 + 2),#0x02
   0F21 12 10 BB            912 	lcall	_strcpy
                            913 ;	serial.c 49
   0F24 75 3E 01            914 	mov	_txloc,#0x01
                            915 ;	serial.c 50
   0F27 75 3D 04            916 	mov	_txlen,#0x04
                            917 ;	serial.c 51
   0F2A 85 33 99            918 	mov	_SBUF0,_txbuf
   0F2D                     919 00101$:
                    0075    920 	C$serial.c$52$1$1 ==.
                    0075    921 	XG$nextMP3$0$0 ==.
   0F2D 22                  922 	ret
                            923 ;------------------------------------------------------------
                            924 ;Allocation info for local variables in function 'previousMP3'
                            925 ;------------------------------------------------------------
                    0076    926 	G$previousMP3$0$0 ==.
                            927 ;	serial.c 54
                            928 ;	-----------------------------------------
                            929 ;	 function previousMP3
                            930 ;	-----------------------------------------
   0F2E                     931 _previousMP3:
                            932 ;	serial.c 55
                            933 ; Peephole 182   used 16 bit load of dptr
   0F2E 90 00 33            934 	mov  dptr,#(((0x00)<<8) + _txbuf)
   0F31 75 F0 00            935 	mov	b,#0x00
   0F34 75 50 A4            936 	mov	_strcpy_PARM_2,#__str_1
   0F37 75 51 10            937 	mov	(_strcpy_PARM_2 + 1),#(__str_1 >> 8)
   0F3A 75 52 02            938 	mov	(_strcpy_PARM_2 + 2),#0x02
   0F3D 12 10 BB            939 	lcall	_strcpy
                            940 ;	serial.c 56
   0F40 75 3E 01            941 	mov	_txloc,#0x01
                            942 ;	serial.c 57
   0F43 75 3D 08            943 	mov	_txlen,#0x08
                            944 ;	serial.c 58
   0F46 85 33 99            945 	mov	_SBUF0,_txbuf
   0F49                     946 00101$:
                    0091    947 	C$serial.c$59$1$1 ==.
                    0091    948 	XG$previousMP3$0$0 ==.
   0F49 22                  949 	ret
                            950 ;------------------------------------------------------------
                            951 ;Allocation info for local variables in function 'mixMP3'
                            952 ;------------------------------------------------------------
                    0092    953 	G$mixMP3$0$0 ==.
                            954 ;	serial.c 61
                            955 ;	-----------------------------------------
                            956 ;	 function mixMP3
                            957 ;	-----------------------------------------
   0F4A                     958 _mixMP3:
                            959 ;	serial.c 62
                            960 ; Peephole 182   used 16 bit load of dptr
   0F4A 90 00 33            961 	mov  dptr,#(((0x00)<<8) + _txbuf)
   0F4D 75 F0 00            962 	mov	b,#0x00
   0F50 75 50 AD            963 	mov	_strcpy_PARM_2,#__str_2
   0F53 75 51 10            964 	mov	(_strcpy_PARM_2 + 1),#(__str_2 >> 8)
   0F56 75 52 02            965 	mov	(_strcpy_PARM_2 + 2),#0x02
   0F59 12 10 BB            966 	lcall	_strcpy
                            967 ;	serial.c 63
   0F5C 75 3E 01            968 	mov	_txloc,#0x01
                            969 ;	serial.c 64
   0F5F 75 3D 03            970 	mov	_txlen,#0x03
                            971 ;	serial.c 65
   0F62 85 33 99            972 	mov	_SBUF0,_txbuf
   0F65                     973 00101$:
                    00AD    974 	C$serial.c$66$1$1 ==.
                    00AD    975 	XG$mixMP3$0$0 ==.
   0F65 22                  976 	ret
                            977 ;------------------------------------------------------------
                            978 ;Allocation info for local variables in function 'playMP3'
                            979 ;------------------------------------------------------------
                    00AE    980 	G$playMP3$0$0 ==.
                            981 ;	serial.c 68
                            982 ;	-----------------------------------------
                            983 ;	 function playMP3
                            984 ;	-----------------------------------------
   0F66                     985 _playMP3:
                            986 ;	serial.c 69
                            987 ; Peephole 182   used 16 bit load of dptr
   0F66 90 00 33            988 	mov  dptr,#(((0x00)<<8) + _txbuf)
   0F69 75 F0 00            989 	mov	b,#0x00
   0F6C 75 50 B1            990 	mov	_strcpy_PARM_2,#__str_3
   0F6F 75 51 10            991 	mov	(_strcpy_PARM_2 + 1),#(__str_3 >> 8)
   0F72 75 52 02            992 	mov	(_strcpy_PARM_2 + 2),#0x02
   0F75 12 10 BB            993 	lcall	_strcpy
                            994 ;	serial.c 70
   0F78 75 3E 01            995 	mov	_txloc,#0x01
                            996 ;	serial.c 71
   0F7B 75 3D 04            997 	mov	_txlen,#0x04
                            998 ;	serial.c 72
   0F7E 85 33 99            999 	mov	_SBUF0,_txbuf
   0F81                    1000 00101$:
                    00C9   1001 	C$serial.c$73$1$1 ==.
                    00C9   1002 	XG$playMP3$0$0 ==.
   0F81 22                 1003 	ret
                           1004 ;------------------------------------------------------------
                           1005 ;Allocation info for local variables in function 'serial0'
                           1006 ;------------------------------------------------------------
                           1007 ;tmp                       Allocated to registers r2 
                    00CA   1008 	G$serial0$0$0 ==.
                           1009 ;	serial.c 75
                           1010 ;	-----------------------------------------
                           1011 ;	 function serial0
                           1012 ;	-----------------------------------------
   0F82                    1013 _serial0:
   0F82 C0 E0              1014 	push	acc
   0F84 C0 F0              1015 	push	b
   0F86 C0 82              1016 	push	dpl
   0F88 C0 83              1017 	push	dph
   0F8A C0 02              1018 	push	ar2
   0F8C C0 00              1019 	push	ar0
   0F8E C0 D0              1020 	push	psw
   0F90 75 D0 00           1021 	mov	psw,#0x00
                           1022 ;	serial.c 76
                           1023 ; Peephole 111   removed ljmp by inverse jump logic
   0F93 30 99 13           1024 	jnb  _TI_0,00104$
   0F96                    1025 00115$:
                           1026 ;	serial.c 77
   0F96 C2 99              1027 	clr	_TI_0
                           1028 ;	serial.c 78
   0F98 C3                 1029 	clr	c
   0F99 E5 3E              1030 	mov	a,_txloc
   0F9B 95 3D              1031 	subb	a,_txlen
                           1032 ; Peephole 108   removed ljmp by inverse jump logic
   0F9D 50 0A              1033 	jnc  00104$
   0F9F                    1034 00116$:
                           1035 ;	serial.c 79
   0F9F AA 3E              1036 	mov	r2,_txloc
   0FA1 05 3E              1037 	inc	_txloc
   0FA3 EA                 1038 	mov	a,r2
   0FA4 24 33              1039 	add	a,#_txbuf
   0FA6 F8                 1040 	mov	r0,a
   0FA7 86 99              1041 	mov	_SBUF0,@r0
   0FA9                    1042 00104$:
                           1043 ;	serial.c 82
                           1044 ; Peephole 111   removed ljmp by inverse jump logic
   0FA9 30 98 1D           1045 	jnb  _RI_0,00109$
   0FAC                    1046 00117$:
                           1047 ;	serial.c 84
   0FAC AA 99              1048 	mov	r2,_SBUF0
                           1049 ;	serial.c 85
                           1050 ; Peephole 132   changed ljmp to sjmp
                           1051 ; Peephole 199   optimized misc jump sequence
   0FAE BA 00 03           1052 	cjne r2,#0x00,00106$
                           1053 ;00118$:
                           1054 ; Peephole 200   removed redundant sjmp
   0FB1                    1055 00119$:
                           1056 ;	serial.c 86
   0FB1 75 4F 00           1057 	mov	_rxloc,#0x00
   0FB4                    1058 00106$:
                           1059 ;	serial.c 87
   0FB4 E5 4F              1060 	mov	a,_rxloc
   0FB6 24 3F              1061 	add	a,#_rxbuf
   0FB8 A8 E0              1062 	mov	r0,acc
   0FBA A6 02              1063 	mov	@r0,ar2
                           1064 ;	serial.c 88
   0FBC 74 01              1065 	mov	a,#0x01
   0FBE 25 4F              1066 	add	a,_rxloc
   0FC0 75 F0 10           1067 	mov	b,#0x10
   0FC3 84                 1068 	div	ab
   0FC4 85 F0 4F           1069 	mov	_rxloc,b
                           1070 ;	serial.c 89
   0FC7 C2 98              1071 	clr	_RI_0
   0FC9                    1072 00109$:
   0FC9 D0 D0              1073 	pop	psw
   0FCB D0 00              1074 	pop	ar0
   0FCD D0 02              1075 	pop	ar2
   0FCF D0 83              1076 	pop	dph
   0FD1 D0 82              1077 	pop	dpl
   0FD3 D0 F0              1078 	pop	b
   0FD5 D0 E0              1079 	pop	acc
                    011F   1080 	C$serial.c$91$2$1 ==.
                    011F   1081 	XG$serial0$0$0 ==.
   0FD7 32                 1082 	reti
                           1083 ;------------------------------------------------------------
                           1084 ;Allocation info for local variables in function 'timeClocks'
                           1085 ;------------------------------------------------------------
                    0120   1086 	G$timeClocks$0$0 ==.
                           1087 ;	serial.c 93
                           1088 ;	-----------------------------------------
                           1089 ;	 function timeClocks
                           1090 ;	-----------------------------------------
   0FD8                    1091 _timeClocks:
                           1092 ;	serial.c 158
   0FD8 90 7F E5           1093 	      mov  dptr, #_AUTODATA
   0FDB 7A 40              1094 	      mov  r2, #64
   0FDD                    1095     00001$:
   0FDD A2 87              1096 	      mov  c,_IOA_7 ;; 2 cycles 1
   0FDF 33                 1097 	      rlc  a        ;; 1 cycle 3
   0FE0 00                 1098 	      nop           ;; 1 cycle 4
   0FE1 00                 1099 	      nop           ;; 1 cycle 5
   0FE2 00                 1100 	      nop           ;; 1 cycle 6
   0FE3 00                 1101 	      nop           ;; 1 cycle 7
   0FE4 00                 1102 	      nop           ;; 1 cycle 8
   0FE5 A2 87              1103 	      mov  c,_IOA_7 ;; 2 cycles 2
   0FE7 33                 1104 	      rlc  a        ;; 1 cycle
   0FE8 00                 1105 	      nop           ;; 1 cycle
   0FE9 00                 1106 	      nop           ;; 1 cycle
   0FEA 00                 1107 	      nop           ;; 1 cycle
   0FEB 00                 1108 	      nop           ;; 1 cycle
   0FEC 00                 1109 	      nop           ;; 1 cycle
   0FED A2 87              1110 	      mov  c,_IOA_7 ;; 2 cycles 3
   0FEF 33                 1111 	      rlc  a        ;; 1 cycle
   0FF0 00                 1112 	      nop           ;; 1 cycle
   0FF1 00                 1113 	      nop           ;; 1 cycle
   0FF2 00                 1114 	      nop           ;; 1 cycle
   0FF3 00                 1115 	      nop           ;; 1 cycle
   0FF4 00                 1116 	      nop           ;; 1 cycle
   0FF5 A2 87              1117 	      mov  c,_IOA_7 ;; 2 cycles 4
   0FF7 33                 1118 	      rlc  a        ;; 1 cycle
   0FF8 00                 1119 	      nop           ;; 1 cycle
   0FF9 00                 1120 	      nop           ;; 1 cycle
   0FFA 00                 1121 	      nop           ;; 1 cycle
   0FFB 00                 1122 	      nop           ;; 1 cycle
   0FFC 00                 1123 	      nop           ;; 1 cycle
   0FFD A2 87              1124 	      mov  c,_IOA_7 ;; 2 cycles 5
   0FFF 33                 1125 	      rlc  a        ;; 1 cycle
   1000 00                 1126 	      nop           ;; 1 cycle
   1001 00                 1127 	      nop           ;; 1 cycle
   1002 00                 1128 	      nop           ;; 1 cycle
   1003 00                 1129 	      nop           ;; 1 cycle
   1004 00                 1130 	      nop           ;; 1 cycle
   1005 A2 87              1131 	      mov  c,_IOA_7 ;; 2 cycles 6 
   1007 33                 1132 	      rlc  a        ;; 1 cycle
   1008 00                 1133 	      nop           ;; 1 cycle
   1009 00                 1134 	      nop           ;; 1 cycle
   100A 00                 1135 	      nop           ;; 1 cycle
   100B 00                 1136 	      nop           ;; 1 cycle
   100C 00                 1137 	      nop           ;; 1 cycle
   100D A2 87              1138 	      mov  c,_IOA_7 ;; 2 cycles 7
   100F 33                 1139 	      rlc  a        ;; 1 cycle
   1010 00                 1140 	      nop           ;; 1 cycle
   1011 00                 1141 	      nop           ;; 1 cycle
   1012 00                 1142 	      nop           ;; 1 cycle
   1013 00                 1143 	      nop           ;; 1 cycle
   1014 00                 1144 	      nop           ;; 1 cycle
   1015 A2 87              1145 	      mov  c,_IOA_7 ;; 2 cycles 8
   1017 33                 1146 	      rlc  a        ;; 1 cycle
   1018 F0                 1147 	      movx @dptr,a  ;; 2 cycles
   1019 DA C2              1148 	      djnz r2,00001$;; 3 cycles
   101B                    1149 00101$:
                    0163   1150 	C$serial.c$159$1$1 ==.
                    0163   1151 	XG$timeClocks$0$0 ==.
   101B 22                 1152 	ret
                           1153 ;------------------------------------------------------------
                           1154 ;Allocation info for local variables in function 'captureHead'
                           1155 ;------------------------------------------------------------
                    0164   1156 	G$captureHead$0$0 ==.
                           1157 ;	serial.c 161
                           1158 ;	-----------------------------------------
                           1159 ;	 function captureHead
                           1160 ;	-----------------------------------------
   101C                    1161 _captureHead:
                           1162 ;	serial.c 186
                           1163 	      ;; setup autoptr to point at isochronous (free) memory area
   101C 90 7F E4           1164 	      mov     dptr,#_AUTOPTRL
   101F E4                 1165 	      clr     a
   1020 F0                 1166 	      movx    @dptr,a
   1021 90 7F E3           1167 	      mov     dptr,#_AUTOPTRH
   1024 74 20              1168 	      mov     a,#0x20
   1026 90 7F E5           1169 	      mov     dptr,#_AUTODATA
   1029 7C 08              1170 	      mov     r4,#8
   102B 7A 00              1171 	      mov     r2,#0
   102D 7B 08              1172 	      mov     r3,#8
                           1173 	      ;; wait for first HIGH
   102F                    1174     00009$:
   102F 30 85 FD           1175 	      jnb     _IOA_5,00009$
   1032                    1176     00001$:
   1032 A2 85              1177 	      mov     c,_IOA_5
   1034 33                 1178 	      rlc     a
   1035 DB FB              1179 	      djnz    r3,00001$
   1037 F0                 1180 	      movx    @dptr,a
   1038 7B 08              1181 	      mov     r3,#8
   103A DA F6              1182 	      djnz    r2,00001$
   103C DC F4              1183 	      djnz    r4,00001$
   103E                    1184 00101$:
                    0186   1185 	C$serial.c$187$1$1 ==.
                    0186   1186 	XG$captureHead$0$0 ==.
   103E 22                 1187 	ret
                           1188 ;------------------------------------------------------------
                           1189 ;Allocation info for local variables in function 'captureCD'
                           1190 ;------------------------------------------------------------
                    0187   1191 	G$captureCD$0$0 ==.
                           1192 ;	serial.c 189
                           1193 ;	-----------------------------------------
                           1194 ;	 function captureCD
                           1195 ;	-----------------------------------------
   103F                    1196 _captureCD:
                           1197 ;	serial.c 190
   103F C2 A9              1198 	clr	_ET0
                           1199 ;	serial.c 191
   1041 90 7F 9C           1200 	mov	dptr,#_OEA
   1044 74 1F              1201 	mov	a,#0x1F
   1046 F0                 1202 	movx	@dptr,a
   1047                    1203 00105$:
                           1204 ;	serial.c 193
   1047 90 7F E4           1205 	mov	dptr,#_AUTOPTRL
                           1206 ; Peephole 180   changed mov to clr
   104A E4                 1207 	clr  a
   104B F0                 1208 	movx	@dptr,a
                           1209 ;	serial.c 194
   104C 90 7F E3           1210 	mov	dptr,#_AUTOPTRH
   104F 74 7D              1211 	mov	a,#0x7D
   1051 F0                 1212 	movx	@dptr,a
                           1213 ;	serial.c 195
   1052                    1214 00101$:
   1052 90 7F BC           1215 	mov	dptr,#_IN4CS
   1055 E0                 1216 	movx	a,@dptr
                           1217 ; Peephole 166   removed redundant mov
   1056 FA                 1218 	mov  r2,a
   1057 8A 03              1219 	mov  ar3,r2 
   1059 33                 1220 	rlc	a
   105A 95 E0              1221 	subb	a,acc
   105C FC                 1222 	mov	r4,a
   105D 74 02              1223 	mov	a,#0x02
   105F 5B                 1224 	anl	a,r3
   1060 FD                 1225 	mov	r5,a
   1061 7E 00              1226 	mov	r6,#0x00
   1063 ED                 1227 	mov	a,r5
   1064 4E                 1228 	orl	a,r6
                           1229 ; Peephole 109   removed ljmp by inverse jump logic
   1065 70 EB              1230 	jnz  00101$
   1067                    1231 00112$:
                           1232 ;	serial.c 230
   1067 90 7F E5           1233 	      mov     dptr,#_AUTODATA
                           1234 	      ;; wait for SCLK low at least 256 pulses
   106A                    1235     00005$:
   106A 7A 00              1236 	      mov     r2, #0
   106C                    1237     00006$:
   106C A2 85              1238 	      mov     c,_IOA_5            ;; copy head unit buttons to cd changer
   106E 92 84              1239 	      mov     _IOA_4,c
   1070 20 87 F7           1240 	      jb      _IOA_7,00005$
   1073 DA F7              1241 	      djnz    r2,00006$
                           1242 	      ;; now read in 64 bytes of data from the cd changer
   1075 7D 40              1243 	      mov     r5, #64
   1077                    1244     00000$:
   1077 7A 08              1245 	      mov     r2, #8
   1079                    1246     00007$:
   1079 A2 85              1247 	      mov     c,_IOA_5            ;; copy head unit buttons to cd changer
   107B 92 84              1248 	      mov     _IOA_4,c
   107D 30 87 F9           1249 	      jnb     _IOA_7,00007$       ;; wait for SCLK HIGH
   1080 D2 80              1250 	      setb    _IOA_0
   1082                    1251     00002$:
   1082 A2 85              1252 	      mov     c,_IOA_5            ;; copy head unit buttons to cd changer
   1084 92 84              1253 	      mov     _IOA_4,c
   1086 20 87 F9           1254 	      jb      _IOA_7,00002$       ;; wait for SCLK LOW, then sample SRX
   1089 A2 86              1255 	      mov     c,_IOA_6
   108B 92 81              1256 	      mov     _IOA_1,c
   108D C2 80              1257 	      clr     _IOA_0
   108F 33                 1258 	      rlc     a
   1090 DA E7              1259 	      djnz    r2,00007$
   1092                    1260     00009$:
   1092 F0                 1261 	      movx    @dptr,a	
   1093 DD E2              1262 	      djnz    r5,00000$
                           1263 ;	serial.c 231
   1095 90 7F BD           1264 	mov	dptr,#_IN4BC
   1098 74 40              1265 	mov	a,#0x40
   109A F0                 1266 	movx	@dptr,a
   109B 02 10 47           1267 	ljmp	00105$
   109E                    1268 00107$:
                    01E6   1269 	C$serial.c$233$2$2 ==.
                    01E6   1270 	XG$captureCD$0$0 ==.
   109E 22                 1271 	ret
                           1272 	.area CSEG    (CODE)
                    01E7   1273 Fserial$_str_0$0$0 == .
   109F                    1274 __str_0:
   109F 4E 45 58 54        1275 	.ascii "NEXT"
   10A3 00                 1276 	.db 0x00
                    01EC   1277 Fserial$_str_1$0$0 == .
   10A4                    1278 __str_1:
   10A4 50 52 45 56 49 4F  1279 	.ascii "PREVIOUS"
        55 53
   10AC 00                 1280 	.db 0x00
                    01F5   1281 Fserial$_str_2$0$0 == .
   10AD                    1282 __str_2:
   10AD 4D 49 58           1283 	.ascii "MIX"
   10B0 00                 1284 	.db 0x00
                    01F9   1285 Fserial$_str_3$0$0 == .
   10B1                    1286 __str_3:
   10B1 50 4C 41 59        1287 	.ascii "PLAY"
   10B5 00                 1288 	.db 0x00
                    01FE   1289 Fserial$_str_4$0$0 == .
   10B6                    1290 __str_4:
   10B6 4E 45 58 54        1291 	.ascii "NEXT"
   10BA 00                 1292 	.db 0x00
