// EZ-USB FX Registers
// Copyright (c) 2000, Ed Schlunder <zilym@yahoo.com>

#ifndef EZUSBFX_H
#define EZUSBFX_H

void msecWait48MHz(void);
void msecWait24MHz(void);
void msecWait(int msec);

short i2cWrite(unsigned short val); // assumes I2CS START bit set beforehand
// first byte read from slave will be garbage and should be discarded.
// before reading second to last byte from slave, set LASTRD bit of I2CS.
// last byte of data has to be read directly from I2DAT (don't use i2cRead())
// immediately after setting the STOP bit of I2CS.
int i2cRead(void);

// you may need to change these definitions to match how you've connected
// your LED latch to the EZ-USB chip...
#define LEDEN IOA_7
#define LEDS  IOD
#define LEDOE OED

void setLEDs(unsigned short val);
void blinkLED(unsigned short l);
void setLED(unsigned short l);
void clearLED(unsigned short l);

typedef unsigned char byte;

#define EPBUSY (1<<1)

/*
 * Special Function Registers (SFRs) ----------------------------------------
 */

sfr at 0x81 SP;     // stack pointer
sfr at 0x82 DPL;    // first data pointer low
sfr at 0x83 DPH;    // first data pointer high
sfr at 0x82 DPL0;
sfr at 0x83 DPH0;
sfr at 0x84 DPL1;   // second data pointer low 
sfr at 0x85 DPH1;   // second data pointer high
sfr at 0x86 DPS;    // dptr select 0=first data pointer 1=second data pointer


sfr at 0x8E CKCON;  // clock control SFR
// CKCON.7 - reserved
// CKCON.6 - reserved
// CKCON.5 - T2M - Timer 2 Clock Select (no effect when baud rate generator)
//           T2M = 0 timer 2 uses CLKOUT/12
//           T2M = 1 timer 2 uses CLKOUT/4
// CKCON.4 - T1M - Timer 1 Clock Select
//           T1M = 0 timer 1 uses CLKOUT/12
//           T1M = 1 timer 1 uses CLKOUT/4
// CKCON.3 - T0M - Timer 0 Clock Select
//           T0M = 0 timer 0 uses CLKOUT/12
//           T0M = 1 timer 0 uses CLKOUT/4
// CKCON.2-0 - Number of cycles to wait for external MOVX intructions.
#define T2M  1<<5
#define T1M  1<<4
#define T0M  1<<3

/* Interrupt Control */
sfr at 0xA2 INT4CLR;
sfr at 0xF8 EIP;    // extended interrupt priorities
sbit at 0xFC PX6;
sbit at 0xFB PX5;
sbit at 0xFA PX4;
sbit at 0xF9 PI2C;
sbit at 0xF8 PUSB;

/*
  SMOD0 = 1 serial port 0 baud rate is doubled
  GF1/GF0 - general purpose flags, use for whatever you want
  STOP - reserved (?)
  IDLE - puts 8051 into idle mode
*/
sfr at 0x87 PCON;
#define IDLE  1<<0
#define STOP  1<<1
#define GF0   1<<2
#define GF1   1<<3
#define SMOD0 1<<7

/*
  TR0/TR1 - timer enable bits 
  TF0/TF1 - timer overflow flags
  IE0/IE1 - interrupt edge detect
  IT0/IT0 - interrupt type select (1 - falling edge, 0 - level)
*/
sfr  at 0x88 TCON;
sbit at 0x8F TF1;
sbit at 0x8E TR1;
sbit at 0x8D TF0;
sbit at 0x8C TR0;
sbit at 0x8B IE1;
sbit at 0x8A IT1;
sbit at 0x89 IE0;
sbit at 0x88 IT0;

/* IOA */
sfr  at 0x80 IOA;
sbit at 0x80 IOA_0;
sbit at 0x81 IOA_1;
sbit at 0x82 IOA_2;
sbit at 0x83 IOA_3;
sbit at 0x84 IOA_4;
sbit at 0x85 IOA_5;
sbit at 0x86 IOA_6;
sbit at 0x87 IOA_7;

/* IOB */
sfr  at 0x90 IOB;
sbit at 0x90 IOB_0;
sbit at 0x91 IOB_1;
sbit at 0x92 IOB_2;
sbit at 0x93 IOB_3;
sbit at 0x94 IOB_4;
sbit at 0x95 IOB_5;
sbit at 0x96 IOB_6;
sbit at 0x97 IOB_7;

/* IOC */
sfr  at 0xA0 IOC;
sbit at 0xA0 IOC_0;
sbit at 0xA1 IOC_1;
sbit at 0xA2 IOC_2;
sbit at 0xA3 IOC_3;
sbit at 0xA4 IOC_4;
sbit at 0xA5 IOC_5;
sbit at 0xA6 IOC_6;
sbit at 0xA7 IOC_7;

/* IOD */
sfr  at 0xB0 IOD;
sbit at 0xB0 IOD_0;
sbit at 0xB1 IOD_1;
sbit at 0xB2 IOD_2;
sbit at 0xB3 IOD_3;
sbit at 0xB4 IOD_4;
sbit at 0xB5 IOD_5;
sbit at 0xB6 IOD_6;
sbit at 0xB7 IOD_7;

/* IOE - port e is not bit addressable */
sfr  at 0xB1 IOE;

/*
 * XDATA Registers ----------------------------------------------------------
 */

/* FIFO A-IN */
xdata at 0x7800 short AINDATA;
xdata at 0x7801 short AINBC;
xdata at 0x7802 short AINPF;
xdata at 0x7803 short AINPFPIN;

/* FIFO B-IN */
xdata at 0x7805 short BINDATA;
xdata at 0x7806 short BINBC;
xdata at 0x7807 short BINPF;
xdata at 0x7808 short BINPFPIN;

/* FIFO A/B-IN Control */
xdata at 0x780A short ABINTF;
xdata at 0x780B short ABINIE;
xdata at 0x780C short ABINIRQ;

/* FIFO A-OUT */
xdata at 0x780E short AOUTDATA;
xdata at 0x780F short AOUTBC;
xdata at 0x7810 short AOUTPF;
xdata at 0x7811 short AOUTPFPIN;

/* FIFO B-OUT */
xdata at 0x7813 short BOUTDATA;
xdata at 0x7814 short BOUTBC;
xdata at 0x7815 short BOUTPF;
xdata at 0x7816 short BOUTPFPIN;

/* FIFO A/B OUT Control */
xdata at 0x7818 short ABOUTTF;
xdata at 0x7819 short ABOUTIE;
xdata at 0x781A short ABOUTIRQ;

/* FIFO A/B Global Control */
xdata at 0x781C short ABSETUP;
xdata at 0x781D short ABPOLAR;
xdata at 0x781E short ABFLUSH;

/* GPIF */
xdata at 0x7824 short WFSELECT;
xdata at 0x7825 short IDLE_CS;
xdata at 0x7826 short IDLE_CTLOUT;
xdata at 0x7827 short CTLOUTCFG;
xdata at 0x782A short GPIFADRL;
xdata at 0x7900 short WFDESC[128];
xdata at 0x7900 short WFDESC0[32];
xdata at 0x7920 short WFDESC1[32];
xdata at 0x7940 short WFDESC2[32];
xdata at 0x7960 short WFDESC3[32];
#define CTL0 (1<<0)
#define CTL1 (1<<1)
#define CTL2 (1<<2)
#define CTL3 (1<<3)
#define CTL4 (1<<4)
#define CTL5 (1<<5)
#define IDLEDRV (1<<0)

xdata at 0x782C short AINTC;
xdata at 0x782D short AOUTTC;
xdata at 0x782E short ATRIG;
xdata at 0x7830 short BINTC;
xdata at 0x7831 short BOUTTC;
xdata at 0x7832 short BTRIG;

xdata at 0x7834 short SGLDATH;
xdata at 0x7835 short SGLDATLTRIG;
xdata at 0x7836 short SGLDATLNTRIG;
xdata at 0x7838 short READY;
xdata at 0x7839 short ABORT;
xdata at 0x783B short GENIE;
xdata at 0x783C short GENIRQ;

xdata at 0x784A short IFCONFIG;
/*
  7- 52ONE
  3- GSTATE
  2- BUS16
  1/0- IF[0..1]
*/


/* autopointer */
xdata at 0x7FE3 short AUTOPTRH;
xdata at 0x7FE4 short AUTOPTRL;
xdata at 0x7FE5 short AUTODATA;

/* IO Ports */
xdata at 0x7F96 short OUTA;
xdata at 0x7F97 short OUTB;
xdata at 0x7F98 short OUTC;
xdata at 0x7841 short OUTD;
xdata at 0x7845 short OUTE;
xdata at 0x7F99 short PINSA;
xdata at 0x7F9A short PINSB;
xdata at 0x7F9B short PINSC;
xdata at 0x7842 short PINSD;
xdata at 0x7846 short PINSE;
xdata at 0x7F9C short OEA;
xdata at 0x7F9D short OEB;
xdata at 0x7F9E short OEC;
xdata at 0x7843 short OED;
xdata at 0x7847 short OEE;

/* IO Port Control */
xdata at 0x7F93 short PORTACFG;
xdata at 0x7F94 short PORTBCFG;
xdata at 0x7F95 short PORTCCFG;
xdata at 0x784C	short PORTCCF2;
xdata at 0x7849 short PORTSETUP;

xdata at 0x785D short INT4IVEC;
xdata at 0x785E short INT4SETUP;
#define INT4SFC       1<<2
#define INT4_INTERNAL 1<<1
#define AV4EN         1<<0

/* DMA Control */
xdata at 0x784F short DMASRCH;
xdata at 0x7850 short DMASRCL;
xdata at 0x7851 short DMADESTH;
xdata at 0x7852 short DMADESTL;
xdata at 0x7857 short DMABURST;
xdata at 0x7854 short DMALEN;
xdata at 0x7855 short DMAGO;

/* I2C Registers */
xdata at 0x7FA6 short I2DAT;
xdata at 0x7FA5 short I2CS;
#define I2DONE	      1<<0
#define I2ACK	      1<<1
#define I2BERR	      1<<2
#define I2ID0	      1<<3
#define I2ID1	      1<<4
#define I2LASTRD      1<<5
#define I2STOP	      1<<6
#define I2START	      1<<7

xdata at 0x7FA7 short I2CMODE;
#define I2STOPIE      1<<1
#define I2400KHZ      1<<0

/* CPU Control/Status */
xdata at 0x7F92 short CPUCS;
#define RESET8051     1<<0
#define CLKOE         1<<1
#define CLKINV        1<<2
#define CLK2448       1<<3
// bits 4-7 silicon revision

/* Isochronous Control/Status */
xdata at 0x7FA0 short ISOERR;
xdata at 0x7FA1 short ISOCTL;
#define ISODISAB 1
#define PPSTAT (1<<3)
xdata at 0x7FA2 short ZBCOUNT; // zero byte count bits

/*
 * ----------------------------------------------------------------------
 */

// the rest of this file is left over from Thomas Sailer's include file
// that I haven't sorted through yet...
sfr at 0x89 TMOD    ;

// TMOD = TIMER0_16 | TIMER1_STOP

// timer0 mode:
#define TIMER0_13			0	// 13 bit 8048 compatible
#define TIMER0_16			1	// 16 bit timer/counter
#define TIMER0_8AUTO_RELOAD_0		2	// 8 bit auto reload timer/counter
#define TIMER0__SPLIT			3	// tl0 and th0 two 8 bit timer/counters

#define GATE_0				1<<3	// timerx runs when intx is high
#define COUNTER_0			1<<2	// counter not timer

// timer1 mode:
#define TIMER1_13			0<<4	// 13 bit 8048 compatible
#define TIMER1_16			1<<4	// 16 bit timer/counter
#define TIMER1_8AUTO_RELOAD		2<<4	// 8 bit auto reload timer/counter
#define TIMER1_STOP			3<<4

#define GATE_1				1<<7	// timerx runs when intx is high
#define COUNTER_1			1<<6	// counter not timer

sfr at 0x8A TL0     ;
sfr at 0x8B TL1     ;
sfr at 0x8C TH0     ;
sfr at 0x8D TH1     ;



sfr at 0x8F SPC_FNC ;

sfr at 0x91 EXIF    ;
#define USBINT 1<<4
#define I2CINT 1<<5
#define IE4 1<<6
#define IE5 1<<7

sfr at 0x92 MPAGE   ;
sfr at 0x98 SCON0   ;
sfr at 0x99 SBUF0   ;

sfr at 0xA8 IE      ; // interrupt enable

/* 

can use sbit (see below)

// IE = EA | ET0;
#define EA	1<<7	// enable all
// unimp	1<<6
#define ET2	1<<5	// timer 2
#define ES	1<<4	// serial port 0
#define ET1	1<<3	// timer 2
#define EX1	1<<2	// external int 1
#define ET0	1<<1	// timer 0
#define EX0	1<<0	// external int 0

*/

sfr at 0xB8 IP      ; // interrupt priority
sfr at 0xC0 SCON1   ;
sfr at 0xC1 SBUF1   ;
sfr at 0xC8 T2CON   ;
sfr at 0xCA RCAP2L  ;
sfr at 0xCB RCAP2H  ;
sfr at 0xCC TL2     ;
sfr at 0xCD TH2     ;
sfr at 0xD0 PSW     ;
sfr at 0xD8 EICON   ;
#define IE6 1<<3
sfr at 0xE0 ACC     ;
sfr at 0xE8 EIE     ;
sfr at 0xF0 B       ;


/*  BIT Register  */

/* TMOD bits */
#define GATE1   (1<<7)
#define C_T1    (1<<6)
#define M1_1    (1<<5)
#define M0_1    (1<<4)
#define GATE0   (1<<3)
#define C_T0    (1<<2)
#define M1_0    (1<<1)
#define M0_0    (1<<0)

/*  SCON0  */
sbit at 0x9F SM0_0 ;
sbit at 0x9E SM1_0 ;
sbit at 0x9D SM2_0 ;
sbit at 0x9C REN_0 ;
sbit at 0x9B TB8_0 ;
sbit at 0x9A RB8_0 ;
sbit at 0x99 TI_0  ;
sbit at 0x98 RI_0  ;

/*  IE   */
sbit at 0xAF EA    ;
sbit at 0xAE ES1   ;
sbit at 0xAD ET2   ;
sbit at 0xAC ES0   ;
sbit at 0xAB ET1   ;
sbit at 0xAA EX1   ;
sbit at 0xA9 ET0   ;
sbit at 0xA8 EX0   ;

/*  IP   */ 
sbit at 0xBE PS1;
sbit at 0xBD PT2;
sbit at 0xBC PS0;
sbit at 0xBB PT1;
sbit at 0xBA PX1;
sbit at 0xB9 PT0;
sbit at 0xB8 PX0;

/*  SCON1  */
sbit at 0xC7 SM0_1;
sbit at 0xC6 SM1_1;
sbit at 0xC5 SM2_1;
sbit at 0xC4 REN_1;
sbit at 0xC3 TB8_1;
sbit at 0xC2 RB8_1;
sbit at 0xC1 TI_1;
sbit at 0xC0 RI_1;

/*  T2CON  */
sbit at 0xCF TF2;
sbit at 0xCE EXF2;
sbit at 0xCD RCLK;
sbit at 0xCC TCLK;
sbit at 0xCB EXEN2;
sbit at 0xCA TR2;
sbit at 0xC9 CT2;
sbit at 0xC8 CPRL2;

/*  PSW   */
sbit at 0xD7 CY;
sbit at 0xD6 AC;
sbit at 0xD5 F0;
sbit at 0xD4 RS1;
sbit at 0xD3 RS0;
sbit at 0xD2 OV;
sbit at 0xD0 P;

/*  EICON  */
sbit at 0xDF SMOD1;
sbit at 0xDD ERESI;
sbit at 0xDC RESI;
sbit at 0xDB INT6;

/*  EIE  */
sbit at 0xEC EWDI;
sbit at 0xEB EX5;
sbit at 0xEA EX4;
sbit at 0xE9 EI2C;
sbit at 0xE8 EUSB;


/* XDATA registers */

/* control/interrupt/bulk endpoints */
xdata at 0x7F00 short IN0BUF[64];
xdata at 0x7EC0 short OUT0BUF[64];
xdata at 0x7E80 short IN1BUF[64];
xdata at 0x7E40 short OUT1BUF[64];
xdata at 0x7E00 short IN2BUF[64];
xdata at 0x7DC0 short OUT2BUF[64];
xdata at 0x7D80 short IN3BUF[64];
xdata at 0x7D40 short OUT3BUF[64];
xdata at 0x7D00 short IN4BUF[64];
xdata at 0x7CC0 short OUT4BUF[64];
xdata at 0x7C80 short IN5BUF[64];
xdata at 0x7C40 short OUT5BUF[64];
xdata at 0x7C00 short IN6BUF[64];
xdata at 0x7BC0 short OUT6BUF[64];
xdata at 0x7B80 short IN7BUF[64];
xdata at 0x7B40 short OUT7BUF[64];
xdata at 0x7FE8 short SETUPBUF[8];
xdata at 0x7FE8 short SETUPDAT[8];

xdata at 0x7FB4 short EP0CS;
xdata at 0x7FB5 short IN0BC;
xdata at 0x7FB6 short IN1CS;
xdata at 0x7FB7 short IN1BC;
xdata at 0x7FB8 short IN2CS;
xdata at 0x7FB9 short IN2BC;
xdata at 0x7FBA short IN3CS;
xdata at 0x7FBB short IN3BC;
xdata at 0x7FBC short IN4CS;
xdata at 0x7FBD short IN4BC;
xdata at 0x7FBE short IN5CS;
xdata at 0x7FBF short IN5BC;
xdata at 0x7FC0 short IN6CS;
xdata at 0x7FC1 short IN6BC;
xdata at 0x7FC2 short IN7CS;
xdata at 0x7FC3 short IN7BC;
xdata at 0x7FC5 short OUT0BC;
xdata at 0x7FC6 short OUT1CS;
xdata at 0x7FC7 short OUT1BC;
xdata at 0x7FC8 short OUT2CS;
xdata at 0x7FC9 short OUT2BC;
xdata at 0x7FCA short OUT3CS;
xdata at 0x7FCB short OUT3BC;
xdata at 0x7FCC short OUT4CS;
xdata at 0x7FCD short OUT4BC;
xdata at 0x7FCE short OUT5CS;
xdata at 0x7FCF short OUT5BC;
xdata at 0x7FD0 short OUT6CS;
xdata at 0x7FD1 short OUT6BC;
xdata at 0x7FD2 short OUT7CS;
xdata at 0x7FD3 short OUT7BC;

xdata at 0x7FA8 short IVEC;
xdata at 0x7FA9 short IN07IRQ;
xdata at 0x7FAA short OUT07IRQ;

xdata at 0x7FAB short USBIRQ;
#define URESIR		1<<4
#define SUSPIR		1<<3
#define SUTOKIR		1<<2
#define SOFIR		1<<1
#define	SUDAVIR		1<<0

xdata at 0x7FAC short IN07IEN;
xdata at 0x7FAD short OUT07IEN;

xdata at 0x7FAE short USBIEN;
#define URESIEN		1<<4
#define SUSPIEN		1<<3
#define SUTOKIEN	1<<2
#define SOFIEN		1<<1
#define	SUDAVIEN	1<<0

xdata at 0x7FAF short USBBAV;
xdata at 0x7FB2 short BPADDRH;
xdata at 0x7FB3 short BPADDRL;

xdata at 0x7FD4 short SUDPTRH;
xdata at 0x7FD5 short SUDPTRL;
xdata at 0x7FD6 short USBCS;
xdata at 0x7FD7 short TOGCTL;
xdata at 0x7FD8 short USBFRAMEL;
xdata at 0x7FD9 short USBFRAMEH;
xdata at 0x7FDB short FNADDR;
xdata at 0x7FDD short USBPAIR;
xdata at 0x7FDE short IN07VAL;
xdata at 0x7FDF short OUT07VAL;

/* isochronous endpoints. only available if ISODISAB=0 */

xdata at 0x7F60 short OUT8DATA;
xdata at 0x7F61 short OUT9DATA;
xdata at 0x7F62 short OUT10DATA;
xdata at 0x7F63 short OUT11DATA;
xdata at 0x7F64 short OUT12DATA;
xdata at 0x7F65 short OUT13DATA;
xdata at 0x7F66 short OUT14DATA;
xdata at 0x7F67 short OUT15DATA;

xdata at 0x7F68 short IN8DATA;
xdata at 0x7F69 short IN9DATA;
xdata at 0x7F6A short IN10DATA;
xdata at 0x7F6B short IN11DATA;
xdata at 0x7F6C short IN12DATA;
xdata at 0x7F6D short IN13DATA;
xdata at 0x7F6E short IN14DATA;
xdata at 0x7F6F short IN15DATA;

xdata at 0x7F70 short OUT8BCH;
xdata at 0x7F71 short OUT8BCL;
xdata at 0x7F72 short OUT9BCH;
xdata at 0x7F73 short OUT9BCL;
xdata at 0x7F74 short OUT10BCH;
xdata at 0x7F75 short OUT10BCL;
xdata at 0x7F76 short OUT11BCH;
xdata at 0x7F77 short OUT11BCL;
xdata at 0x7F78 short OUT12BCH;
xdata at 0x7F79 short OUT12BCL;
xdata at 0x7F7A short OUT13BCH;
xdata at 0x7F7B short OUT13BCL;
xdata at 0x7F7C short OUT14BCH;
xdata at 0x7F7D short OUT14BCL;
xdata at 0x7F7E short OUT15BCH;
xdata at 0x7F7F short OUT15BCL;

xdata at 0x7FF0 short OUT8ADDR;
xdata at 0x7FF1 short OUT9ADDR;
xdata at 0x7FF2 short OUT10ADDR;
xdata at 0x7FF3 short OUT11ADDR;
xdata at 0x7FF4 short OUT12ADDR;
xdata at 0x7FF5 short OUT13ADDR;
xdata at 0x7FF6 short OUT14ADDR;
xdata at 0x7FF7 short OUT15ADDR;
xdata at 0x7FF8 short IN8ADDR;
xdata at 0x7FF9 short IN9ADDR;
xdata at 0x7FFA short IN10ADDR;
xdata at 0x7FFB short IN11ADDR;
xdata at 0x7FFC short IN12ADDR;
xdata at 0x7FFD short IN13ADDR;
xdata at 0x7FFE short IN14ADDR;
xdata at 0x7FFF short IN15ADDR;

xdata at 0x7FE0 short INISOVAL;
xdata at 0x7FE1 short OUTISOVAL;
xdata at 0x7FE2 short FASTXFR;
#endif
