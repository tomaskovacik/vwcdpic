// USB Control
// Copyright (c) 2001, Edward Schlunder <zilym@yahoo.com>

void initUSB(void);
void intUSB(void) interrupt 8;
void ep2outUSB(void);

// send a string back to the host through EP2IN
short prints(char _generic *s);
short printn(unsigned int val);
short printDone(void);

#define STATE_IDLE   0
#define STATE_CAP    1
#define STATE_CDPASS 3
#define STATESAVE    10
#define STATE_HEAD   2
#define STATE_SIMPLE 5
