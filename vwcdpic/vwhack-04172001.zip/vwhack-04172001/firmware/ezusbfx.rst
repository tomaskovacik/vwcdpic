                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : FreeWare ANSI-C Compiler
                              3 ; Version 2.2.2 Tue Apr 17 02:00:26 2001
                              4 
                              5 ;--------------------------------------------------------
                              6 	.module ezusbfx
                              7 	
                              8 ;--------------------------------------------------------
                              9 ; Public variables in this module
                             10 ;--------------------------------------------------------
                             11 	.globl _CPUCS
                             12 	.globl _I2CS
                             13 	.globl _I2DAT
                             14 	.globl _msecWait48MHz
                             15 	.globl _msecWait24MHz
                             16 	.globl _msecWait
                             17 	.globl _i2cWrite
                             18 	.globl _i2cRead
                             19 ;--------------------------------------------------------
                             20 ; special function registers
                             21 ;--------------------------------------------------------
                    0081     22 G$SP$0$0 == 0x0081
                    0081     23 _SP	=	0x0081
                    0082     24 G$DPL$0$0 == 0x0082
                    0082     25 _DPL	=	0x0082
                    0083     26 G$DPH$0$0 == 0x0083
                    0083     27 _DPH	=	0x0083
                    0082     28 G$DPL0$0$0 == 0x0082
                    0082     29 _DPL0	=	0x0082
                    0083     30 G$DPH0$0$0 == 0x0083
                    0083     31 _DPH0	=	0x0083
                    0084     32 G$DPL1$0$0 == 0x0084
                    0084     33 _DPL1	=	0x0084
                    0085     34 G$DPH1$0$0 == 0x0085
                    0085     35 _DPH1	=	0x0085
                    0086     36 G$DPS$0$0 == 0x0086
                    0086     37 _DPS	=	0x0086
                    008E     38 G$CKCON$0$0 == 0x008e
                    008E     39 _CKCON	=	0x008e
                    00A2     40 G$INT4CLR$0$0 == 0x00a2
                    00A2     41 _INT4CLR	=	0x00a2
                    00F8     42 G$EIP$0$0 == 0x00f8
                    00F8     43 _EIP	=	0x00f8
                    0087     44 G$PCON$0$0 == 0x0087
                    0087     45 _PCON	=	0x0087
                    0088     46 G$TCON$0$0 == 0x0088
                    0088     47 _TCON	=	0x0088
                    0080     48 G$IOA$0$0 == 0x0080
                    0080     49 _IOA	=	0x0080
                    0090     50 G$IOB$0$0 == 0x0090
                    0090     51 _IOB	=	0x0090
                    00A0     52 G$IOC$0$0 == 0x00a0
                    00A0     53 _IOC	=	0x00a0
                    00B0     54 G$IOD$0$0 == 0x00b0
                    00B0     55 _IOD	=	0x00b0
                    00B1     56 G$IOE$0$0 == 0x00b1
                    00B1     57 _IOE	=	0x00b1
                    0089     58 G$TMOD$0$0 == 0x0089
                    0089     59 _TMOD	=	0x0089
                    008A     60 G$TL0$0$0 == 0x008a
                    008A     61 _TL0	=	0x008a
                    008B     62 G$TL1$0$0 == 0x008b
                    008B     63 _TL1	=	0x008b
                    008C     64 G$TH0$0$0 == 0x008c
                    008C     65 _TH0	=	0x008c
                    008D     66 G$TH1$0$0 == 0x008d
                    008D     67 _TH1	=	0x008d
                    008F     68 G$SPC_FNC$0$0 == 0x008f
                    008F     69 _SPC_FNC	=	0x008f
                    0091     70 G$EXIF$0$0 == 0x0091
                    0091     71 _EXIF	=	0x0091
                    0092     72 G$MPAGE$0$0 == 0x0092
                    0092     73 _MPAGE	=	0x0092
                    0098     74 G$SCON0$0$0 == 0x0098
                    0098     75 _SCON0	=	0x0098
                    0099     76 G$SBUF0$0$0 == 0x0099
                    0099     77 _SBUF0	=	0x0099
                    00A8     78 G$IE$0$0 == 0x00a8
                    00A8     79 _IE	=	0x00a8
                    00B8     80 G$IP$0$0 == 0x00b8
                    00B8     81 _IP	=	0x00b8
                    00C0     82 G$SCON1$0$0 == 0x00c0
                    00C0     83 _SCON1	=	0x00c0
                    00C1     84 G$SBUF1$0$0 == 0x00c1
                    00C1     85 _SBUF1	=	0x00c1
                    00C8     86 G$T2CON$0$0 == 0x00c8
                    00C8     87 _T2CON	=	0x00c8
                    00CA     88 G$RCAP2L$0$0 == 0x00ca
                    00CA     89 _RCAP2L	=	0x00ca
                    00CB     90 G$RCAP2H$0$0 == 0x00cb
                    00CB     91 _RCAP2H	=	0x00cb
                    00CC     92 G$TL2$0$0 == 0x00cc
                    00CC     93 _TL2	=	0x00cc
                    00CD     94 G$TH2$0$0 == 0x00cd
                    00CD     95 _TH2	=	0x00cd
                    00D0     96 G$PSW$0$0 == 0x00d0
                    00D0     97 _PSW	=	0x00d0
                    00D8     98 G$EICON$0$0 == 0x00d8
                    00D8     99 _EICON	=	0x00d8
                    00E0    100 G$ACC$0$0 == 0x00e0
                    00E0    101 _ACC	=	0x00e0
                    00E8    102 G$EIE$0$0 == 0x00e8
                    00E8    103 _EIE	=	0x00e8
                    00F0    104 G$B$0$0 == 0x00f0
                    00F0    105 _B	=	0x00f0
                            106 ;--------------------------------------------------------
                            107 ; special function bits 
                            108 ;--------------------------------------------------------
                    00FC    109 G$PX6$0$0 == 0x00fc
                    00FC    110 _PX6	=	0x00fc
                    00FB    111 G$PX5$0$0 == 0x00fb
                    00FB    112 _PX5	=	0x00fb
                    00FA    113 G$PX4$0$0 == 0x00fa
                    00FA    114 _PX4	=	0x00fa
                    00F9    115 G$PI2C$0$0 == 0x00f9
                    00F9    116 _PI2C	=	0x00f9
                    00F8    117 G$PUSB$0$0 == 0x00f8
                    00F8    118 _PUSB	=	0x00f8
                    008F    119 G$TF1$0$0 == 0x008f
                    008F    120 _TF1	=	0x008f
                    008E    121 G$TR1$0$0 == 0x008e
                    008E    122 _TR1	=	0x008e
                    008D    123 G$TF0$0$0 == 0x008d
                    008D    124 _TF0	=	0x008d
                    008C    125 G$TR0$0$0 == 0x008c
                    008C    126 _TR0	=	0x008c
                    008B    127 G$IE1$0$0 == 0x008b
                    008B    128 _IE1	=	0x008b
                    008A    129 G$IT1$0$0 == 0x008a
                    008A    130 _IT1	=	0x008a
                    0089    131 G$IE0$0$0 == 0x0089
                    0089    132 _IE0	=	0x0089
                    0088    133 G$IT0$0$0 == 0x0088
                    0088    134 _IT0	=	0x0088
                    0080    135 G$IOA_0$0$0 == 0x0080
                    0080    136 _IOA_0	=	0x0080
                    0081    137 G$IOA_1$0$0 == 0x0081
                    0081    138 _IOA_1	=	0x0081
                    0082    139 G$IOA_2$0$0 == 0x0082
                    0082    140 _IOA_2	=	0x0082
                    0083    141 G$IOA_3$0$0 == 0x0083
                    0083    142 _IOA_3	=	0x0083
                    0084    143 G$IOA_4$0$0 == 0x0084
                    0084    144 _IOA_4	=	0x0084
                    0085    145 G$IOA_5$0$0 == 0x0085
                    0085    146 _IOA_5	=	0x0085
                    0086    147 G$IOA_6$0$0 == 0x0086
                    0086    148 _IOA_6	=	0x0086
                    0087    149 G$IOA_7$0$0 == 0x0087
                    0087    150 _IOA_7	=	0x0087
                    0090    151 G$IOB_0$0$0 == 0x0090
                    0090    152 _IOB_0	=	0x0090
                    0091    153 G$IOB_1$0$0 == 0x0091
                    0091    154 _IOB_1	=	0x0091
                    0092    155 G$IOB_2$0$0 == 0x0092
                    0092    156 _IOB_2	=	0x0092
                    0093    157 G$IOB_3$0$0 == 0x0093
                    0093    158 _IOB_3	=	0x0093
                    0094    159 G$IOB_4$0$0 == 0x0094
                    0094    160 _IOB_4	=	0x0094
                    0095    161 G$IOB_5$0$0 == 0x0095
                    0095    162 _IOB_5	=	0x0095
                    0096    163 G$IOB_6$0$0 == 0x0096
                    0096    164 _IOB_6	=	0x0096
                    0097    165 G$IOB_7$0$0 == 0x0097
                    0097    166 _IOB_7	=	0x0097
                    00A0    167 G$IOC_0$0$0 == 0x00a0
                    00A0    168 _IOC_0	=	0x00a0
                    00A1    169 G$IOC_1$0$0 == 0x00a1
                    00A1    170 _IOC_1	=	0x00a1
                    00A2    171 G$IOC_2$0$0 == 0x00a2
                    00A2    172 _IOC_2	=	0x00a2
                    00A3    173 G$IOC_3$0$0 == 0x00a3
                    00A3    174 _IOC_3	=	0x00a3
                    00A4    175 G$IOC_4$0$0 == 0x00a4
                    00A4    176 _IOC_4	=	0x00a4
                    00A5    177 G$IOC_5$0$0 == 0x00a5
                    00A5    178 _IOC_5	=	0x00a5
                    00A6    179 G$IOC_6$0$0 == 0x00a6
                    00A6    180 _IOC_6	=	0x00a6
                    00A7    181 G$IOC_7$0$0 == 0x00a7
                    00A7    182 _IOC_7	=	0x00a7
                    00B0    183 G$IOD_0$0$0 == 0x00b0
                    00B0    184 _IOD_0	=	0x00b0
                    00B1    185 G$IOD_1$0$0 == 0x00b1
                    00B1    186 _IOD_1	=	0x00b1
                    00B2    187 G$IOD_2$0$0 == 0x00b2
                    00B2    188 _IOD_2	=	0x00b2
                    00B3    189 G$IOD_3$0$0 == 0x00b3
                    00B3    190 _IOD_3	=	0x00b3
                    00B4    191 G$IOD_4$0$0 == 0x00b4
                    00B4    192 _IOD_4	=	0x00b4
                    00B5    193 G$IOD_5$0$0 == 0x00b5
                    00B5    194 _IOD_5	=	0x00b5
                    00B6    195 G$IOD_6$0$0 == 0x00b6
                    00B6    196 _IOD_6	=	0x00b6
                    00B7    197 G$IOD_7$0$0 == 0x00b7
                    00B7    198 _IOD_7	=	0x00b7
                    009F    199 G$SM0_0$0$0 == 0x009f
                    009F    200 _SM0_0	=	0x009f
                    009E    201 G$SM1_0$0$0 == 0x009e
                    009E    202 _SM1_0	=	0x009e
                    009D    203 G$SM2_0$0$0 == 0x009d
                    009D    204 _SM2_0	=	0x009d
                    009C    205 G$REN_0$0$0 == 0x009c
                    009C    206 _REN_0	=	0x009c
                    009B    207 G$TB8_0$0$0 == 0x009b
                    009B    208 _TB8_0	=	0x009b
                    009A    209 G$RB8_0$0$0 == 0x009a
                    009A    210 _RB8_0	=	0x009a
                    0099    211 G$TI_0$0$0 == 0x0099
                    0099    212 _TI_0	=	0x0099
                    0098    213 G$RI_0$0$0 == 0x0098
                    0098    214 _RI_0	=	0x0098
                    00AF    215 G$EA$0$0 == 0x00af
                    00AF    216 _EA	=	0x00af
                    00AE    217 G$ES1$0$0 == 0x00ae
                    00AE    218 _ES1	=	0x00ae
                    00AD    219 G$ET2$0$0 == 0x00ad
                    00AD    220 _ET2	=	0x00ad
                    00AC    221 G$ES0$0$0 == 0x00ac
                    00AC    222 _ES0	=	0x00ac
                    00AB    223 G$ET1$0$0 == 0x00ab
                    00AB    224 _ET1	=	0x00ab
                    00AA    225 G$EX1$0$0 == 0x00aa
                    00AA    226 _EX1	=	0x00aa
                    00A9    227 G$ET0$0$0 == 0x00a9
                    00A9    228 _ET0	=	0x00a9
                    00A8    229 G$EX0$0$0 == 0x00a8
                    00A8    230 _EX0	=	0x00a8
                    00BE    231 G$PS1$0$0 == 0x00be
                    00BE    232 _PS1	=	0x00be
                    00BD    233 G$PT2$0$0 == 0x00bd
                    00BD    234 _PT2	=	0x00bd
                    00BC    235 G$PS0$0$0 == 0x00bc
                    00BC    236 _PS0	=	0x00bc
                    00BB    237 G$PT1$0$0 == 0x00bb
                    00BB    238 _PT1	=	0x00bb
                    00BA    239 G$PX1$0$0 == 0x00ba
                    00BA    240 _PX1	=	0x00ba
                    00B9    241 G$PT0$0$0 == 0x00b9
                    00B9    242 _PT0	=	0x00b9
                    00B8    243 G$PX0$0$0 == 0x00b8
                    00B8    244 _PX0	=	0x00b8
                    00C7    245 G$SM0_1$0$0 == 0x00c7
                    00C7    246 _SM0_1	=	0x00c7
                    00C6    247 G$SM1_1$0$0 == 0x00c6
                    00C6    248 _SM1_1	=	0x00c6
                    00C5    249 G$SM2_1$0$0 == 0x00c5
                    00C5    250 _SM2_1	=	0x00c5
                    00C4    251 G$REN_1$0$0 == 0x00c4
                    00C4    252 _REN_1	=	0x00c4
                    00C3    253 G$TB8_1$0$0 == 0x00c3
                    00C3    254 _TB8_1	=	0x00c3
                    00C2    255 G$RB8_1$0$0 == 0x00c2
                    00C2    256 _RB8_1	=	0x00c2
                    00C1    257 G$TI_1$0$0 == 0x00c1
                    00C1    258 _TI_1	=	0x00c1
                    00C0    259 G$RI_1$0$0 == 0x00c0
                    00C0    260 _RI_1	=	0x00c0
                    00CF    261 G$TF2$0$0 == 0x00cf
                    00CF    262 _TF2	=	0x00cf
                    00CE    263 G$EXF2$0$0 == 0x00ce
                    00CE    264 _EXF2	=	0x00ce
                    00CD    265 G$RCLK$0$0 == 0x00cd
                    00CD    266 _RCLK	=	0x00cd
                    00CC    267 G$TCLK$0$0 == 0x00cc
                    00CC    268 _TCLK	=	0x00cc
                    00CB    269 G$EXEN2$0$0 == 0x00cb
                    00CB    270 _EXEN2	=	0x00cb
                    00CA    271 G$TR2$0$0 == 0x00ca
                    00CA    272 _TR2	=	0x00ca
                    00C9    273 G$CT2$0$0 == 0x00c9
                    00C9    274 _CT2	=	0x00c9
                    00C8    275 G$CPRL2$0$0 == 0x00c8
                    00C8    276 _CPRL2	=	0x00c8
                    00D7    277 G$CY$0$0 == 0x00d7
                    00D7    278 _CY	=	0x00d7
                    00D6    279 G$AC$0$0 == 0x00d6
                    00D6    280 _AC	=	0x00d6
                    00D5    281 G$F0$0$0 == 0x00d5
                    00D5    282 _F0	=	0x00d5
                    00D4    283 G$RS1$0$0 == 0x00d4
                    00D4    284 _RS1	=	0x00d4
                    00D3    285 G$RS0$0$0 == 0x00d3
                    00D3    286 _RS0	=	0x00d3
                    00D2    287 G$OV$0$0 == 0x00d2
                    00D2    288 _OV	=	0x00d2
                    00D0    289 G$P$0$0 == 0x00d0
                    00D0    290 _P	=	0x00d0
                    00DF    291 G$SMOD1$0$0 == 0x00df
                    00DF    292 _SMOD1	=	0x00df
                    00DD    293 G$ERESI$0$0 == 0x00dd
                    00DD    294 _ERESI	=	0x00dd
                    00DC    295 G$RESI$0$0 == 0x00dc
                    00DC    296 _RESI	=	0x00dc
                    00DB    297 G$INT6$0$0 == 0x00db
                    00DB    298 _INT6	=	0x00db
                    00EC    299 G$EWDI$0$0 == 0x00ec
                    00EC    300 _EWDI	=	0x00ec
                    00EB    301 G$EX5$0$0 == 0x00eb
                    00EB    302 _EX5	=	0x00eb
                    00EA    303 G$EX4$0$0 == 0x00ea
                    00EA    304 _EX4	=	0x00ea
                    00E9    305 G$EI2C$0$0 == 0x00e9
                    00E9    306 _EI2C	=	0x00e9
                    00E8    307 G$EUSB$0$0 == 0x00e8
                    00E8    308 _EUSB	=	0x00e8
                            309 ;--------------------------------------------------------
                            310 ; internal ram data
                            311 ;--------------------------------------------------------
                            312 	.area DSEG    (DATA)
                            313 ;--------------------------------------------------------
                            314 ; overlayable items in internal ram 
                            315 ;--------------------------------------------------------
                            316 	.area OSEG    (OVR,DATA)
                            317 ;--------------------------------------------------------
                            318 ; indirectly addressable internal ram data
                            319 ;--------------------------------------------------------
                            320 	.area ISEG    (DATA)
                            321 ;--------------------------------------------------------
                            322 ; bit data
                            323 ;--------------------------------------------------------
                            324 	.area BSEG    (BIT)
                            325 ;--------------------------------------------------------
                            326 ; external ram data
                            327 ;--------------------------------------------------------
                            328 	.area XSEG    (XDATA)
                    7800    329 G$AINDATA$0$0 == 0x7800
                    7800    330 _AINDATA	=	0x7800
                    7801    331 G$AINBC$0$0 == 0x7801
                    7801    332 _AINBC	=	0x7801
                    7802    333 G$AINPF$0$0 == 0x7802
                    7802    334 _AINPF	=	0x7802
                    7803    335 G$AINPFPIN$0$0 == 0x7803
                    7803    336 _AINPFPIN	=	0x7803
                    7805    337 G$BINDATA$0$0 == 0x7805
                    7805    338 _BINDATA	=	0x7805
                    7806    339 G$BINBC$0$0 == 0x7806
                    7806    340 _BINBC	=	0x7806
                    7807    341 G$BINPF$0$0 == 0x7807
                    7807    342 _BINPF	=	0x7807
                    7808    343 G$BINPFPIN$0$0 == 0x7808
                    7808    344 _BINPFPIN	=	0x7808
                    780A    345 G$ABINTF$0$0 == 0x780a
                    780A    346 _ABINTF	=	0x780a
                    780B    347 G$ABINIE$0$0 == 0x780b
                    780B    348 _ABINIE	=	0x780b
                    780C    349 G$ABINIRQ$0$0 == 0x780c
                    780C    350 _ABINIRQ	=	0x780c
                    780E    351 G$AOUTDATA$0$0 == 0x780e
                    780E    352 _AOUTDATA	=	0x780e
                    780F    353 G$AOUTBC$0$0 == 0x780f
                    780F    354 _AOUTBC	=	0x780f
                    7810    355 G$AOUTPF$0$0 == 0x7810
                    7810    356 _AOUTPF	=	0x7810
                    7811    357 G$AOUTPFPIN$0$0 == 0x7811
                    7811    358 _AOUTPFPIN	=	0x7811
                    7813    359 G$BOUTDATA$0$0 == 0x7813
                    7813    360 _BOUTDATA	=	0x7813
                    7814    361 G$BOUTBC$0$0 == 0x7814
                    7814    362 _BOUTBC	=	0x7814
                    7815    363 G$BOUTPF$0$0 == 0x7815
                    7815    364 _BOUTPF	=	0x7815
                    7816    365 G$BOUTPFPIN$0$0 == 0x7816
                    7816    366 _BOUTPFPIN	=	0x7816
                    7818    367 G$ABOUTTF$0$0 == 0x7818
                    7818    368 _ABOUTTF	=	0x7818
                    7819    369 G$ABOUTIE$0$0 == 0x7819
                    7819    370 _ABOUTIE	=	0x7819
                    781A    371 G$ABOUTIRQ$0$0 == 0x781a
                    781A    372 _ABOUTIRQ	=	0x781a
                    781C    373 G$ABSETUP$0$0 == 0x781c
                    781C    374 _ABSETUP	=	0x781c
                    781D    375 G$ABPOLAR$0$0 == 0x781d
                    781D    376 _ABPOLAR	=	0x781d
                    781E    377 G$ABFLUSH$0$0 == 0x781e
                    781E    378 _ABFLUSH	=	0x781e
                    7824    379 G$WFSELECT$0$0 == 0x7824
                    7824    380 _WFSELECT	=	0x7824
                    7825    381 G$IDLE_CS$0$0 == 0x7825
                    7825    382 _IDLE_CS	=	0x7825
                    7826    383 G$IDLE_CTLOUT$0$0 == 0x7826
                    7826    384 _IDLE_CTLOUT	=	0x7826
                    7827    385 G$CTLOUTCFG$0$0 == 0x7827
                    7827    386 _CTLOUTCFG	=	0x7827
                    782A    387 G$GPIFADRL$0$0 == 0x782a
                    782A    388 _GPIFADRL	=	0x782a
                    7900    389 G$WFDESC$0$0 == 0x7900
                    7900    390 _WFDESC	=	0x7900
                    7900    391 G$WFDESC0$0$0 == 0x7900
                    7900    392 _WFDESC0	=	0x7900
                    7920    393 G$WFDESC1$0$0 == 0x7920
                    7920    394 _WFDESC1	=	0x7920
                    7940    395 G$WFDESC2$0$0 == 0x7940
                    7940    396 _WFDESC2	=	0x7940
                    7960    397 G$WFDESC3$0$0 == 0x7960
                    7960    398 _WFDESC3	=	0x7960
                    782C    399 G$AINTC$0$0 == 0x782c
                    782C    400 _AINTC	=	0x782c
                    782D    401 G$AOUTTC$0$0 == 0x782d
                    782D    402 _AOUTTC	=	0x782d
                    782E    403 G$ATRIG$0$0 == 0x782e
                    782E    404 _ATRIG	=	0x782e
                    7830    405 G$BINTC$0$0 == 0x7830
                    7830    406 _BINTC	=	0x7830
                    7831    407 G$BOUTTC$0$0 == 0x7831
                    7831    408 _BOUTTC	=	0x7831
                    7832    409 G$BTRIG$0$0 == 0x7832
                    7832    410 _BTRIG	=	0x7832
                    7834    411 G$SGLDATH$0$0 == 0x7834
                    7834    412 _SGLDATH	=	0x7834
                    7835    413 G$SGLDATLTRIG$0$0 == 0x7835
                    7835    414 _SGLDATLTRIG	=	0x7835
                    7836    415 G$SGLDATLNTRIG$0$0 == 0x7836
                    7836    416 _SGLDATLNTRIG	=	0x7836
                    7838    417 G$READY$0$0 == 0x7838
                    7838    418 _READY	=	0x7838
                    7839    419 G$ABORT$0$0 == 0x7839
                    7839    420 _ABORT	=	0x7839
                    783B    421 G$GENIE$0$0 == 0x783b
                    783B    422 _GENIE	=	0x783b
                    783C    423 G$GENIRQ$0$0 == 0x783c
                    783C    424 _GENIRQ	=	0x783c
                    784A    425 G$IFCONFIG$0$0 == 0x784a
                    784A    426 _IFCONFIG	=	0x784a
                    7FE3    427 G$AUTOPTRH$0$0 == 0x7fe3
                    7FE3    428 _AUTOPTRH	=	0x7fe3
                    7FE4    429 G$AUTOPTRL$0$0 == 0x7fe4
                    7FE4    430 _AUTOPTRL	=	0x7fe4
                    7FE5    431 G$AUTODATA$0$0 == 0x7fe5
                    7FE5    432 _AUTODATA	=	0x7fe5
                    7F96    433 G$OUTA$0$0 == 0x7f96
                    7F96    434 _OUTA	=	0x7f96
                    7F97    435 G$OUTB$0$0 == 0x7f97
                    7F97    436 _OUTB	=	0x7f97
                    7F98    437 G$OUTC$0$0 == 0x7f98
                    7F98    438 _OUTC	=	0x7f98
                    7841    439 G$OUTD$0$0 == 0x7841
                    7841    440 _OUTD	=	0x7841
                    7845    441 G$OUTE$0$0 == 0x7845
                    7845    442 _OUTE	=	0x7845
                    7F99    443 G$PINSA$0$0 == 0x7f99
                    7F99    444 _PINSA	=	0x7f99
                    7F9A    445 G$PINSB$0$0 == 0x7f9a
                    7F9A    446 _PINSB	=	0x7f9a
                    7F9B    447 G$PINSC$0$0 == 0x7f9b
                    7F9B    448 _PINSC	=	0x7f9b
                    7842    449 G$PINSD$0$0 == 0x7842
                    7842    450 _PINSD	=	0x7842
                    7846    451 G$PINSE$0$0 == 0x7846
                    7846    452 _PINSE	=	0x7846
                    7F9C    453 G$OEA$0$0 == 0x7f9c
                    7F9C    454 _OEA	=	0x7f9c
                    7F9D    455 G$OEB$0$0 == 0x7f9d
                    7F9D    456 _OEB	=	0x7f9d
                    7F9E    457 G$OEC$0$0 == 0x7f9e
                    7F9E    458 _OEC	=	0x7f9e
                    7843    459 G$OED$0$0 == 0x7843
                    7843    460 _OED	=	0x7843
                    7847    461 G$OEE$0$0 == 0x7847
                    7847    462 _OEE	=	0x7847
                    7F93    463 G$PORTACFG$0$0 == 0x7f93
                    7F93    464 _PORTACFG	=	0x7f93
                    7F94    465 G$PORTBCFG$0$0 == 0x7f94
                    7F94    466 _PORTBCFG	=	0x7f94
                    7F95    467 G$PORTCCFG$0$0 == 0x7f95
                    7F95    468 _PORTCCFG	=	0x7f95
                    784C    469 G$PORTCCF2$0$0 == 0x784c
                    784C    470 _PORTCCF2	=	0x784c
                    7849    471 G$PORTSETUP$0$0 == 0x7849
                    7849    472 _PORTSETUP	=	0x7849
                    785D    473 G$INT4IVEC$0$0 == 0x785d
                    785D    474 _INT4IVEC	=	0x785d
                    785E    475 G$INT4SETUP$0$0 == 0x785e
                    785E    476 _INT4SETUP	=	0x785e
                    784F    477 G$DMASRCH$0$0 == 0x784f
                    784F    478 _DMASRCH	=	0x784f
                    7850    479 G$DMASRCL$0$0 == 0x7850
                    7850    480 _DMASRCL	=	0x7850
                    7851    481 G$DMADESTH$0$0 == 0x7851
                    7851    482 _DMADESTH	=	0x7851
                    7852    483 G$DMADESTL$0$0 == 0x7852
                    7852    484 _DMADESTL	=	0x7852
                    7857    485 G$DMABURST$0$0 == 0x7857
                    7857    486 _DMABURST	=	0x7857
                    7854    487 G$DMALEN$0$0 == 0x7854
                    7854    488 _DMALEN	=	0x7854
                    7855    489 G$DMAGO$0$0 == 0x7855
                    7855    490 _DMAGO	=	0x7855
                    7FA6    491 G$I2DAT$0$0 == 0x7fa6
                    7FA6    492 _I2DAT	=	0x7fa6
                    7FA5    493 G$I2CS$0$0 == 0x7fa5
                    7FA5    494 _I2CS	=	0x7fa5
                    7FA7    495 G$I2CMODE$0$0 == 0x7fa7
                    7FA7    496 _I2CMODE	=	0x7fa7
                    7F92    497 G$CPUCS$0$0 == 0x7f92
                    7F92    498 _CPUCS	=	0x7f92
                    7FA0    499 G$ISOERR$0$0 == 0x7fa0
                    7FA0    500 _ISOERR	=	0x7fa0
                    7FA1    501 G$ISOCTL$0$0 == 0x7fa1
                    7FA1    502 _ISOCTL	=	0x7fa1
                    7FA2    503 G$ZBCOUNT$0$0 == 0x7fa2
                    7FA2    504 _ZBCOUNT	=	0x7fa2
                    7F00    505 G$IN0BUF$0$0 == 0x7f00
                    7F00    506 _IN0BUF	=	0x7f00
                    7EC0    507 G$OUT0BUF$0$0 == 0x7ec0
                    7EC0    508 _OUT0BUF	=	0x7ec0
                    7E80    509 G$IN1BUF$0$0 == 0x7e80
                    7E80    510 _IN1BUF	=	0x7e80
                    7E40    511 G$OUT1BUF$0$0 == 0x7e40
                    7E40    512 _OUT1BUF	=	0x7e40
                    7E00    513 G$IN2BUF$0$0 == 0x7e00
                    7E00    514 _IN2BUF	=	0x7e00
                    7DC0    515 G$OUT2BUF$0$0 == 0x7dc0
                    7DC0    516 _OUT2BUF	=	0x7dc0
                    7D80    517 G$IN3BUF$0$0 == 0x7d80
                    7D80    518 _IN3BUF	=	0x7d80
                    7D40    519 G$OUT3BUF$0$0 == 0x7d40
                    7D40    520 _OUT3BUF	=	0x7d40
                    7D00    521 G$IN4BUF$0$0 == 0x7d00
                    7D00    522 _IN4BUF	=	0x7d00
                    7CC0    523 G$OUT4BUF$0$0 == 0x7cc0
                    7CC0    524 _OUT4BUF	=	0x7cc0
                    7C80    525 G$IN5BUF$0$0 == 0x7c80
                    7C80    526 _IN5BUF	=	0x7c80
                    7C40    527 G$OUT5BUF$0$0 == 0x7c40
                    7C40    528 _OUT5BUF	=	0x7c40
                    7C00    529 G$IN6BUF$0$0 == 0x7c00
                    7C00    530 _IN6BUF	=	0x7c00
                    7BC0    531 G$OUT6BUF$0$0 == 0x7bc0
                    7BC0    532 _OUT6BUF	=	0x7bc0
                    7B80    533 G$IN7BUF$0$0 == 0x7b80
                    7B80    534 _IN7BUF	=	0x7b80
                    7B40    535 G$OUT7BUF$0$0 == 0x7b40
                    7B40    536 _OUT7BUF	=	0x7b40
                    7FE8    537 G$SETUPBUF$0$0 == 0x7fe8
                    7FE8    538 _SETUPBUF	=	0x7fe8
                    7FE8    539 G$SETUPDAT$0$0 == 0x7fe8
                    7FE8    540 _SETUPDAT	=	0x7fe8
                    7FB4    541 G$EP0CS$0$0 == 0x7fb4
                    7FB4    542 _EP0CS	=	0x7fb4
                    7FB5    543 G$IN0BC$0$0 == 0x7fb5
                    7FB5    544 _IN0BC	=	0x7fb5
                    7FB6    545 G$IN1CS$0$0 == 0x7fb6
                    7FB6    546 _IN1CS	=	0x7fb6
                    7FB7    547 G$IN1BC$0$0 == 0x7fb7
                    7FB7    548 _IN1BC	=	0x7fb7
                    7FB8    549 G$IN2CS$0$0 == 0x7fb8
                    7FB8    550 _IN2CS	=	0x7fb8
                    7FB9    551 G$IN2BC$0$0 == 0x7fb9
                    7FB9    552 _IN2BC	=	0x7fb9
                    7FBA    553 G$IN3CS$0$0 == 0x7fba
                    7FBA    554 _IN3CS	=	0x7fba
                    7FBB    555 G$IN3BC$0$0 == 0x7fbb
                    7FBB    556 _IN3BC	=	0x7fbb
                    7FBC    557 G$IN4CS$0$0 == 0x7fbc
                    7FBC    558 _IN4CS	=	0x7fbc
                    7FBD    559 G$IN4BC$0$0 == 0x7fbd
                    7FBD    560 _IN4BC	=	0x7fbd
                    7FBE    561 G$IN5CS$0$0 == 0x7fbe
                    7FBE    562 _IN5CS	=	0x7fbe
                    7FBF    563 G$IN5BC$0$0 == 0x7fbf
                    7FBF    564 _IN5BC	=	0x7fbf
                    7FC0    565 G$IN6CS$0$0 == 0x7fc0
                    7FC0    566 _IN6CS	=	0x7fc0
                    7FC1    567 G$IN6BC$0$0 == 0x7fc1
                    7FC1    568 _IN6BC	=	0x7fc1
                    7FC2    569 G$IN7CS$0$0 == 0x7fc2
                    7FC2    570 _IN7CS	=	0x7fc2
                    7FC3    571 G$IN7BC$0$0 == 0x7fc3
                    7FC3    572 _IN7BC	=	0x7fc3
                    7FC5    573 G$OUT0BC$0$0 == 0x7fc5
                    7FC5    574 _OUT0BC	=	0x7fc5
                    7FC6    575 G$OUT1CS$0$0 == 0x7fc6
                    7FC6    576 _OUT1CS	=	0x7fc6
                    7FC7    577 G$OUT1BC$0$0 == 0x7fc7
                    7FC7    578 _OUT1BC	=	0x7fc7
                    7FC8    579 G$OUT2CS$0$0 == 0x7fc8
                    7FC8    580 _OUT2CS	=	0x7fc8
                    7FC9    581 G$OUT2BC$0$0 == 0x7fc9
                    7FC9    582 _OUT2BC	=	0x7fc9
                    7FCA    583 G$OUT3CS$0$0 == 0x7fca
                    7FCA    584 _OUT3CS	=	0x7fca
                    7FCB    585 G$OUT3BC$0$0 == 0x7fcb
                    7FCB    586 _OUT3BC	=	0x7fcb
                    7FCC    587 G$OUT4CS$0$0 == 0x7fcc
                    7FCC    588 _OUT4CS	=	0x7fcc
                    7FCD    589 G$OUT4BC$0$0 == 0x7fcd
                    7FCD    590 _OUT4BC	=	0x7fcd
                    7FCE    591 G$OUT5CS$0$0 == 0x7fce
                    7FCE    592 _OUT5CS	=	0x7fce
                    7FCF    593 G$OUT5BC$0$0 == 0x7fcf
                    7FCF    594 _OUT5BC	=	0x7fcf
                    7FD0    595 G$OUT6CS$0$0 == 0x7fd0
                    7FD0    596 _OUT6CS	=	0x7fd0
                    7FD1    597 G$OUT6BC$0$0 == 0x7fd1
                    7FD1    598 _OUT6BC	=	0x7fd1
                    7FD2    599 G$OUT7CS$0$0 == 0x7fd2
                    7FD2    600 _OUT7CS	=	0x7fd2
                    7FD3    601 G$OUT7BC$0$0 == 0x7fd3
                    7FD3    602 _OUT7BC	=	0x7fd3
                    7FA8    603 G$IVEC$0$0 == 0x7fa8
                    7FA8    604 _IVEC	=	0x7fa8
                    7FA9    605 G$IN07IRQ$0$0 == 0x7fa9
                    7FA9    606 _IN07IRQ	=	0x7fa9
                    7FAA    607 G$OUT07IRQ$0$0 == 0x7faa
                    7FAA    608 _OUT07IRQ	=	0x7faa
                    7FAB    609 G$USBIRQ$0$0 == 0x7fab
                    7FAB    610 _USBIRQ	=	0x7fab
                    7FAC    611 G$IN07IEN$0$0 == 0x7fac
                    7FAC    612 _IN07IEN	=	0x7fac
                    7FAD    613 G$OUT07IEN$0$0 == 0x7fad
                    7FAD    614 _OUT07IEN	=	0x7fad
                    7FAE    615 G$USBIEN$0$0 == 0x7fae
                    7FAE    616 _USBIEN	=	0x7fae
                    7FAF    617 G$USBBAV$0$0 == 0x7faf
                    7FAF    618 _USBBAV	=	0x7faf
                    7FB2    619 G$BPADDRH$0$0 == 0x7fb2
                    7FB2    620 _BPADDRH	=	0x7fb2
                    7FB3    621 G$BPADDRL$0$0 == 0x7fb3
                    7FB3    622 _BPADDRL	=	0x7fb3
                    7FD4    623 G$SUDPTRH$0$0 == 0x7fd4
                    7FD4    624 _SUDPTRH	=	0x7fd4
                    7FD5    625 G$SUDPTRL$0$0 == 0x7fd5
                    7FD5    626 _SUDPTRL	=	0x7fd5
                    7FD6    627 G$USBCS$0$0 == 0x7fd6
                    7FD6    628 _USBCS	=	0x7fd6
                    7FD7    629 G$TOGCTL$0$0 == 0x7fd7
                    7FD7    630 _TOGCTL	=	0x7fd7
                    7FD8    631 G$USBFRAMEL$0$0 == 0x7fd8
                    7FD8    632 _USBFRAMEL	=	0x7fd8
                    7FD9    633 G$USBFRAMEH$0$0 == 0x7fd9
                    7FD9    634 _USBFRAMEH	=	0x7fd9
                    7FDB    635 G$FNADDR$0$0 == 0x7fdb
                    7FDB    636 _FNADDR	=	0x7fdb
                    7FDD    637 G$USBPAIR$0$0 == 0x7fdd
                    7FDD    638 _USBPAIR	=	0x7fdd
                    7FDE    639 G$IN07VAL$0$0 == 0x7fde
                    7FDE    640 _IN07VAL	=	0x7fde
                    7FDF    641 G$OUT07VAL$0$0 == 0x7fdf
                    7FDF    642 _OUT07VAL	=	0x7fdf
                    7F60    643 G$OUT8DATA$0$0 == 0x7f60
                    7F60    644 _OUT8DATA	=	0x7f60
                    7F61    645 G$OUT9DATA$0$0 == 0x7f61
                    7F61    646 _OUT9DATA	=	0x7f61
                    7F62    647 G$OUT10DATA$0$0 == 0x7f62
                    7F62    648 _OUT10DATA	=	0x7f62
                    7F63    649 G$OUT11DATA$0$0 == 0x7f63
                    7F63    650 _OUT11DATA	=	0x7f63
                    7F64    651 G$OUT12DATA$0$0 == 0x7f64
                    7F64    652 _OUT12DATA	=	0x7f64
                    7F65    653 G$OUT13DATA$0$0 == 0x7f65
                    7F65    654 _OUT13DATA	=	0x7f65
                    7F66    655 G$OUT14DATA$0$0 == 0x7f66
                    7F66    656 _OUT14DATA	=	0x7f66
                    7F67    657 G$OUT15DATA$0$0 == 0x7f67
                    7F67    658 _OUT15DATA	=	0x7f67
                    7F68    659 G$IN8DATA$0$0 == 0x7f68
                    7F68    660 _IN8DATA	=	0x7f68
                    7F69    661 G$IN9DATA$0$0 == 0x7f69
                    7F69    662 _IN9DATA	=	0x7f69
                    7F6A    663 G$IN10DATA$0$0 == 0x7f6a
                    7F6A    664 _IN10DATA	=	0x7f6a
                    7F6B    665 G$IN11DATA$0$0 == 0x7f6b
                    7F6B    666 _IN11DATA	=	0x7f6b
                    7F6C    667 G$IN12DATA$0$0 == 0x7f6c
                    7F6C    668 _IN12DATA	=	0x7f6c
                    7F6D    669 G$IN13DATA$0$0 == 0x7f6d
                    7F6D    670 _IN13DATA	=	0x7f6d
                    7F6E    671 G$IN14DATA$0$0 == 0x7f6e
                    7F6E    672 _IN14DATA	=	0x7f6e
                    7F6F    673 G$IN15DATA$0$0 == 0x7f6f
                    7F6F    674 _IN15DATA	=	0x7f6f
                    7F70    675 G$OUT8BCH$0$0 == 0x7f70
                    7F70    676 _OUT8BCH	=	0x7f70
                    7F71    677 G$OUT8BCL$0$0 == 0x7f71
                    7F71    678 _OUT8BCL	=	0x7f71
                    7F72    679 G$OUT9BCH$0$0 == 0x7f72
                    7F72    680 _OUT9BCH	=	0x7f72
                    7F73    681 G$OUT9BCL$0$0 == 0x7f73
                    7F73    682 _OUT9BCL	=	0x7f73
                    7F74    683 G$OUT10BCH$0$0 == 0x7f74
                    7F74    684 _OUT10BCH	=	0x7f74
                    7F75    685 G$OUT10BCL$0$0 == 0x7f75
                    7F75    686 _OUT10BCL	=	0x7f75
                    7F76    687 G$OUT11BCH$0$0 == 0x7f76
                    7F76    688 _OUT11BCH	=	0x7f76
                    7F77    689 G$OUT11BCL$0$0 == 0x7f77
                    7F77    690 _OUT11BCL	=	0x7f77
                    7F78    691 G$OUT12BCH$0$0 == 0x7f78
                    7F78    692 _OUT12BCH	=	0x7f78
                    7F79    693 G$OUT12BCL$0$0 == 0x7f79
                    7F79    694 _OUT12BCL	=	0x7f79
                    7F7A    695 G$OUT13BCH$0$0 == 0x7f7a
                    7F7A    696 _OUT13BCH	=	0x7f7a
                    7F7B    697 G$OUT13BCL$0$0 == 0x7f7b
                    7F7B    698 _OUT13BCL	=	0x7f7b
                    7F7C    699 G$OUT14BCH$0$0 == 0x7f7c
                    7F7C    700 _OUT14BCH	=	0x7f7c
                    7F7D    701 G$OUT14BCL$0$0 == 0x7f7d
                    7F7D    702 _OUT14BCL	=	0x7f7d
                    7F7E    703 G$OUT15BCH$0$0 == 0x7f7e
                    7F7E    704 _OUT15BCH	=	0x7f7e
                    7F7F    705 G$OUT15BCL$0$0 == 0x7f7f
                    7F7F    706 _OUT15BCL	=	0x7f7f
                    7FF0    707 G$OUT8ADDR$0$0 == 0x7ff0
                    7FF0    708 _OUT8ADDR	=	0x7ff0
                    7FF1    709 G$OUT9ADDR$0$0 == 0x7ff1
                    7FF1    710 _OUT9ADDR	=	0x7ff1
                    7FF2    711 G$OUT10ADDR$0$0 == 0x7ff2
                    7FF2    712 _OUT10ADDR	=	0x7ff2
                    7FF3    713 G$OUT11ADDR$0$0 == 0x7ff3
                    7FF3    714 _OUT11ADDR	=	0x7ff3
                    7FF4    715 G$OUT12ADDR$0$0 == 0x7ff4
                    7FF4    716 _OUT12ADDR	=	0x7ff4
                    7FF5    717 G$OUT13ADDR$0$0 == 0x7ff5
                    7FF5    718 _OUT13ADDR	=	0x7ff5
                    7FF6    719 G$OUT14ADDR$0$0 == 0x7ff6
                    7FF6    720 _OUT14ADDR	=	0x7ff6
                    7FF7    721 G$OUT15ADDR$0$0 == 0x7ff7
                    7FF7    722 _OUT15ADDR	=	0x7ff7
                    7FF8    723 G$IN8ADDR$0$0 == 0x7ff8
                    7FF8    724 _IN8ADDR	=	0x7ff8
                    7FF9    725 G$IN9ADDR$0$0 == 0x7ff9
                    7FF9    726 _IN9ADDR	=	0x7ff9
                    7FFA    727 G$IN10ADDR$0$0 == 0x7ffa
                    7FFA    728 _IN10ADDR	=	0x7ffa
                    7FFB    729 G$IN11ADDR$0$0 == 0x7ffb
                    7FFB    730 _IN11ADDR	=	0x7ffb
                    7FFC    731 G$IN12ADDR$0$0 == 0x7ffc
                    7FFC    732 _IN12ADDR	=	0x7ffc
                    7FFD    733 G$IN13ADDR$0$0 == 0x7ffd
                    7FFD    734 _IN13ADDR	=	0x7ffd
                    7FFE    735 G$IN14ADDR$0$0 == 0x7ffe
                    7FFE    736 _IN14ADDR	=	0x7ffe
                    7FFF    737 G$IN15ADDR$0$0 == 0x7fff
                    7FFF    738 _IN15ADDR	=	0x7fff
                    7FE0    739 G$INISOVAL$0$0 == 0x7fe0
                    7FE0    740 _INISOVAL	=	0x7fe0
                    7FE1    741 G$OUTISOVAL$0$0 == 0x7fe1
                    7FE1    742 _OUTISOVAL	=	0x7fe1
                    7FE2    743 G$FASTXFR$0$0 == 0x7fe2
                    7FE2    744 _FASTXFR	=	0x7fe2
                            745 ;--------------------------------------------------------
                            746 ; global & static initialisations
                            747 ;--------------------------------------------------------
                            748 	.area GSINIT  (CODE)
                            749 	.area GSFINAL (CODE)
                            750 	.area GSINIT  (CODE)
                            751 ;--------------------------------------------------------
                            752 ; Home
                            753 ;--------------------------------------------------------
                            754 	.area HOME	 (CODE)
                            755 	.area CSEG    (CODE)
                            756 ;--------------------------------------------------------
                            757 ; code
                            758 ;--------------------------------------------------------
                            759 	.area CSEG    (CODE)
                            760 ;------------------------------------------------------------
                            761 ;Allocation info for local variables in function 'msecWait48MHz'
                            762 ;------------------------------------------------------------
                    0000    763 	G$msecWait48MHz$0$0 ==.
                            764 ;	ezusbfx.c 10
                            765 ;	-----------------------------------------
                            766 ;	 function msecWait48MHz
                            767 ;	-----------------------------------------
   02F2                     768 _msecWait48MHz:
                    0002    769 	ar2 = 0x02
                    0003    770 	ar3 = 0x03
                    0004    771 	ar4 = 0x04
                    0005    772 	ar5 = 0x05
                    0006    773 	ar6 = 0x06
                    0007    774 	ar7 = 0x07
                    0000    775 	ar0 = 0x00
                    0001    776 	ar1 = 0x01
                            777 ;	ezusbfx.c 18
   02F2 90 FB 4F            778 	    mov     dptr,#(0xFFFF - 1200)
   02F5                     779   00001$:
                            780 	                  ; 10 instruction cycles per loop iteration 
   02F5 A3                  781 	    inc     dptr            ; 3 Instruction Cycles
   02F6 E5 82               782 	    mov     a,dpl           ; 2 Instruction Cycles
   02F8 45 83               783 	    orl     a,dph           ; 2 Instruction Cycles
   02FA 70 F9               784 	    jnz     00001$          ; 3 Instruction Cycles
   02FC                     785 00101$:
                    000A    786 	C$ezusbfx.c$19$1$1 ==.
                    000A    787 	XG$msecWait48MHz$0$0 ==.
   02FC 22                  788 	ret
                            789 ;------------------------------------------------------------
                            790 ;Allocation info for local variables in function 'msecWait24MHz'
                            791 ;------------------------------------------------------------
                    000B    792 	G$msecWait24MHz$0$0 ==.
                            793 ;	ezusbfx.c 23
                            794 ;	-----------------------------------------
                            795 ;	 function msecWait24MHz
                            796 ;	-----------------------------------------
   02FD                     797 _msecWait24MHz:
                            798 ;	ezusbfx.c 31
   02FD 90 FD A7            799 	    mov     dptr,#(0xFFFF - 600)
   0300                     800   00001$:
                            801 	                  ; 10 instruction cycles per loop iteration 
   0300 A3                  802 	    inc     dptr            ; 3 Instruction Cycles
   0301 E5 82               803 	    mov     a,dpl           ; 2 Instruction Cycles
   0303 45 83               804 	    orl     a,dph           ; 2 Instruction Cycles
   0305 70 F9               805 	    jnz     00001$          ; 3 Instruction Cycles
   0307                     806 00101$:
                    0015    807 	C$ezusbfx.c$32$1$1 ==.
                    0015    808 	XG$msecWait24MHz$0$0 ==.
   0307 22                  809 	ret
                            810 ;------------------------------------------------------------
                            811 ;Allocation info for local variables in function 'msecWait'
                            812 ;------------------------------------------------------------
                            813 ;msec                      Allocated to registers r2 r3 
                    0016    814 	G$msecWait$0$0 ==.
                            815 ;	ezusbfx.c 35
                            816 ;	-----------------------------------------
                            817 ;	 function msecWait
                            818 ;	-----------------------------------------
   0308                     819 _msecWait:
                            820 ;	ezusbfx.c 0
   0308 AA 82               821 	mov	r2,dpl
   030A AB 83               822 	mov	r3,dph
                            823 ;	ezusbfx.c 36
   030C 90 7F 92            824 	mov	dptr,#_CPUCS
   030F E0                  825 	movx	a,@dptr
                            826 ; Peephole 105   removed redundant mov
   0310 FC                  827 	mov  r4,a
   0311 33                  828 	rlc	a
   0312 95 E0               829 	subb	a,acc
   0314 FD                  830 	mov	r5,a
   0315 53 04 08            831 	anl	ar4,#0x08
   0318 7D 00               832 	mov	r5,#0x00
   031A EC                  833 	mov	a,r4
   031B 4D                  834 	orl	a,r5
                            835 ; Peephole 110   removed ljmp by inverse jump logic
   031C 60 26               836 	jz  00115$
   031E                     837 00116$:
                            838 ;	ezusbfx.c 37
   031E 8A 04               839 	mov	ar4,r2
   0320 8B 05               840 	mov	ar5,r3
   0322                     841 00101$:
   0322 8C 06               842 	mov	ar6,r4
   0324 8D 07               843 	mov	ar7,r5
   0326 1C                  844 	dec	r4
   0327 BC FF 01            845 	cjne	r4,#0xff,00117$
   032A 1D                  846 	dec	r5
   032B                     847 00117$:
   032B EE                  848 	mov	a,r6
   032C 4F                  849 	orl	a,r7
                            850 ; Peephole 110   removed ljmp by inverse jump logic
   032D 60 2F               851 	jz  00110$
   032F                     852 00118$:
                            853 ;	ezusbfx.c 38
   032F C0 02               854 	push	ar2
   0331 C0 03               855 	push	ar3
   0333 C0 04               856 	push	ar4
   0335 C0 05               857 	push	ar5
   0337 12 02 F2            858 	lcall	_msecWait48MHz
   033A D0 05               859 	pop	ar5
   033C D0 04               860 	pop	ar4
   033E D0 03               861 	pop	ar3
   0340 D0 02               862 	pop	ar2
                            863 ;	ezusbfx.c 40
                            864 ; Peephole 132   changed ljmp to sjmp
   0342 80 DE               865 	sjmp 00101$
   0344                     866 00115$:
   0344                     867 00104$:
   0344 8A 04               868 	mov	ar4,r2
   0346 8B 05               869 	mov	ar5,r3
   0348 1A                  870 	dec	r2
   0349 BA FF 01            871 	cjne	r2,#0xff,00119$
   034C 1B                  872 	dec	r3
   034D                     873 00119$:
   034D EC                  874 	mov	a,r4
   034E 4D                  875 	orl	a,r5
                            876 ; Peephole 110   removed ljmp by inverse jump logic
   034F 60 0D               877 	jz  00110$
   0351                     878 00120$:
                            879 ;	ezusbfx.c 41
   0351 C0 02               880 	push	ar2
   0353 C0 03               881 	push	ar3
   0355 12 02 FD            882 	lcall	_msecWait24MHz
   0358 D0 03               883 	pop	ar3
   035A D0 02               884 	pop	ar2
                            885 ; Peephole 132   changed ljmp to sjmp
   035C 80 E6               886 	sjmp 00104$
   035E                     887 00110$:
                    006C    888 	C$ezusbfx.c$42$1$1 ==.
                    006C    889 	XG$msecWait$0$0 ==.
   035E 22                  890 	ret
                            891 ;------------------------------------------------------------
                            892 ;Allocation info for local variables in function 'i2cWrite'
                            893 ;------------------------------------------------------------
                            894 ;val                       Allocated to registers 
                    006D    895 	G$i2cWrite$0$0 ==.
                            896 ;	ezusbfx.c 45
                            897 ;	-----------------------------------------
                            898 ;	 function i2cWrite
                            899 ;	-----------------------------------------
   035F                     900 _i2cWrite:
                            901 ;	ezusbfx.c 56
   035F C0 82               902 	push	dpl
   0361 90 7F A6            903 	mov	dptr,#_I2DAT
   0364 D0 E0               904 	pop	acc
   0366 F0                  905 	movx	@dptr,a
                            906 ;	ezusbfx.c 48
   0367                     907 00101$:
   0367 90 7F A5            908 	mov	dptr,#_I2CS
   036A E0                  909 	movx	a,@dptr
                            910 ; Peephole 105   removed redundant mov
   036B FA                  911 	mov  r2,a
   036C 33                  912 	rlc	a
   036D 95 E0               913 	subb	a,acc
   036F FB                  914 	mov	r3,a
   0370 53 02 01            915 	anl	ar2,#0x01
   0373 7B 00               916 	mov	r3,#0x00
   0375 BA 00 05            917 	cjne	r2,#0x00,00112$
   0378 BB 00 02            918 	cjne	r3,#0x00,00112$
                            919 ; Peephole 132   changed ljmp to sjmp
   037B 80 EA               920 	sjmp 00101$
   037D                     921 00112$:
                            922 ;	ezusbfx.c 51
   037D 90 7F A5            923 	mov	dptr,#_I2CS
   0380 E0                  924 	movx	a,@dptr
                            925 ; Peephole 105   removed redundant mov
   0381 FA                  926 	mov  r2,a
   0382 33                  927 	rlc	a
   0383 95 E0               928 	subb	a,acc
   0385 FB                  929 	mov	r3,a
   0386 53 02 04            930 	anl	ar2,#0x04
   0389 7B 00               931 	mov	r3,#0x00
   038B EA                  932 	mov	a,r2
   038C 4B                  933 	orl	a,r3
                            934 ; Peephole 109   removed ljmp by inverse jump logic
   038D 70 14               935 	jnz  00104$
   038F                     936 00113$:
   038F 90 7F A5            937 	mov	dptr,#_I2CS
   0392 E0                  938 	movx	a,@dptr
                            939 ; Peephole 105   removed redundant mov
   0393 FA                  940 	mov  r2,a
   0394 33                  941 	rlc	a
   0395 95 E0               942 	subb	a,acc
   0397 FB                  943 	mov	r3,a
   0398 53 02 02            944 	anl	ar2,#0x02
   039B 7B 00               945 	mov	r3,#0x00
                            946 ; Peephole 132   changed ljmp to sjmp
                            947 ; Peephole 198   optimized misc jump sequence
   039D BA 00 0E            948 	cjne r2,#0x00,00105$
   03A0 BB 00 0B            949 	cjne r3,#0x00,00105$
                            950 ;00114$:
                            951 ; Peephole 200   removed redundant sjmp
   03A3                     952 00115$:
   03A3                     953 00104$:
                            954 ;	ezusbfx.c 52
   03A3 90 7F A5            955 	mov	dptr,#_I2CS
   03A6 74 40               956 	mov	a,#0x40
   03A8 F0                  957 	movx	@dptr,a
                            958 ;	ezusbfx.c 53
   03A9 75 82 FF            959 	mov	dpl,#0xFF
                            960 ; Peephole 132   changed ljmp to sjmp
   03AC 80 03               961 	sjmp 00107$
   03AE                     962 00105$:
                            963 ;	ezusbfx.c 56
   03AE 75 82 00            964 	mov	dpl,#0x00
   03B1                     965 00107$:
                    00BF    966 	C$ezusbfx.c$57$1$1 ==.
                    00BF    967 	XG$i2cWrite$0$0 ==.
   03B1 22                  968 	ret
                            969 ;------------------------------------------------------------
                            970 ;Allocation info for local variables in function 'i2cRead'
                            971 ;------------------------------------------------------------
                            972 ;dat                       Allocated to registers r2 
                    00C0    973 	G$i2cRead$0$0 ==.
                            974 ;	ezusbfx.c 63
                            975 ;	-----------------------------------------
                            976 ;	 function i2cRead
                            977 ;	-----------------------------------------
   03B2                     978 _i2cRead:
                            979 ;	ezusbfx.c 65
   03B2 90 7F A6            980 	mov	dptr,#_I2DAT
   03B5 E0                  981 	movx	a,@dptr
   03B6 FA                  982 	mov	r2,a
                            983 ;	ezusbfx.c 66
   03B7                     984 00101$:
   03B7 90 7F A5            985 	mov	dptr,#_I2CS
   03BA E0                  986 	movx	a,@dptr
                            987 ; Peephole 105   removed redundant mov
   03BB FB                  988 	mov  r3,a
   03BC 33                  989 	rlc	a
   03BD 95 E0               990 	subb	a,acc
   03BF FC                  991 	mov	r4,a
   03C0 53 03 01            992 	anl	ar3,#0x01
   03C3 7C 00               993 	mov	r4,#0x00
   03C5 BB 00 05            994 	cjne	r3,#0x00,00111$
   03C8 BC 00 02            995 	cjne	r4,#0x00,00111$
                            996 ; Peephole 132   changed ljmp to sjmp
   03CB 80 EA               997 	sjmp 00101$
   03CD                     998 00111$:
                            999 ;	ezusbfx.c 69
   03CD 90 7F A5           1000 	mov	dptr,#_I2CS
   03D0 E0                 1001 	movx	a,@dptr
                           1002 ; Peephole 105   removed redundant mov
   03D1 FB                 1003 	mov  r3,a
   03D2 33                 1004 	rlc	a
   03D3 95 E0              1005 	subb	a,acc
   03D5 FC                 1006 	mov	r4,a
   03D6 53 03 04           1007 	anl	ar3,#0x04
   03D9 7C 00              1008 	mov	r4,#0x00
   03DB EB                 1009 	mov	a,r3
   03DC 4C                 1010 	orl	a,r4
                           1011 ; Peephole 110   removed ljmp by inverse jump logic
   03DD 60 0B              1012 	jz  00105$
   03DF                    1013 00112$:
                           1014 ;	ezusbfx.c 70
   03DF 90 7F A5           1015 	mov	dptr,#_I2CS
   03E2 74 40              1016 	mov	a,#0x40
   03E4 F0                 1017 	movx	@dptr,a
                           1018 ;	ezusbfx.c 71
                           1019 ; Peephole 182   used 16 bit load of dptr
   03E5 90 FF FF           1020 	mov  dptr,#(((0xFF)<<8) + 0xFF)
                           1021 ; Peephole 132   changed ljmp to sjmp
   03E8 80 05              1022 	sjmp 00106$
   03EA                    1023 00105$:
                           1024 ;	ezusbfx.c 74
   03EA 8A 82              1025 	mov	dpl,r2
   03EC 75 83 00           1026 	mov	dph,#0x00
   03EF                    1027 00106$:
                    00FD   1028 	C$ezusbfx.c$75$1$1 ==.
                    00FD   1029 	XG$i2cRead$0$0 ==.
   03EF 22                 1030 	ret
                           1031 	.area CSEG    (CODE)
