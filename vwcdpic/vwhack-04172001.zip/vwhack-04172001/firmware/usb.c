// USB Control
// Copyright (c) 2001, Edward Schlunder <zilym@yahoo.com>

#include "ezusbfx.h"
#include "usb.h"
#include "serial.h"

#include <string.h>

extern idata unsigned short volatile state, disc, track, mix, scan;
extern unsigned int volatile timeCount, timeSave;

void initUSB(void) {
  unsigned short i;

  USBIEN = 0;             // disable all USB interrupts

  USBCS = 0;              // disconnect from USB (to simulate device removal)
  USBBAV = 0;             // disable autovector, disable breakpoint logic
  ISOCTL = ISODISAB;      // disable ISO endpoints
  INISOVAL = 0;
  OUTISOVAL = 0;

  USBPAIR = (1<<1);       // turn on double buffering for endpoints 4/5 IN
  IN07VAL = (1<<2)|(1<<4);// enable ezconsole in endpoint
  OUT07VAL= (1<<2);       // enable ezconsole out endpoint
  IN07IEN = 0;            // disable all IN endpoint interrupts
  OUT07IEN = (1<<2);      // enable OUT2EP interrupt, disable all others

  // clear all endpoint dataX toggles
  for(i = 0; i < 7; i++) {
    TOGCTL = 0x10 + i;
    TOGCTL = 0x30 + i;
    TOGCTL = i;           // clear EP in toggle
    TOGCTL = 0x20 + i;    // clear EP out toggle
  }

  USBCS = (1<<2);         // reconnect to USB bus (simulate device insertion)
  // renumeration is done

  // arm the OUT2EP so we can receive the next command
  OUT2BC = 0;
  EUSB = 1;               // enable USB interrupts
}

void intUSB(void) interrupt 8 {
  unsigned short src = IVEC >> 2;

  switch(src) {
  case 0:
    // setup data available
    EXIF &= ~USBINT;
    USBIRQ = SUDAVIR;
    break;
  case 1:
    //    usb_sof();
    EXIF &= ~USBINT; // without this get continuous interrupt :-)
    USBIRQ = SOFIR;
    break;
  case 2:
    //    usb_sutok(); // setup token (debug only)
    EXIF &= ~USBINT;
    USBIRQ = SUTOKIR;
    break;
  case 3:
    //    usb_suspend();
    EXIF &= ~USBINT;
    USBIRQ = SUSPIR;
    break;
  case 4:
    //    usb_usbreset();
    EXIF &= ~USBINT;
    USBIRQ = URESIR;
    break;
  case 6:
    //    usb_ep0in();
    EXIF &= ~USBINT;
    IN07IRQ = 1<<0;
    break;
  case 7:
    //    usb_ep0out();
    EXIF &= ~USBINT;
    OUT07IRQ = 1<<0;
    break;
  case 8:
    //    usb_ep1in();
    EXIF &= ~USBINT;
    IN07IRQ = 1<<1;
    break;
  case 9:
    //    usb_ep1out();
    EXIF &= ~USBINT;
    OUT07IRQ = 1<<1;
    break;
  case 11:
    ep2outUSB();
    EXIF &= ~USBINT;
    OUT07IRQ = 1<<2;
    break;
  }
}

// EndPoint 2 Out - Console Commands
void ep2outUSB(void) {
  // console app start/exit?
  if(OUT2BUF[0] == 0 || OUT2BUF[0] == 1) {
    unsigned short i;
    for(i = 0; i < 7; i++) {
      TOGCTL = 0x10 + i;
      TOGCTL = 0x30 + i;
      TOGCTL = i;           // clear EP in toggle
      if(OUT2BUF[0] == 1)
	TOGCTL = 0x20 + i;  // clear EP out toggle (only if console app exited)
    }

    OUT2BC = 0;
    return;
  }

  if(strcmp(OUT2BUF, "id\n") == 0) {
    prints("EZ Protoboard Console Firmware v1.0.0\n");
    prints("Copyright (c) 2001, Ed Schlunder <zilym@yahoo.com>\n\n");
  }

  if(strcmp(OUT2BUF, "speed\n") == 0) {
    if(CPUCS & CLK2448)
      prints("48MHz\n\n");
    else
      prints("24MHz\n\n");
  }
  
  if(strcmp(OUT2BUF, "next\n") == 0) {
    prints("next mp3 song\n");
    nextMP3();
  }

  if(strcmp(OUT2BUF, "pass\n") == 0) {
    prints("State Change: CD Passthrough\n");
    state = STATE_CDPASS;
  }
  if(strcmp(OUT2BUF, "rxbuf\n") == 0) {
    unsigned short i;

    prints("RXBUF: [");

    // make sure EP2IN is available before screwing around with it
    while(IN2CS & EPBUSY);
    IN2BUF[0] = 3; // flag host that we're sending binary data
    IN2BUF[1] = RXSIZE;
    for(i = 0; i < RXSIZE; i++)
      IN2BUF[i+2] = rxbuf[i];
    IN2BC = 64;

    rxloc = 0;
    for(i = 0; i < RXSIZE; i++)
      rxbuf[i] = 0xFF;

    prints("]\n");
  }

  if(strcmp(OUT2BUF, "idle\n") == 0) {
    prints("State Change: Idle\n");
    state = STATE_IDLE;
  }

  if(strcmp(OUT2BUF, "time\n") == 0) {
    prints("timeSave: ");
    printn(timeSave);
    prints("\n");
  }

  /*
  if(strcmp(OUT2BUF, "dl\n") == 0) {
    unsigned int loc;
    unsigned short i;

    i = 0;
    AUTOPTRL = 0x00;
    AUTOPTRH = 0x20;
    for(loc = 0; loc < 2048; loc++) {
      IN4BUF[i++] = 
    }
  }
  */

  if(strcmp(OUT2BUF, "t+\n") == 0)
    track++;
  if(strcmp(OUT2BUF, "t-\n") == 0)
    track--;

  if(strcmp(OUT2BUF, "d+\n") == 0)
    disc++;
  if(strcmp(OUT2BUF, "d-\n") == 0)
    disc--;


  if(strcmp(OUT2BUF, "stop\n") == 0) {
    ET0 = 0;
    prints("cd emulator timer disabled\n");
  }

  if(strcmp(OUT2BUF, "mix\n") == 0) {
    if(mix) {
      prints("mix off\n");
      mix = 0;
    }
    else {
      prints("mix on\n");
      mix = 1;
    }
  }
  if(strcmp(OUT2BUF, "simple\n") == 0) {
    prints("going to simple mode\n");
    state = STATE_SIMPLE;
  }

  if(strcmp(OUT2BUF, "scan\n") == 0) {
    if(scan) {
      prints("scan off\n");
      scan = 0;
    }
    else {
      prints("scan on\n");
      scan = 1;
    }
  }

  if(strcmp(OUT2BUF, "go\n") == 0) {
    ET0 = 1;
    prints("cd emulator timer enabled\n");
  }

  if(strcmp(OUT2BUF, "state\n") == 0) {
    switch(state) {
    case STATE_IDLE:
      prints("idle\n");
      break;
    case STATE_CDPASS:
      prints("cd passthrough\n");
      break;
    case STATE_SIMPLE:
      prints("simple\n");
      break;
    }
  }

  if(strcmp(OUT2BUF, "capture\n") == 0) {
    prints("starting capture...\n");
    state = STATE_CAP;
    
    // re-arm the endpoint so we can receive the next command
    OUT2BC = 0;
    return;
  }

  if(strcmp(OUT2BUF, "head\n") == 0) {
    prints("starting head unit capture...\n");
    state = STATE_HEAD;
  }

  if(strcmp(OUT2BUF, "status\n") == 0) {
    unsigned short i, v;
    prints("EZ USB Status...\n");

    prints("Port A: ");
    v = IOA;
    for(i = 0; i < 8; i++) {
      prints((v & 0x80) ? "1":"0");
      v <<= 1;
    }
    prints("\n");

    prints("Port B: ");
    v = IOB;
    for(i = 0; i < 8; i++) {
      prints((v & 0x80) ? "1":"0");
      v <<= 1;
    }
    prints("\n");

    prints("Port C: ");
    v = IOC;
    for(i = 0; i < 8; i++) {
      prints((v & 0x80) ? "1":"0");
      v <<= 1;
    }
    prints("\n");

    prints("Port D: ");
    v = IOD;
    for(i = 0; i < 8; i++) {
      prints((v & 0x80) ? "1":"0");
      v <<= 1;
    }
    prints("\n");
  }
  
  if(strcmp(OUT2BUF, "\n") == 0)
    prints("commands: id status capture speed pass idle\n");

  printDone();
  // re-arm the endpoint so we can receive the next command
  OUT2BC = 0;
}

// send a string back to the host through EP2IN
short prints(char _generic *s) {
  unsigned short i;
  
  // make sure EP2IN is available before screwing around with it
  for(i = 1; i; i++) {
    if((IN2CS & 2) == 0)
      break;

    msecWait(10);
  }
  if(IN2CS & EPBUSY)
    return -1;   // EP2IN is busy, we skipped sending the data

  IN2BUF[0] = 1; // flag host that we're sending a string
  for(i = 0; i < 63; i++) {
    IN2BUF[i+1] = s[i];
    if(s[i] == 0)
      break;
  }

  IN2BC = 64;
  return 0;
}

short printn(unsigned int val) {
  unsigned short i;
  
  // make sure EP2IN is available before screwing around with it
  for(i = 1; i; i++) {
    if((IN2CS & 2) == 0)
      break;

    msecWait(10);
  }
  if(IN2CS & EPBUSY)
    return -1;   // EP2IN is busy, we skipped sending the data

  IN2BUF[0] = 2; // flag host that we're sending an integer
  IN2BUF[1] = val;
  IN2BUF[2] = val >> 8;
  IN2BC = 64;
  return 0;
}

short printDone(void) {
  unsigned short i;
  
  // make sure EP2IN is available before screwing around with it
  for(i = 1; i; i++) {
    if((IN2CS & 2) == 0)
      break;

    msecWait(10);
  }
  if(IN2CS & EPBUSY)
    return -1;   // EP2IN is busy, we skipped sending the data

  IN2BUF[0] = 0; // flag host that we're done
  IN2BC = 64;
  return 0;
}
