// VW Head Unit Serial Communications
// Copyright (c) 2001, Edward Schlunder <zilym@yahoo.com>

#define RXSIZE 16

extern unsigned char volatile rxbuf[RXSIZE], rxloc;

void initSerial(void);
void clearRX(void);
void nextMP3(void);
void previousMP3(void);
void mixMP3(void);
void playMP3(void);

void serial0(void) interrupt 4;

void captureHead(void);
void captureCD(void);

