// VW Head Unit Serial Communications
// Copyright (c) 2001, Edward Schlunder <zilym@yahoo.com>

#include <string.h>
#include "ezusbfx.h"
#include "serial.h"

#define BAUDRATE 1429

unsigned char txbuf[10] = "NEXT", txlen, txloc;
unsigned char volatile rxbuf[RXSIZE], rxloc;

void initSerial(void) {
  SCON0 = 0x50;           // Serial 0 - Mode 1, Async No Parity
  OEC   |= (1<<1);        // enable output (is this necessary?)
  OEC   &= ~(1<<0);
  IOC_1 = 0;
  
  //  PORTCCFG = 0;
  PORTCCF2 = 0;
  PORTCCFG = (1<<1)|(1<<0);     // IOC.1 = TxD0
  //  PORTCCF2 = ~(1<<1);

  T2CON = 0x34;          // time 2 baud rate generator for send & recieve
  TR2 = 0;               // turn off timer while changing timer reload value

  // Timer Reload = 65536 - (MCU Osc. Freq / (32 * Baud Rate))
  RCAP2H = (0xFFFF - (48000000 / (32 * BAUDRATE))) >> 8;
  RCAP2L = (0xFFFF - (48000000 / (32 * BAUDRATE))) & 0xFF;
  //  RCAP2H = 0xFF;
  //  RCAP2L = 0xB1;

  rxloc = 0;
  clearRX();

  TR2 = 1;               // enable timer 2 (baud rate generator)
  ES0 = 1;               // enable serial interrupt
}

void clearRX(void) {
  unsigned short i;

  for(i = 0; i < RXSIZE; i++)
    rxbuf[i] = 0;
}

void nextMP3(void) {
  strcpy(txbuf, "NEXT");
  txloc = 1;
  txlen = 4;
  SBUF0 = txbuf[0];
}

void previousMP3(void) {
  strcpy(txbuf, "PREVIOUS");
  txloc = 1;
  txlen = 8;
  SBUF0 = txbuf[0];
}

void mixMP3(void) {
  strcpy(txbuf, "MIX");
  txloc = 1;
  txlen = 3;
  SBUF0 = txbuf[0];
}

void playMP3(void) {
  strcpy(txbuf, "PLAY");
  txloc = 1;
  txlen = 4;
  SBUF0 = txbuf[0];
}

void serial0(void) interrupt 4 {
  if(TI_0) {
    TI_0 = 0;
    if(txloc < txlen)
      SBUF0 = txbuf[txloc++];
  }

  if(RI_0) {
    unsigned char tmp;
    tmp = SBUF0;
    if(tmp == 0)
      rxloc = 0;
    rxbuf[rxloc] = tmp;
    rxloc = (rxloc + 1) % 16;
    RI_0 = 0;
  }
}

void timeClocks(void) {
    _asm
      mov  dptr, #_AUTODATA
      mov  r2, #64
    00001$:
      mov  c,_IOA_7 ;; 2 cycles 1
      rlc  a        ;; 1 cycle 3
      nop           ;; 1 cycle 4
      nop           ;; 1 cycle 5
      nop           ;; 1 cycle 6
      nop           ;; 1 cycle 7
      nop           ;; 1 cycle 8

      mov  c,_IOA_7 ;; 2 cycles 2
      rlc  a        ;; 1 cycle
      nop           ;; 1 cycle
      nop           ;; 1 cycle
      nop           ;; 1 cycle
      nop           ;; 1 cycle
      nop           ;; 1 cycle

      mov  c,_IOA_7 ;; 2 cycles 3
      rlc  a        ;; 1 cycle
      nop           ;; 1 cycle
      nop           ;; 1 cycle
      nop           ;; 1 cycle
      nop           ;; 1 cycle
      nop           ;; 1 cycle

      mov  c,_IOA_7 ;; 2 cycles 4
      rlc  a        ;; 1 cycle
      nop           ;; 1 cycle
      nop           ;; 1 cycle
      nop           ;; 1 cycle
      nop           ;; 1 cycle
      nop           ;; 1 cycle

      mov  c,_IOA_7 ;; 2 cycles 5
      rlc  a        ;; 1 cycle
      nop           ;; 1 cycle
      nop           ;; 1 cycle
      nop           ;; 1 cycle
      nop           ;; 1 cycle
      nop           ;; 1 cycle

      mov  c,_IOA_7 ;; 2 cycles 6 
      rlc  a        ;; 1 cycle
      nop           ;; 1 cycle
      nop           ;; 1 cycle
      nop           ;; 1 cycle
      nop           ;; 1 cycle
      nop           ;; 1 cycle

      mov  c,_IOA_7 ;; 2 cycles 7
      rlc  a        ;; 1 cycle
      nop           ;; 1 cycle
      nop           ;; 1 cycle
      nop           ;; 1 cycle
      nop           ;; 1 cycle
      nop           ;; 1 cycle

      mov  c,_IOA_7 ;; 2 cycles 8
      rlc  a        ;; 1 cycle
      movx @dptr,a  ;; 2 cycles
      djnz r2,00001$;; 3 cycles
    _endasm;
}

void captureHead(void) {
    _asm
      ;; setup autoptr to point at isochronous (free) memory area
      mov     dptr,#_AUTOPTRL
      clr     a
      movx    @dptr,a
      mov     dptr,#_AUTOPTRH
      mov     a,#0x20
      mov     dptr,#_AUTODATA
      mov     r4,#8
      mov     r2,#0
      mov     r3,#8

      ;; wait for first HIGH
    00009$:
      jnb     _IOA_5,00009$

    00001$:
      mov     c,_IOA_5
      rlc     a
      djnz    r3,00001$
      movx    @dptr,a
      mov     r3,#8
      djnz    r2,00001$
      djnz    r4,00001$
    _endasm;
}

void captureCD(void) {
  ET0 = 0;
  OEA = 0x1F;             // port a pins outputs (blinking LEDs)
  for(;;) {
    AUTOPTRL = 00;
    AUTOPTRH = 0x7D;
    while(IN4CS & EPBUSY); // wait for endpoint to become available
    _asm
      mov     dptr,#_AUTODATA

      ;; wait for SCLK low at least 256 pulses
    00005$:
      mov     r2, #0
    00006$:
      mov     c,_IOA_5            ;; copy head unit buttons to cd changer
      mov     _IOA_4,c
      jb      _IOA_7,00005$
      djnz    r2,00006$

      ;; now read in 64 bytes of data from the cd changer
      mov     r5, #64
    00000$:
      mov     r2, #8
    00007$:
      mov     c,_IOA_5            ;; copy head unit buttons to cd changer
      mov     _IOA_4,c
      jnb     _IOA_7,00007$       ;; wait for SCLK HIGH
      setb    _IOA_0
    00002$:
      mov     c,_IOA_5            ;; copy head unit buttons to cd changer
      mov     _IOA_4,c
      jb      _IOA_7,00002$       ;; wait for SCLK LOW, then sample SRX
      mov     c,_IOA_6
      mov     _IOA_1,c
      clr     _IOA_0
      rlc     a
      
      djnz    r2,00007$
    00009$:
      movx    @dptr,a	
      djnz    r5,00000$
    _endasm;
    IN4BC = 64;
  }
}
