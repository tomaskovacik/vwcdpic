// USB Linux - Userland USB interface routines
// Copyright (c) 2001, Ed Schlunder <zilym@yahoo.com>
//
// Based upon code originally by Andrew Burgess and Thomas Sailer

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/param.h>
#include <sys/ioctl.h>
#include <fcntl.h>

#include <linux/usbdevice_fs.h>

#include "usblinux.h"

const char *usbdevfs = "/proc/bus/usb"; // usual usbdevfs mount point

struct usbdevice *usbOpenByNumber(unsigned int bus, unsigned int device) {
  struct usbdevice *dev;
  struct usb_device_descriptor desc;
  int fd;
  char tmp[PATH_MAX + 1];

  // open the usbdevfs file of this USB device
  if(snprintf(tmp, sizeof(tmp), 
	      "%s/%03u/%03u", usbdevfs, bus, device) >= sizeof(tmp)) {
    errno = ENAMETOOLONG;
    return NULL;
  }
  fd = open(tmp, O_RDWR);
  if(fd == -1)
    return NULL;

  // try to read the usb device descriptor
  if(read(fd, &desc, sizeof(desc)) != sizeof(desc)) {
    errno = EIO;
    close(fd);
    return NULL;
  }

  // allocate a usbdevice handle for this new device and return it
  dev = malloc(sizeof(struct usbdevice));
  if(dev == NULL) {
    close(fd);
    return NULL;
  }

  dev->fd = fd;
  dev->desc = desc;
  dev->interface = dev->altsetting = 0;
  return dev;
}

struct usbdevice *usbOpen(unsigned int vendor, unsigned int product) {
  int fd, i, bus = -1, device = -1;
  char tmp[16384], *begin, *end, *lineEnd, *cp;

  // open the usbdevfs device listing file to scan for this vendor/product ID
  if(snprintf(tmp, sizeof(tmp), 
	      "%s/devices", usbdevfs) >= sizeof(tmp)) {
    errno = ENAMETOOLONG;
    return NULL;
  }
  fd = open(tmp, O_RDONLY);
  if(fd == -1)
    return NULL;

  i = read(fd, tmp, sizeof(tmp));
  close(fd);
  if(i == -1)
    return NULL;

  begin = tmp;
  end = begin + i;
  while(begin < end) { 
    int tmpVendor = -1, tmpProduct = -1;

    lineEnd = strchr(begin, '\n');
    if(lineEnd == NULL) {
      errno = ENODEV;
      return NULL;
    }
    lineEnd[0] = 0;

    switch(begin[0]) {
    case 'T': // topology
      if((cp = strstr(begin, "Bus=")) != NULL)
	bus = atoi(cp + 4);
      if((cp = strstr(begin, "Dev#=")) != NULL)
	device = atoi(cp + 5);
      break;
    case 'P': // product identification
      if((cp = strstr(begin, "Vendor=")) != NULL)
	tmpVendor = strtoul(cp + 7, NULL, 16);
      if((cp = strstr(begin, "ProdID=")) != NULL)
	tmpProduct = strtoul(cp + 7, NULL, 16);

      // is this the device we were looking for?
      if(vendor == tmpVendor && product == tmpProduct && device > 0 && bus > 0)
	return usbOpenByNumber(bus, device);
      break;
    }
    
    begin = lineEnd + 1;
  }

  return NULL;
}

void usbClose(struct usbdevice *dev) {
  if(!dev)
     return;

  close(dev->fd);
  free(dev);
}

int usbClaimInterface(struct usbdevice *dev, unsigned int intf) {
  int ret;

  dev->interface = intf;
  ret = ioctl(dev->fd, USBDEVFS_CLAIMINTERFACE, &intf);
  if(ret < 0)
    printf("USBDEVFS_CLAIMINTERFACE (intf=0x%x) error %s\n", 
	   intf, strerror(errno));
 
  return ret;
}

int usbReleaseInterface(struct usbdevice *dev, unsigned int intf) {
  int ret;

  ret = ioctl(dev->fd, USBDEVFS_RELEASEINTERFACE, &intf);
  if(ret < 0)
    printf("USBDEVFS_RELEASEINTERFACE (intf=0x%x) error %s\n", 
	   intf, strerror(errno));
 
  return ret;
}

int usbSetAltInterface(struct usbdevice *dev, unsigned int altsetting) {
  struct usbdevfs_setinterface tmp;
  int ret;

  tmp.interface = dev->interface;
  tmp.altsetting = altsetting;
  ret = ioctl(dev->fd, USBDEVFS_SETINTERFACE, &tmp);
  if(ret < 0)
    printf("USBDEVFS_SETINTERFACE (intf=0x%x altset=%u) error %s\n", 
	   tmp.interface, tmp.altsetting, strerror(errno));
  return ret;
}

int usbBulkOut(struct usbdevice *dev, int ep, void *data, int len, int timeout) {
  struct usbdevfs_bulktransfer tmp;
  int ret;

  tmp.ep = ep | USB_DIR_OUT;
  tmp.len = len;
  tmp.timeout = timeout;
  tmp.data = data;
 
  ret = ioctl(dev->fd, USBDEVFS_BULK, &tmp);
  if(ret < 0)
    printf("USBDEVFS_BULKOUT (ep=0x%x len=%u) error %s\n", 
	   ep, len, strerror(errno));
  return ret;
}

int usbBulkIn(struct usbdevice *dev, int ep, void *data, int len, int timeout) {
  struct usbdevfs_bulktransfer tmp;
  int ret;

  tmp.ep = ep | USB_DIR_IN;
  tmp.len = len;
  tmp.timeout = timeout;
  tmp.data = data;
 
  ret = ioctl(dev->fd, USBDEVFS_BULK, &tmp);
  /*
  if(ret < 0)
    printf("USBDEVFS_BULKIN (ep=0x%x len=%u) error %s\n", 
	   ep, len, strerror(errno));
  */
  return ret;
}
