// USB Linux - Userland USB interface routines
// Copyright (c) 2001, Ed Schlunder <zilym@yahoo.com>

#include <sys/types.h>
#include <errno.h>

#define USB_DIR_OUT 0
#define USB_DIR_IN  0x80

struct usb_device_descriptor {
  u_int8_t  bLength;
  u_int8_t  bDescriptorType;
  u_int8_t  bcdUSB[2];
  u_int8_t  bDeviceClass;
  u_int8_t  bDeviceSubClass;
  u_int8_t  bDeviceProtocol;
  u_int8_t  bMaxPacketSize0;
  u_int8_t  idVendor[2];
  u_int8_t  idProduct[2];
  u_int8_t  bcdDevice[2];
  u_int8_t  iManufacturer;
  u_int8_t  iProduct;
  u_int8_t  iSerialNumber;
  u_int8_t  bNumConfigurations;
};

struct usbdevice {
  int fd;
  unsigned int interface;
  unsigned int altsetting;
  struct usb_device_descriptor desc;
};

struct usbdevice *usbOpen(unsigned int vendor, unsigned int product);
struct usbdevice *usbOpenByNumber(unsigned int bus, unsigned int device);
void usbClose(struct usbdevice *dev);

int usbClaimInterface(struct usbdevice *dev, unsigned int intf);
int usbReleaseInterface(struct usbdevice *dev, unsigned int intf);
int usbSetAltInterface(struct usbdevice *dev, unsigned int altsetting);

int usbBulkIn(struct usbdevice *dev, int ep, void *data, int len, int timeout);
int usbBulkOut(struct usbdevice *dev, int ep, void *data, int len, int timeout);
